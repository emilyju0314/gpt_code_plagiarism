void ts::DCCT::clear()
{
    dcc_subtype = 0;
    dcc_id = 0;
    protocol_version = 0;
    descs.clear();
    tests.clear();
}