void Vector3::getValues(FLOAT_TYPE& X, FLOAT_TYPE& Y, FLOAT_TYPE &Z) const {
  X = _v[0];
  Y = _v[1];
  Z = _v[2];
}