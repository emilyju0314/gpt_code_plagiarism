Vector4::Vector4(const Vector4& v) {
  _v[0] = v[0];
  _v[1] = v[1];
  _v[2] = v[2];
  _v[3] = v[3];
}