void CGenericCrowd::Precache()
{
	PrecacheModel( STRING( GetModelName() ) );
		PrecacheModel( "models/bahl101.mdl" );
		PrecacheModel( "models/combine_soldier.mdl" );
		PrecacheModel( "models/police.mdl" );
		PrecacheModel( "models/childsoldier.mdl" );
		PrecacheModel( "models/cremator_npc.mdl" );
		PrecacheModel( "models/hgang01.mdl" );
		PrecacheModel( "models/monster_metropolice.mdl" );
		PrecacheModel( "models/Tank_Escorter.mdl" );
		PrecacheModel( "models/barngreen.mdl" );
		PrecacheModel( "models/barnyellow.mdl" );
}