inline UObjectMode
  UContext::getRunningMode() const
  {
    return ctx_->getRunningMode();
  }