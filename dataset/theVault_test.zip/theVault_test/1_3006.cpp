Configuration *Configuration::EnableHarmonyCollections(bool _HarmonyCollections)
{
	HarmonyCollections = _HarmonyCollections;

	return this;
}