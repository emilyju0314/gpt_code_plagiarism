std::string NumberToString ( int Number )
{
	std::stringstream ss;
	ss << Number;
	return ss.str();
}