rsm_client_protocol::status
rsm::client_invoke(int procno, std::string req, std::string &r)
{
  int ret = rsm_client_protocol::OK;
  return ret;
}