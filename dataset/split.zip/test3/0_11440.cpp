#include <iostream>
#include <vector>
#include <cmath>

#define MOD 100000007

std::vector<int> sieve(int n) {
    std::vector<int> primes;
    std::vector<bool> is_prime(n + 1, true);

    for (int p = 2; p * p <= n; p++) {
        if (is_prime[p]) {
            for (int i = p * p; i <= n; i += p) {
                is_prime[i] = false;
            }
        }
    }

    for (int p = 2; p <= n; p++) {
        if (is_prime[p]) {
            primes.push_back(p);
        }
    }

    return primes;
}

int countNumbers(int n, int m) {
    std::vector<int> primes = sieve(n);

    long long result = 1;

    for (int i = 0; i < primes.size(); i++) {
        if (primes[i] <= m) {
            continue;
        }

        long long p = primes[i];
        long long k = (n / p) - 1;
        long long temp = 1;

        while (k > 0) {
            temp = (temp * k) % MOD;
            k -= p;
        }

        result = (result * temp) % MOD;
    }

    return result;
}

int main() {
    int n, m;

    while (true) {
        std::cin >> n >> m;

        if (n == 0 && m == 0) {
            break;
        }

        int result = countNumbers(n, m);

        std::cout << result << std::endl;
    }

    return 0;
}