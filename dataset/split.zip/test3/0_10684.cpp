#include <iostream>
#include <vector>

int main() {
    int N;
    
    while (true) {
        std::cin >> N;
        
        if (N == 0) {
            break;
        }
        
        std::vector<int> bets(N);
        
        for (int i = 0; i < N; i++) {
            std::cin >> bets[i];
        }
        
        int max_gain = 0;
        int curr_gain = 0;
        
        for (int i = 0; i < N; i++) {
            curr_gain += bets[i];
            
            if (curr_gain < 0) {
                curr_gain = 0;
            }
            
            if (curr_gain > max_gain) {
                max_gain = curr_gain;
            }
        }
        
        if (max_gain > 0) {
            std::cout << "The maximum winning streak is " << max_gain << "." << std::endl;
        } else {
            std::cout << "Losing streak." << std::endl;
        }
    }
    
    return 0;
}