#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    int caseNum = 1;
    int n, D;
    while (cin >> n >> D) {
        if (n == 0 && D == 0) break;
        
        double totalTime = 0.0;
        
        for (int i = 0; i < n; i++) {
            int p, L, v;
            cin >> p >> L >> v;
            
            double timeToCross = (double)L / v;
            double timeToCatch = (double)p / v;
            
            double timeWaiting = 0.0;
            while (timeWaiting < timeToCatch) {
                timeToCatch -= timeWaiting;
                if (timeToCatch >= 2 * timeToCross) {
                    totalTime += timeToCatch;
                    break;
                } else {
                    totalTime += 2 * timeToCatch;
                    timeToCatch = 0;
                }
                timeWaiting = 2 * timeToCross - timeToCatch;
            }
        }
        
        cout << "Case " << caseNum << ": " << fixed << setprecision(3) << totalTime << endl;
        cout << endl;
        caseNum++;
    }
    
    return 0;
}