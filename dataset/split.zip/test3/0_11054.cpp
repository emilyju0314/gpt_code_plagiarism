#include <iostream>
#include <vector>
#include <cmath>

int main() {
    int n;
    
    while (std::cin >> n && n != 0) {
        std::vector<int> demands(n);
        
        for (int i = 0; i < n; i++) {
            std::cin >> demands[i];
        }
        
        long long total_work = 0;
        long long cumulative_demand = 0;
        
        for (int i = 0; i < n; i++) {
            cumulative_demand += demands[i];
            total_work += std::abs(cumulative_demand);
        }
        
        std::cout << total_work << std::endl;
    }
    
    return 0;
}