#include <iostream>
#include <string>
#include <algorithm>
#include <vector>

void generateWords(std::string word, std::string current, std::vector<std::string>& result) {
    if (word.empty()) {
        result.push_back(current);
        return;
    }

    for (int i = 0; i < word.length(); i++) {
        std::string next = current + word[i];
        std::string remaining = word.substr(0, i) + word.substr(i + 1);
        generateWords(remaining, next, result);
    }
}

int main() {
    int n;
    std::cin >> n;

    for (int i = 0; i < n; i++) {
        std::string input;
        std::cin >> input;

        std::transform(input.begin(), input.end(), input.begin(), ::tolower); // Convert input to lowercase
        std::sort(input.begin(), input.end()); // Sort the input word

        std::vector<std::string> result;
        generateWords(input, "", result);

        std::sort(result.begin(), result.end()); // Sort the generated words

        for (const auto& word : result) {
            std::cout << word << std::endl;
        }
    }

    return 0;
}