#include <iostream>
#include <vector>
#include <iomanip>

struct Player {
    std::string name;
    int round1;
    int round2;
    int round3;
    int round4;
    int totalScore;
    double moneyWon;
};

bool comparePlayers(Player &p1, Player &p2) {
    if (p1.totalScore != p2.totalScore) {
        return p1.totalScore < p2.totalScore;
    } else {
        if (p1.round1 + p1.round2 + p1.round3 + p1.round4 != p2.round1 + p2.round2 + p2.round3 + p2.round4) {
            return p1.round1 + p1.round2 + p1.round3 + p1.round4 < p2.round1 + p2.round2 + p2.round3 + p2.round4;
        } else {
            return p1.name < p2.name;
        }
    }
}

int main() {
    int cases;
    std::cin >> cases;

    for (int i = 0; i < cases; i++) {
        double purse;
        std::cin >> purse;

        std::vector<double> percentages(71);
        for (int j = 0; j < 71; j++) {
            std::cin >> percentages[j];
        }

        int numOfPlayers;
        std::cin >> numOfPlayers;

        std::vector<Player> players(numOfPlayers);

        for (int j = 0; j < numOfPlayers; j++) {
            std::string name;
            int round1, round2, round3, round4;

            std::cin >> name >> round1 >> round2 >> round3 >> round4;

            Player player{name, round1, round2, round3, round4, round1 + round2 + round3 + round4, 0};
            players[j] = player;
        }

        std::sort(players.begin(), players.end(), comparePlayers);

        for (size_t j = 0; j < players.size(); j++) {
            players[j].moneyWon = purse * percentages[j];
        }

        std::cout << "Player Name Place RD1 RD2 RD3 RD4 TOTAL Money Won" << std::endl;
        std::cout << "---------------------------------------------------------------" << std::endl;

        int count = 1;
        for (size_t j = 0; j < players.size(); j++) {
            if (players[j].name.back() != '*') {
                if (j > 0 && players[j].totalScore != players[j - 1].totalScore) {
                    count = j + 1;
                }
                std::cout << std::setw(20) << players[j].name;
                std::cout << std::setw(6) << count;
                std::cout << std::setw(4) << players[j].round1;
                std::cout << std::setw(4) << players[j].round2;
                std::cout << std::setw(4) << players[j].round3;
                std::cout << std::setw(4) << players[j].round4;
                std::cout << std::setw(6) << players[j].totalScore;
                std::cout << std::fixed << std::setprecision(2) << "$" << std::setw(10) << players[j].moneyWon << std::endl;
            }
        }

        std::cout << std::endl;
    }

    return 0;
}