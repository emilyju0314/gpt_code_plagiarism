#include <iostream>
#include <vector>
#include <string>

using namespace std;

int calculateArea(vector<string> &picture) {
    int area = 0;
    int h = picture.size();
    int w = picture[0].length();

    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            if (picture[i][j] == '/' || picture[i][j] == '\\') {
                area += 1;
            }
        }
    }

    return area;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int h, w;
        cin >> h >> w;

        vector<string> picture(h);
        for (int i = 0; i < h; i++) {
            cin >> picture[i];
        }

        int area = calculateArea(picture);
        cout << area << endl;
    }

    return 0;
}