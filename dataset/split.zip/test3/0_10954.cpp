#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N;
    while (std::cin >> N) {
        if (N == 0) {
            break;
        }
        
        std::vector<int> nums(N);
        for (int i = 0; i < N; i++) {
            std::cin >> nums[i];
        }
        
        std::sort(nums.begin(), nums.end());
        
        int totalCost = 0;
        while (nums.size() > 1) {
            int sum = nums[0] + nums[1];
            totalCost += sum;
            nums.erase(nums.begin());
            nums[0] = sum;
            std::sort(nums.begin(), nums.end());
        }
        
        std::cout << totalCost << std::endl;
    }
    
    return 0;
}