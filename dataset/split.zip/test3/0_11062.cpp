#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

bool isAlphabet(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

std::string toLowerCase(std::string str) {
    for (int i = 0; i < str.size(); i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') {
            str[i] = str[i] + 32; // converting uppercase to lowercase
        }
    }
    return str;
}

int main() {
    std::vector<std::string> words;
    std::string line;
    
    while (getline(std::cin, line)) {
        std::istringstream iss(line);
        std::string word;

        while (iss >> word) {
            std::string cleanWord = "";
            bool hyphenated = false;

            for (char c : word) {
                if (isAlphabet(c)) {
                    cleanWord += c;
                } else if (c == '-') {
                    cleanWord += c;
                    hyphenated = true;
                }
            }
            if (hyphenated) {
                continue;
            }

            cleanWord = toLowerCase(cleanWord);

            if (!cleanWord.empty()) {
                words.push_back(cleanWord);
            }
        }
    }

    std::sort(words.begin(), words.end());

    for (std::string word : words) {
        std::cout << word << std::endl;
    }

    return 0;
}