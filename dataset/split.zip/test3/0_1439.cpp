#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<pair<char, char>> processes(n);
    for(int i = 0; i < n; i++) {
        cin >> processes[i].first >> processes[i].second;
    }

    unordered_map<char, char> resourceOrder;

    int maxLength = 0;

    for(int i = 0; i < n; i++) {
        resourceOrder[processes[i].first] = processes[i].second;

        for(int j = i+1; j < n; j++) {
            if(processes[i].second == processes[j].first) {
                maxLength = max(maxLength, j-i);
            }
        }
    }

    cout << maxLength << endl;

    for(int i = 0; i < n; i++) {
        cout << processes[i].first << " " << resourceOrder[processes[i].first] << endl;
    }

    return 0;
}