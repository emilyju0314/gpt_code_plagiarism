#include <iostream>
#include <algorithm>
#include <vector>

int calculate(int a, int b, char op) {
    if(op == '+') {
        return a + b;
    } else if(op == '-') {
        return a - b;
    } else if(op == '*') {
        return a * b;
    }
    return 0;
}

bool findExpression(std::vector<int>& nums) {
    std::sort(nums.begin(), nums.end());
    
    do {
        for(char op1 : {'+', '-', '*'}) {
            for(char op2 : {'+', '-', '*'}) {
                for(char op3 : {'+', '-', '*'}) {
                    for(char op4 : {'+', '-', '*'}) {
                        if(calculate(calculate(calculate(calculate(nums[0], nums[1], op1), nums[2], op2), nums[3], op3), nums[4], op4) == 23) {
                            return true;
                        }
                    }
                }
            }
        }
    } while(std::next_permutation(nums.begin(), nums.end()));
    
    return false;
}

int main() {
    int a1, a2, a3, a4, a5;
    
    while(std::cin >> a1 >> a2 >> a3 >> a4 >> a5) {
        if(a1 == 0 && a2 == 0 && a3 == 0 && a4 == 0 && a5 == 0) {
            break;
        }
        
        std::vector<int> nums = {a1, a2, a3, a4, a5};
        
        if(findExpression(nums)) {
            std::cout << "Possible" << std::endl;
        } else {
            std::cout << "Impossible" << std::endl;
        }
    }
    
    return 0;
}