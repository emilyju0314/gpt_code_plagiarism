#include <iostream>
#include <vector>
#include <unordered_set>

// Function to transform the grid according to the given rules
std::vector<std::vector<int>> transformGrid(const std::vector<std::vector<int>>& grid) {
    int rows = grid.size();
    int cols = grid[0].size();

    std::vector<std::vector<int>> transformedGrid(rows, std::vector<int>(cols, 0));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int sum = 0;
            if (i > 0) sum += grid[i-1][j]; // Top cell
            if (j > 0) sum += grid[i][j-1]; // Left cell
            if (i < rows-1) sum += grid[i+1][j]; // Bottom cell
            if (j < cols-1) sum += grid[i][j+1]; // Right cell

            transformedGrid[i][j] = sum % 2;
        }
    }

    return transformedGrid;
}

int main() {
    int numTestCases;
    std::cin >> numTestCases;

    for (int t = 0; t < numTestCases; t++) {
        std::vector<std::vector<int>> grid(3, std::vector<int>(3, 0));

        // Input grid
        for (int i = 0; i < 3; i++) {
            std::string row;
            std::cin >> row;
            for (int j = 0; j < 3; j++) {
                grid[i][j] = row[j] - '0';
            }
        }

        std::unordered_set<std::vector<std::vector<int>>> seen;
        int idx = 0;

        // Transform the grid recursively and keep track of seen grids
        while (seen.find(grid) == seen.end()) {
            seen.insert(grid);
            grid = transformGrid(grid);
            idx++;
        }

        // Output the result for this test case
        if (seen.size() == idx) {
            std::cout << idx - 1 << std::endl;
        } else {
            std::cout << -1 << std::endl;
        }
    }

    return 0;
}