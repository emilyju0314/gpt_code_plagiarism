#include <iostream>
#include <cmath>

int next_2_3(int m) {
    int exp2 = 0, exp3 = 0;
    while (m % 2 == 0) {
        m /= 2;
        exp2++;
    }
    while (m % 3 == 0) {
        m /= 3;
        exp3++;
    }
    
    return pow(2, exp2) * pow(3, exp3);
}

int main() {
    int m;
    
    while (true) {
        std::cin >> m;
        if (m == 0) {
            break;
        }
        
        int result = next_2_3(m);
        std::cout << result << std::endl;
    }
    
    return 0;
}