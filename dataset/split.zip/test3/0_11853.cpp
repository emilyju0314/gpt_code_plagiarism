#include <iostream>
#include <vector>
#include <iomanip>

struct Opponent {
    double x;
    double y;
    double range;
};

int main() {
    int numScenarios;
    std::cin >> numScenarios;

    for (int i = 0; i < numScenarios; ++i) {
        int numOpponents;
        std::cin >> numOpponents;

        std::vector<Opponent> opponents(numOpponents);

        for (int j = 0; j < numOpponents; ++j) {
            std::cin >> opponents[j].x >> opponents[j].y >> opponents[j].range;
        }

        double minX = 1000.0;
        double maxX = 0.0;
        double minY = 1000.0;
        double maxY = 0.0;

        for (int j = 0; j < numOpponents; ++j) {
            double x1 = opponents[j].x - opponents[j].range;
            double x2 = opponents[j].x + opponents[j].range;
            double y1 = opponents[j].y - opponents[j].range;
            double y2 = opponents[j].y + opponents[j].range;

            if (x1 < minX) minX = x1;
            if (x2 > maxX) maxX = x2;
            if (y1 < minY) minY = y1;
            if (y2 > maxY) maxY = y2;
        }

        if (minX <= 0 && maxX >= 1000 && minY <= 0 && maxY >= 1000) {
            std::cout << std::fixed << std::setprecision(2) << "0.00 1000.00 1000.00 " << maxY << std::endl;
        } else {
            std::cout << "IMPOSSIBLE" << std::endl;
        }
    }

    return 0;
}