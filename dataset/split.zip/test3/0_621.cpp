#include <iostream>
#include <string>

bool isPositive(std::string input) {
    if (input == "1" || input == "4" || input == "78") {
        return true;
    }
    return false;
}

bool isNegative(std::string input) {
    if (input == "35") {
        return true;
    }
    return false;
}

bool isFailed(std::string input) {
    if (input.substr(input.size() - 3) == "94") {
        return true;
    }
    return false;
}

bool isNotCompleted(std::string input) {
    if (input.substr(0, 3) == "190") {
        return true;
    }
    return false;
}

int main() {
    int n;
    std::cin >> n;

    for (int i = 0; i < n; i++) {
        std::string input;
        std::cin >> input;

        if (isPositive(input)) {
            std::cout << "+" << std::endl;
        } else if (isNegative(input)) {
            std::cout << "-" << std::endl;
        } else if (isFailed(input)) {
            std::cout << "*" << std::endl;
        } else if (isNotCompleted(input)) {
            std::cout << "?" << std::endl;
        } else {
            std::cout << "+" << std::endl; // default to positive if none of the conditions are met
        }
    }

    return 0;
}