#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct DamagedSection {
    int location;
    int repairCost;
    int increaseCost;
};

int calculateMinRepairCost(int n, int v, int x, vector<DamagedSection> sections) {
    sort(sections.begin(), sections.end(), [](DamagedSection a, DamagedSection b) {
        return abs(a.location - x) < abs(b.location - x);
    });

    int totalTime = 0;
    for (int i = 0; i < n; i++) {
        totalTime += abs(sections[i].location - x) / v;
        x = sections[i].location;
    }

    int totalCost = 0;
    for (int i = 0; i < n; i++) {
        totalCost += sections[i].repairCost + totalTime * sections[i].increaseCost;
    }

    return totalCost;
}

int main() {
    int n, v, x;
    cin >> n >> v >> x;

    while (n != 0 || v != 0 || x != 0) {
        vector<DamagedSection> sections(n);
        for (int i = 0; i < n; i++) {
            cin >> sections[i].location >> sections[i].repairCost >> sections[i].increaseCost;
        }

        int minRepairCost = calculateMinRepairCost(n, v, x, sections);
        cout << minRepairCost << endl;

        cin >> n >> v >> x;
    }

    return 0;
}