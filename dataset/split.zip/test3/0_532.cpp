#include <iostream>
#include <queue>
#include <tuple>

using namespace std;

int main() {
    int L, R, C;
    while (cin >> L >> R >> C) {
        if (L == 0 && R == 0 && C == 0) {
            break;
        }

        char dungeon[L][R][C];
        int startLevel = -1, startX = -1, startY = -1;
        int endLevel = -1, endX = -1, endY = -1;

        for (int i = 0; i < L; i++) {
            for (int j = 0; j < R; j++) {
                for (int k = 0; k < C; k++) {
                    cin >> dungeon[i][j][k];
                    if (dungeon[i][j][k] == 'S') {
                        startLevel = i;
                        startX = j;
                        startY = k;
                    } else if (dungeon[i][j][k] == 'E') {
                        endLevel = i;
                        endX = j;
                        endY = k;
                    }
                }
            }
        }

        int dx[] = {-1, 1, 0, 0, 0, 0};
        int dy[] = {0, 0, -1, 1, 0, 0};
        int dz[] = {0, 0, 0, 0, -1, 1};

        queue<tuple<int, int, int, int>> q;
        q.push(make_tuple(startLevel, startX, startY, 0));

        bool escaped = false;
        int minute = 0;

        while (!q.empty()) {
            int level, x, y, time;
            tie(level, x, y, time) = q.front();
            q.pop();

            if (level == endLevel && x == endX && y == endY) {
                escaped = true;
                minute = time;
                break;
            }

            for (int i = 0; i < 6; i++) {
                int newLevel = level + dz[i];
                int newX = x + dx[i];
                int newY = y + dy[i];
                if (newLevel >= 0 && newLevel < L && newX >= 0 && newX < R && newY >= 0 && newY < C && dungeon[newLevel][newX][newY] != '#') {
                    q.push(make_tuple(newLevel, newX, newY, time + 1));
                    dungeon[newLevel][newX][newY] = '#';
                }
            }
        }

        if (escaped) {
            cout << "Escaped in " << minute << " minute(s)." << endl;
        } else {
            cout << "Trapped!" << endl;
        }
    }

    return 0;
}