#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n;
    while (true) {
        cin >> n;
        if (n == 0) {
            cout << "*" << endl;
            break;
        }

        vector<pair<int, int>> blocks(n);
        for (int i = 0; i < n; i++) {
            cin >> blocks[i].first >> blocks[i].second;
        }

        int tallestBlocks = 0;
        for (int i = 0; i < n; i++) {
            bool isTallest = true;
            for (int j = 0; j < n; j++) {
                if (blocks[i].first < blocks[j].first || blocks[i].second < blocks[j].second) {
                    isTallest = false;
                    break;
                }
            }
            if (isTallest) {
                tallestBlocks++;
            }
        }

        cout << tallestBlocks << endl;
    }

    return 0;
}