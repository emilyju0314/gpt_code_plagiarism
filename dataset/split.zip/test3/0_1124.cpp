#include<iostream>
using namespace std;

int main() {
    int value;
    char symbol;

    while(cin >> symbol >> value) {
        cout << symbol << " = " << value << endl;
    }

    return 0;
}