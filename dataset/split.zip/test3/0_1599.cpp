#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

const int INF = 1e9;

int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<pair<int, int>>> adj(n+1);
    for (int i = 0; i < m; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        adj[a].push_back({b, c});
        adj[b].push_back({a, c});
    }

    vector<int> dist(n+1, INF);
    vector<int> color(n+1);
    vector<int> parent(n+1);

    dist[1] = 0;
    queue<int> q;
    q.push(1);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (auto edge : adj[u]) {
            int v = edge.first;
            int c = edge.second;
            if (dist[u] + 1 < dist[v] || (dist[u] + 1 == dist[v] && c < color[v])) {
                dist[v] = dist[u] + 1;
                color[v] = c;
                parent[v] = u;
                q.push(v);
            }
        }
    }

    vector<int> path;
    int cur = n;
    while (cur != 1) {
        path.push_back(color[cur]);
        cur = parent[cur];
    }
    reverse(path.begin(), path.end());

    cout << path.size() << endl;
    for (int c : path) {
        cout << c << " ";
    }

    return 0;
}