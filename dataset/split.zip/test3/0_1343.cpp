#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> center = {7, 8, 11, 12, 13, 16, 17, 18};

bool isCenterSame(vector<int>& blocks) {
    int target = blocks[center[0] - 1];
    for(int i = 1; i < center.size(); i++) {
        if(blocks[center[i] - 1] != target) {
            return false;
        }
    }
    return true;
}

void printMoves(int moveIndex) {
    switch(moveIndex) {
        case 0: cout << "A"; break;
        case 1: cout << "B"; break;
        case 2: cout << "C"; break;
        case 3: cout << "D"; break;
        case 4: cout << "E"; break;
        case 5: cout << "F"; break;
        case 6: cout << "G"; break;
        case 7: cout << "H"; break;
    }
}

void rotateBlocks(vector<int>& blocks, int moveIndex) {
    vector<int> temp = blocks;
    int start = 0 + 7 * moveIndex;
    for(int i = 0; i < 7; i++) {
        blocks[start + i] = temp[start + (i + 1) % 7];
    }
    blocks[start + 6] = temp[start];
}

int main() {
    vector<vector<int>> initialConfigurations;
    vector<vector<int>> finalConfigurations;
    string line;
    
    while(getline(cin, line) && line != "0") {
        istringstream iss(line);
        vector<int> blocks;
        int num;
        while(iss >> num) {
            blocks.push_back(num);
        }
        initialConfigurations.push_back(blocks);
        
        while(getline(cin, line) && line[0] != '0') {
            istringstream iss(line);
            vector<int> fblocks;
            int fnum;
            while(iss >> fnum) {
                fblocks.push_back(fnum);
            }
            finalConfigurations.push_back(fblocks);
        }
    }
    
    for(int t = 0; t < initialConfigurations.size(); t++) {
        vector<int> blocks = initialConfigurations[t];
        vector<int> fblocks = finalConfigurations[t];
        bool solved = false;
        
        for(int i = 0; i < 256; i++) {
            vector<int> tempBlocks = blocks;
            for(int j = 0; j < 8; j++) {
                if(isCenterSame(tempBlocks)) {
                    solved = true;
                    break;
                }
                rotateBlocks(tempBlocks, j);
            }
            if(solved) {
                cout << "Case " << (t + 1) << ":\n";
                for(int j = 0; j < 8; j++) {
                    printMoves((i >> (3 * j)) & 7);
                }
                cout << endl;
                cout << tempBlocks[7] << endl;
                break;
            }
        }
        
        if(!solved) {
            cout << "No moves needed\n";
            cout << blocks[7] << endl;
        }
    }
    
    return 0;
}