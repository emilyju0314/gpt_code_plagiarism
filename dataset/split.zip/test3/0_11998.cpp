#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> parent;
vector<int> rank_;
vector<int> treasure;

int find(int x) {
    if (parent[x] != x) {
        parent[x] = find(parent[x]);
    }
    return parent[x];
}

void unite(int x, int y) {
    x = find(x);
    y = find(y);

    if (x != y) {
        if (rank_[x] < rank_[y]) {
            swap(x, y);
        }
        parent[y] = x;
        treasure[x] = (treasure[x] * treasure[y]) % k;
        if (rank_[x] == rank_[y]) {
            rank_[x]++;
        }
    }
}

int main() {
    int n, m, k;
    while (cin >> n >> m >> k) {
        parent.resize(n + 1);
        rank_.assign(n + 1, 0);
        treasure.resize(n + 1);
        for (int i = 1; i <= n; i++) {
            cin >> treasure[i];
            parent[i] = i;
        }

        int last_output = 0;
        for (int i = 0; i < m; i++) {
            int op, x, y, v;
            cin >> op >> x >> y >> v;
            x = (x + last_output) % n + 1;
            y = (y + last_output) % n + 1;
            v = (v + last_output) % k;

            if (op == 1) {
                unite(x, y);
            } else if (op == 2) {
                int root_x = find(x);
                treasure[root_x] = v;
            } else if (op == 3) {
                vector<int> path;
                bool exist_path = false;
                while (x != y) {
                    if (x == 0) {
                        break;
                    }
                    path.push_back(x);
                    x = find(parent[x]);
                }
                path.push_back(y);

                int count = 0, product = 1;
                for (int j = path.size() - 1; j >= 0; j--) {
                    if (treasure[path[j]] <= v) {
                        count++;
                        product = (product * treasure[path[j]]) % k;
                    }
                }

                last_output = count == 0 ? 0 : count * product % k;
                cout << count << " " << last_output << endl;
            }
        }
    }

    return 0;
}