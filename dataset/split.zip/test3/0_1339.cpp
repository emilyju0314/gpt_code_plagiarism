#include <iostream>
#include <string>

std::string decryptSubstitutionCipher(const std::string& encryptedMessage) {
    std::string decryptedMessage = encryptedMessage;
    for (char& c : decryptedMessage) {
        if (c != 'A') {
            c = c - 1;
        } else {
            c = 'Z';
        }
    }
    return decryptedMessage;
}

std::string decryptPermutationCipher(const std::string& encryptedMessage) {
    std::string decryptedMessage = encryptedMessage;
    std::string permutation = "21543761098";
    for (int i = 0; i < permutation.length(); i++) {
        decryptedMessage[i] = encryptedMessage[permutation[i] - '0' - 1];
    }
    return decryptedMessage;
}

int main() {
    std::string encryptedMessage, originalMessage;

    while (std::cin >> encryptedMessage >> originalMessage) {
        std::string decryptedMessage = decryptPermutationCipher(decryptSubstitutionCipher(encryptedMessage));
        
        if (decryptedMessage == originalMessage) {
            std::cout << "YES" << std::endl;
        } else {
            std::cout << "NO" << std::endl;
        }
    }

    return 0;
}