#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int E;
    cin >> E;

    vector<vector<int>> friends(E);
    for (int i = 0; i < E; i++) {
        int N;
        cin >> N;
        friends[i].resize(N);
        for (int j = 0; j < N; j++) {
            cin >> friends[i][j];
        }
    }

    int T;
    cin >> T;

    while (T--) {
        int source;
        cin >> source;

        vector<bool> visited(E, false);
        queue<int> q;
        q.push(source);
        visited[source] = true;

        int maxBoomSize = 0, maxBoomDay = 0, day = 1;

        while (!q.empty()) {
            int size = q.size();
            if (size > maxBoomSize) {
                maxBoomSize = size;
                maxBoomDay = day;
            }

            for (int i = 0; i < size; i++) {
                int current = q.front();
                q.pop();

                for (int friend : friends[current]) {
                    if (!visited[friend]) {
                        q.push(friend);
                        visited[friend] = true;
                    }
                }
            }

            day++;
        }

        if (maxBoomSize == 1) {
            cout << "0" << endl;
        } else {
            cout << maxBoomSize << " " << maxBoomDay << endl;
        }
    }

    return 0;
}