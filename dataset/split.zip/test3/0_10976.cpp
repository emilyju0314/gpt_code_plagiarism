#include <iostream>
#include <vector>
#include <algorithm>
#include <tuple>
#include <cmath>

using namespace std;

vector<tuple<int, int, int>> findPairs(int k) {
    vector<tuple<int, int, int>> result;

    for (int y = 2; y <= k * 2; y++) {
        int x = k * y / (y - k);
        if ((k * y) % (y - k) == 0 && x >= y) {
            result.push_back(make_tuple(x, y, k));
        }
    }

    return result;
}

int main() {
    int k;
    while (cin >> k) {
        vector<tuple<int, int, int>> pairs = findPairs(k);

        cout << pairs.size() << endl;
        for (auto pair : pairs) {
            int x = get<0>(pair);
            int y = get<1>(pair);
            k = get<2>(pair);
            cout << "1/" << k << " = 1/" << x << " + 1/" << y << endl;
        }
    }

    return 0;
}