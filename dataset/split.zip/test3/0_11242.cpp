#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

int main() {
    int f, r;
    
    while (true) {
        cin >> f;
        
        if (f == 0) {
            break;
        }
        
        cin >> r;
        
        vector<int> front(f);
        vector<int> rear(r);
        
        for (int i = 0; i < f; i++) {
            cin >> front[i];
        }
        
        for (int i = 0; i < r; i++) {
            cin >> rear[i];
        }
        
        vector<double> ratios;
        
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < r; j++) {
                ratios.push_back((double)rear[j] / front[i]);
            }
        }
        
        sort(ratios.begin(), ratios.end());
        
        double max_spread = 0;
        
        for (int i = 0; i < ratios.size() - 1; i++) {
            max_spread = max(max_spread, ratios[i+1] / ratios[i]);
        }
        
        cout << fixed << setprecision(2) << max_spread << endl;
    }
    
    return 0;
}