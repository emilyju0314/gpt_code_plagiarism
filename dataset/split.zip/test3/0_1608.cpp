#include <iostream>
#include <vector>
#include <unordered_set>

bool isNonBoring(const std::vector<int>& sequence) {
    std::unordered_set<int> uniqueElements;

    for(int i = 0; i < sequence.size(); ++i) {
        if(uniqueElements.find(sequence[i]) != uniqueElements.end()) {
            return false;
        }
        uniqueElements.insert(sequence[i]);
    }

    return true;
}

int main() {
    int T;
    std::cin >> T;

    for(int t = 0; t < T; ++t) {
        int n;
        std::cin >> n;
        std::vector<int> sequence(n);

        for(int i = 0; i < n; ++i) {
            std::cin >> sequence[i];
        }

        if(isNonBoring(sequence)) {
            std::cout << "non-boring" << std::endl;
        } else {
            std::cout << "boring" << std::endl;
        }
    }

    return 0;
}