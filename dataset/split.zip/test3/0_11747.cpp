#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Edge {
    int u, v, w;
};

bool compareEdges(const Edge& e1, const Edge& e2) {
    return e1.w < e2.w;
}

int findParent(int node, vector<int>& parent) {
    if (parent[node] == node) {
        return node;
    }
    return parent[node] = findParent(parent[node], parent);
}

void unionNodes(int u, int v, vector<int>& parent) {
    int pu = findParent(u, parent);
    int pv = findParent(v, parent);
    parent[pu] = pv;
}

vector<int> findHeaviestEdges(vector<Edge>& edges, int n) {
    vector<int> heaviestEdges;
    sort(edges.begin(), edges.end(), compareEdges);
    
    vector<int> parent(n);
    for (int i = 0; i < n; i++) {
        parent[i] = i;
    }
    
    for (int i = 0; i < edges.size(); i++) {
        int u = edges[i].u;
        int v = edges[i].v;
        
        int pu = findParent(u, parent);
        int pv = findParent(v, parent);
        
        if (pu != pv) {
            unionNodes(u, v, parent);
        } else {
            heaviestEdges.push_back(edges[i].w);
        }
    }
    
    return heaviestEdges;
}

int main() {
    int n, m;
    while (cin >> n >> m && n != 0 && m != 0) {
        vector<Edge> edges(m);
        for (int i = 0; i < m; i++) {
            cin >> edges[i].u >> edges[i].v >> edges[i].w;
        }
        
        vector<int> heaviestEdges = findHeaviestEdges(edges, n);
        
        if (heaviestEdges.empty()) {
            cout << "forest" << endl;
        } else {
            for (int i = 0; i < heaviestEdges.size(); i++) {
                cout << heaviestEdges[i] << " ";
            }
            cout << endl;
        }
    }
    
    return 0;
}