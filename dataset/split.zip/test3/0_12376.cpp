#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Node {
    int id;
    int value;
    vector<int> children;
};

int main() {
    int T;
    cin >> T;
    
    for (int t = 1; t <= T; t++) {
        int n, m;
        cin >> n >> m;
        
        vector<Node> graph(n);
        
        for (int i = 0; i < n; i++) {
            cin >> graph[i].value;
            graph[i].id = i;
        }
        
        for (int i = 0; i < m; i++) {
            int u, v;
            cin >> u >> v;
            graph[u].children.push_back(v);
        }
        
        vector<int> totalValues(n, 0);
        vector<int> endNodes(n, 0);
        
        for (int i = n-2; i >= 0; i--) {
            int maxVal = 0;
            int nextNode = -1;
            for (int child : graph[i].children) {
                if (totalValues[child] > maxVal) {
                    maxVal = totalValues[child];
                    nextNode = child;
                }
            }
            totalValues[i] = graph[i].value + maxVal;
            endNodes[i] = nextNode;
        }
        
        int maxTotal = totalValues[0];
        int endNode = endNodes[0];
        
        cout << "Case " << t << ": " << maxTotal << " " << endNode << endl;
    }
    
    return 0;
}