#include <iostream>
#include <string>
#include <map>

int main() {
    int testCases;
    std::cin >> testCases;

    for (int i = 0; i < testCases; i++) {
        int numPaidChars;
        std::cin >> numPaidChars;

        std::map<char, int> paidChars;
        char ch;
        int value;

        for (int j = 0; j < numPaidChars; j++) {
            std::cin >> ch >> value;
            paidChars[ch] = value;
        }

        int numLines;
        std::cin >> numLines;
        std::cin.ignore(); // Ignore the newline character

        double totalPayment = 0;

        for (int j = 0; j < numLines; j++) {
            std::string line;
            std::getline(std::cin, line);

            for (char c : line) {
                totalPayment += paidChars[c];
            }
        }

        int dollars = totalPayment / 100;
        int cents = ((int)totalPayment) % 100;

        std::cout << dollars << ".";
        if (cents < 10) {
            std::cout << "0";
        }
        std::cout << cents << "$" << std::endl;
    }

    return 0;
}