#include <iostream>
#include <queue>
#include <map>

struct Node {
    int value;
    Node* left;
    Node* right;

    Node(int val) : value(val), left(nullptr), right(nullptr) {}
};

void levelOrderTraversal(Node* root) {
    if (!root) {
        return;
    }

    std::queue<Node*> q;
    q.push(root);

    while (!q.empty()) {
        Node* current = q.front();
        std::cout << current->value << " ";
        q.pop();

        if (current->left) {
            q.push(current->left);
        }
        if (current->right) {
            q.push(current->right);
        }
    }
}

Node* buildTree(std::vector<std::pair<int, std::string>> nodes) {
    std::map<std::string, Node*> pathToNode;

    Node* root = nullptr;

    for (auto& node : nodes) {
        Node* newNode = new Node(node.first);

        if (!root) {
            root = newNode;
            pathToNode[""] = root;
        } else {
            std::string path = node.second;
            Node* parent = pathToNode[path.substr(0, path.size() - 1)];
            if (path.back() == 'L') {
                parent->left = newNode;
            } else {
                parent->right = newNode;
            }
            pathToNode[path] = newNode;
        }
    }

    return root;
}

int main() {
    std::string line;
    while (getline(std::cin, line)) {
        std::vector<std::pair<int, std::string>> nodes;
        while (line != "()") {
            int value;
            std::string path;
            char temp;
            std::istringstream iss(line);

            iss >> temp; // (
            iss >> value;
            iss >> temp; // ,
            iss >> temp; // R or L
            if (temp != ')') {
                iss >> path; // R or L path
            }

            nodes.emplace_back(value, path);

            getline(std::cin, line);
        }

        Node* root = buildTree(nodes);
        
        bool complete = true;

        // Check if the tree is completely specified
        std::map<std::string, Node*> pathToNode;
        std::queue<Node*> q;
        q.push(root);

        while (!q.empty()) {
            Node* current = q.front();
            q.pop();

            if (pathToNode.find(current->path) != pathToNode.end()) {
                complete = false;
                break;
            } else {
                pathToNode[current->path] = current;
            }

            if (current->left) {
                q.push(current->left);
            }
            if (current->right) {
                q.push(current->right);
            }
        }

        if (complete) {
            levelOrderTraversal(root);
        } else {
            std::cout << "not complete";
        }
        
        std::cout << std::endl;
    }

    return 0;
}