#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main() {
    int N;
    
    while (cin >> N) {
        if (N == 0) {
            break;
        }
        
        vector<string> cards(13);
        
        for (int i = 0; i < N; i++) {
            string card;
            string value, suit;
            
            cin >> value >> suit;
            
            card = value + suit;
            
            int index;
            
            if (value == "A") {
                index = 0;
            } else if (value == "2") {
                index = 1;
            } else if (value == "3") {
                index = 2;
            } else if (value == "4") {
                index = 3;
            } else if (value == "5") {
                index = 4;
            } else if (value == "6") {
                index = 5;
            } else if (value == "7") {
                index = 6;
            } else if (value == "8") {
                index = 7;
            } else if (value == "9") {
                index = 8;
            } else if (value == "T") {
                index = 9;
            } else if (value == "J") {
                index = 10;
            } else if (value == "Q") {
                index = 11;
            } else if (value == "K") {
                index = 12;
            }
            
            cards[index] = card;
        }
        
        int start_index = 11;

        for (int i = 0; i < 13; i++) {
            cout << cards[start_index] << " ";
            start_index = (start_index + 1) % 13;
        }

        cout << endl;
    }
    
    return 0;
}