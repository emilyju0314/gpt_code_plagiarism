#include <bits/stdc++.h>

using namespace std;

int main() {
    char c;
    while (scanf("%c", &c) != EOF) {
        printf("%c", c);
    }
    return 0;
}

/*
Author : bumpy (-_-)
date : 30-Nov-2016
*/
