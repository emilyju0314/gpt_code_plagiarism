#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for(int i = 1; i <= T; i++) {
        int N;
        cin >> N;

        vector<int> creature_speeds(N);
        for(int j = 0; j < N; j++) {
            cin >> creature_speeds[j];
        }

        int min_speed = *max_element(creature_speeds.begin(), creature_speeds.end());
        cout << "Case " << i << ": " << min_speed << endl;
    }

    return 0;
}