#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Object {
    int price;
    int weight;
};

int maxValue(int N, vector<Object>& objects, int G, vector<int>& maxWeights) {
    vector<vector<int>> dp(G + 1, vector<int>(31, 0));

    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= G; j++) {
            dp[j][objects[i - 1].weight] = max(dp[j][objects[i - 1].weight], dp[j - 1][30]);
            
            for (int k = objects[i - 1].weight; k <= 30; k++) {
                dp[j][k] = max(dp[j][k], dp[j - 1][k - objects[i - 1].weight] + objects[i - 1].price);
            }
        }
    }

    int result = 0;
    for (int j = 1; j <= G; j++) {
        for (int k = 1; k <= 30; k++) {
            result = max(result, dp[j][k]);
        }
    }

    return result;
}

int main() {
    int T;
    cin >> T;

    while (T--) {
        int N;
        cin >> N;

        vector<Object> objects(N);
        for (int i = 0; i < N; i++) {
            cin >> objects[i].price >> objects[i].weight;
        }

        int G;
        cin >> G;

        vector<int> maxWeights(G);
        for (int i = 0; i < G; i++) {
            cin >> maxWeights[i];
        }

        int result = maxValue(N, objects, G, maxWeights);
        cout << result << endl;
    }

    return 0;
}