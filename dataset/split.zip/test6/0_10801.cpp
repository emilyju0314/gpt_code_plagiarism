#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int num_test_cases;
    cin >> num_test_cases;

    for (int t = 0; t < num_test_cases; t++) {
        int n, k;
        cin >> n >> k;

        vector<int> elevator_times(n);
        vector<vector<int>> elevator_floors(n);

        for (int i = 0; i < n; i++) {
            cin >> elevator_times[i];
        }

        for (int i = 0; i < n; i++) {
            int num_floors;
            cin >> num_floors;

            for (int j = 0; j < num_floors; j++) {
                int floor;
                cin >> floor;
                elevator_floors[i].push_back(floor);
            }
        }

        vector<int> dp(k + 1, INT_MAX);
        dp[0] = 0;

        for (int i = 0; i <= k; i++) {
            for (int j = 0; j < n; j++) {
                for (int floor : elevator_floors[j]) {
                    if (floor <= i) {
                        dp[i] = min(dp[i], dp[floor] + abs(floor - i) * elevator_times[j]);
                    } else {
                        break;
                    }
                }
            }
        }

        if (dp[k] == INT_MAX) {
            cout << "IMPOSSIBLE" << endl;
        } else {
            cout << dp[k] << endl;
        }
    }

    return 0;
}