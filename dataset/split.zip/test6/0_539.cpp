#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int longestRoad(int n, vector<vector<int>>& edges, vector<int>& visited, int current_node) {
    visited[current_node] = 1;
    int max_len = 0;
    for (int i = 0; i < edges.size(); i++) {
        if (edges[i][0] == current_node && visited[edges[i][1]] == 0) {
            max_len = max(max_len, 1 + longestRoad(n, edges, visited, edges[i][1]));
        }
        if (edges[i][1] == current_node && visited[edges[i][0]] == 0) {
            max_len = max(max_len, 1 + longestRoad(n, edges, visited, edges[i][0]));
        }
    }
    visited[current_node] = 0;
    return max_len;
}

int main() {
    int n, m;
    cin >> n >> m;
    
    while (n != 0 && m != 0) {
        vector<vector<int>> edges(m, vector<int>(2));
        vector<int> visited(n, 0);
        
        for (int i = 0; i < m; i++) {
            cin >> edges[i][0] >> edges[i][1];
        }
        
        int longest_road = 0;
        for (int i = 0; i < n; i++) {
            longest_road = max(longest_road, longestRoad(n, edges, visited, i));
        }

        cout << longest_road << endl;

        cin >> n >> m;
    }
    
    return 0;
}