#include <iostream>
#include <vector>
#include <algorithm>

bool isPerfectCube(int a, int b, int c, int d) {
    return a*a*a == b*b*b + c*c*c + d*d*d;
}

int main() {
    std::vector<std::tuple<int, int, int, int>> results;

    for (int a = 1; a <= 200; a++) {
        for (int b = 1; b <= 200; b++) {
            for (int c = b; c <= 200; c++) {
                for (int d = c; d <= 200; d++) {
                    if (isPerfectCube(a, b, c, d)) {
                        results.push_back(std::make_tuple(a, b, c, d));
                    }
                }
            }
        }
    }

    // Sort the results based on the criteria mentioned in the prompt
    std::sort(results.begin(), results.end());

    // Output the results
    for (auto result : results) {
        int a, b, c, d;
        std::tie(a, b, c, d) = result;
        std::cout << "Cube = " << a << ", Triple = (" << b << "," << c << "," << d << ")" << std::endl;
    }

    return 0;
}