#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

bool isValidWord(string word) {
    for (int i = 0; i < word.length() - 1; i++) {
        if (word[i] >= word[i+1]) {
            return false;
        }
    }
    return true;
}

void findWords(vector<string>& board, int row, int col, string word, set<string>& words) {
    if (row < 0 || col < 0 || row >= board.size() || col >= board[0].length()) {
        return;
    }
    
    word += board[row][col];
    if (word.length() >= 3) {
        words.insert(word);
    }
    
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) {
                continue;
            }
            findWords(board, row + i, col + j, word, words);
        }
    }
}

int main() {
    int T;
    cin >> T;
    
    for (int t = 0; t < T; t++) {
        int N;
        cin >> N;
        
        vector<string> board(N);
        for (int i = 0; i < N; i++) {
            cin >> board[i];
        }
        
        set<string> words;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                findWords(board, i, j, "", words);
            }
        }
        
        vector<string> validWords;
        for (auto word : words) {
            if (isValidWord(word)) {
                validWords.push_back(word);
            }
        }
        
        sort(validWords.begin(), validWords.end());
        
        for (auto word : validWords) {
            cout << word << endl;
        }
        
        if (t != T-1) {
            cout << endl;
        }
    }
    
    return 0;
}