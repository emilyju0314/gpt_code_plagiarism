#include <iostream>
#include <string>

int f(int n) {
    int sum = 0;
    while(n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

int g(int n) {
    while(n >= 10) {
        n = f(n);
    }
    return n;
}

int main() {
    int n;
    std::cin >> n;
    
    while(n != 0) {
        std::cout << g(n) << std::endl;
        std::cin >> n;
    }
    
    return 0;
}