#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int N, M;
    while (cin >> N >> M) {
        if (N == 0 && M == 0) break;
        
        vector<vector<int>> graph(N+1);
        vector<vector<int>> reversedGraph(N+1);
        
        for (int i = 0; i < M; i++) {
            int V, W, P;
            cin >> V >> W >> P;
            graph[V].push_back(W);
            reversedGraph[W].push_back(V);
            if (P == 2) {
                graph[W].push_back(V);
                reversedGraph[V].push_back(W);
            }
        }
        
        vector<bool> visited(N+1, false);
        
        queue<int> q;
        q.push(1);
        visited[1] = true;
        
        while (!q.empty()) {
            int current = q.front();
            q.pop();
            for (int neighbor : graph[current]) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }
        
        bool connected = true;
        for (int i = 1; i <= N; i++) {
            if (!visited[i]) {
                connected = false;
                break;
            }
        }
        
        cout << (connected ? 1 : 0) << endl;
    }
    
    return 0;
}