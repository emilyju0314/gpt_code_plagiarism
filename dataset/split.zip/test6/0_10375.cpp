#include <iostream>
#include <iomanip>

using namespace std;

int factorial(int n) {
    if (n <= 1) {
        return 1;
    }
    return n * factorial(n - 1);
}

double binomialCoefficient(int m, int n) {
    return factorial(m) / (factorial(m - n) * factorial(n));
}

int main() {
    int p, q, r, s;
    
    while (cin >> p >> q >> r >> s) {
        double result = binomialCoefficient(p, q) / binomialCoefficient(r, s);
        cout << fixed << setprecision(5) << result << endl;
    }
    
    return 0;
}