#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;

struct State {
    int a, b;
    string action;
};

bool visited[1001][1001] = {false};

void bfs(int ca, int cb, int n) {
    queue<State> q;
    q.push({0, 0, ""});
    
    while (!q.empty()) {
        State cur = q.front();
        q.pop();
        
        if (visited[cur.a][cur.b]) {
            continue;
        }
        
        visited[cur.a][cur.b] = true;
        
        if (cur.b == n) {
            cout << cur.action << endl;
            cout << "success" << endl;
            return;
        }
        
        // Fill A
        if (cur.a < ca) {
            q.push({ca, cur.b, cur.action + "fill A\n"});
        }
        
        // Fill B
        if (cur.b < cb) {
            q.push({cur.a, cb, cur.action + "fill B\n"});
        }
        
        // Empty A
        if (cur.a > 0) {
            q.push({0, cur.b, cur.action + "empty A\n"});
        }
        
        // Empty B
        if (cur.b > 0) {
            q.push({cur.a, 0, cur.action + "empty B\n"});
        }
        
        // Pour A to B
        int pourAmt = min(cur.a, cb - cur.b);
        if (pourAmt > 0) {
            q.push({cur.a - pourAmt, cur.b + pourAmt, cur.action + "pour A B\n"});
        }
        
        // Pour B to A
        pourAmt = min(cur.b, ca - cur.a);
        if (pourAmt > 0) {
            q.push({cur.a + pourAmt, cur.b - pourAmt, cur.action + "pour B A\n"});
        }
    }
}

int main() {
    int ca, cb, n;
    
    // Assume input is valid
    while (cin >> ca >> cb >> n) {
        bfs(ca, cb, n);
    }
    
    return 0;
}