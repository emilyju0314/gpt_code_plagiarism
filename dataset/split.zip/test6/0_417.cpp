#include <iostream>
#include <string>

int getPosition(std::string word) {
    int position = 0;
    int n = word.size();
    
    if (n == 1) {
        position = word[0] - 'a' + 1;
    } else if (n > 1 && n <= 5) {
        position = (word[0] - 'a' + 1);
        for (int i = 1; i < n; i++) {
            position += (word[i] - 'a' + 1) - (word[i-1] - 'a');
        }
    }
    
    return position;
}

int main() {
    std::string word;
    
    while (std::cin >> word) {
        if (word.size() > 5) {
            std::cout << "0" << std::endl;
        } else {
            int position = getPosition(word);
            std::cout << position << std::endl;
        }
    }
    
    return 0;
}