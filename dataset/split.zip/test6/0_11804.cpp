#include <iostream>
#include <vector>
#include <algorithm>

struct Player {
    std::string name;
    int attackingAbility;
    int defensiveAbility;
};

bool comparePlayers(Player p1, Player p2) {
    return p1.attackingAbility > p2.attackingAbility;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        std::vector<Player> players(10);
        for (int i = 0; i < 10; i++) {
            std::cin >> players[i].name >> players[i].attackingAbility >> players[i].defensiveAbility;
        }

        std::sort(players.begin(), players.end(), comparePlayers);

        std::vector<Player> attackers(players.begin(), players.begin() + 5);
        std::vector<Player> defenders(players.begin() + 5, players.end());

        std::sort(attackers.begin(), attackers.end(), [](Player p1, Player p2) {
            return p1.name < p2.name;
        });

        std::sort(defenders.begin(), defenders.end(), [](Player p1, Player p2) {
            return p1.name < p2.name;
        });

        std::cout << "Case " << t << ":\n";

        std::cout << "(";
        for (int i = 0; i < 5; i++) {
            std::cout << attackers[i].name;
            if (i < 4) {
                std::cout << ",";
            }
        }
        std::cout << ")\n";
        
        std::cout << "(";
        for (int i = 0; i < 5; i++) {
            std::cout << defenders[i].name;
            if (i < 4) {
                std::cout << ",";
            }
        }
        std::cout << ")\n";
    }

    return 0;
}