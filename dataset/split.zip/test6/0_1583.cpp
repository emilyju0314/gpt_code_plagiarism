#include <iostream>
#include <string>

int digitSum(int n) {
    int sum = n;
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

int findSmallestGenerator(int n) {
    for (int i = 1; i < n; i++) {
        if (n == digitSum(i)) {
            return i;
        }
    }
    return 0;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 0; t < T; t++) {
        int N;
        std::cin >> N;
        int generator = findSmallestGenerator(N);
        std::cout << generator << std::endl;
    }

    return 0;
}