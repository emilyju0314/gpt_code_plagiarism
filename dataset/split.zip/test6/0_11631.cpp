#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Edge {
    int u, v, weight;
};

bool operator<(Edge a, Edge b) {
    return a.weight > b.weight;
}

int find(vector<int> &parent, int x) {
    if (parent[x] == x) {
        return x;
    }
    return parent[x] = find(parent, parent[x]);
}

void unite(vector<int> &parent, int x, int y) {
    x = find(parent, x);
    y = find(parent, y);
    if (x != y) {
        parent[y] = x;
    }
}

int main() {
    int m, n;
    while (cin >> m >> n && m != 0 && n != 0) {
        vector<Edge> edges(n);
        vector<int> parent(m);
        for (int i = 0; i < m; i++) {
            parent[i] = i;
        }
        
        for (int i = 0; i < n; i++) {
            int x, y, z;
            cin >> x >> y >> z;
            edges[i] = {x, y, z};
        }
        
        sort(edges.begin(), edges.end());
        
        int total = 0;
        for (int i = 0; i < n; i++) {
            if (find(parent, edges[i].u) != find(parent, edges[i].v)) {
                unite(parent, edges[i].u, edges[i].v);
            } else {
                total += edges[i].weight;
            }
        }
        
        cout << total << endl;
    }
    
    return 0;
}