#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n, d;
        cin >> n >> d;

        vector<int> h(n);
        for (int i = 0; i < n; i++) {
            cin >> h[i];
        }

        int total_diff = 0;
        for (int i = 0; i < n-1; i++) {
            if (h[i+1] > h[i]) {
                int diff = h[i+1] - h[i];
                if (diff > d) {
                    int stones_to_add = diff / d;
                    total_diff += stones_to_add;
                    h[i+1] -= stones_to_add * d;
                }
            } else if (h[i+1] < h[i]) {
                int diff = h[i] - h[i+1];
                if (diff > d) {
                    int stones_to_add = diff / d;
                    total_diff += stones_to_add;
                    h[i] -= stones_to_add * d;
                }
            }
        }

        bool possible = true;
        for (int i = 0; i < n-1; i++) {
            if (abs(h[i+1] - h[i]) > d) {
                possible = false;
                break;
            }
        }

        if (possible) {
            cout << total_diff << endl;
        } else {
            cout << "impossible" << endl;
        }
    }

    return 0;
}