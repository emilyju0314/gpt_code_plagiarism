#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int findMinDays(vector<vector<int>> tree) {
    int n = tree.size();
    vector<int> in_degree(n, 0); // store the in-degree of each node
    // calculate in-degrees
    for (int i = 0; i < n; i++) {
        for (int j : tree[i]) {
            in_degree[j]++;
        }
    }
    queue<int> q;
    for (int i = 0; i < n; i++) {
        if (in_degree[i] == 0) {
            q.push(i);
        }
    }
    int days = 0;
    while (!q.empty()) {
        int size = q.size();
        for (int i = 0; i < size; i++) {
            int node = q.front();
            q.pop();
            for (int j : tree[node]) {
                in_degree[j]--;
                if (in_degree[j] == 0) {
                    q.push(j);
                }
            }
        }
        days++;
    }

    return days;
}

int main() {
    vector<vector<int>> tree;
    vector<int> nodes;
    string line;
    while (getline(cin, line)) {
        if (line == "0") {
            tree.push_back(nodes);
            if (tree.size() % 2 == 0) {
                cout << findMinDays(tree) << endl;
                tree.clear();
            }
            nodes.clear();
        } else {
            int num;
            char direction;
            istringstream iss(line);
            while (iss >> num >> noskipws >> direction) {
                nodes.push_back(num);
            }
        }
    }

    return 0;
}