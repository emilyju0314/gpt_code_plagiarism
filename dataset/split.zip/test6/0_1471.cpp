#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int longestIncreasingSequence(vector<int>& heights) {
    int n = heights.size();
    vector<int> dp(n, 1);
    int maxLength = 1;

    for(int i = 1; i < n; i++) {
        if(heights[i] > heights[i-1]) {
            dp[i] = dp[i-1] + 1;
        }
        maxLength = max(maxLength, dp[i]);
    }

    return maxLength;
}

int main() {
    int Z;
    cin >> Z;

    while(Z--) {
        int n;
        cin >> n;
        vector<int> heights(n);

        for(int i = 0; i < n; i++) {
            cin >> heights[i];
        }

        cout << longestIncreasingSequence(heights) << endl;
    }

    return 0;
}