#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int caseNumber = 1;
    
    while (true) {
        int N, T;
        cin >> N;
        if (N == 0) break;
        
        cin >> T;
        
        vector<int> travelTimes(N-1);
        for (int i = 0; i < N-1; i++) {
            cin >> travelTimes[i];
        }
        
        int M1, M2;
        cin >> M1;
        vector<int> departuresFromFirst(M1);
        for (int i = 0; i < M1; i++) {
            cin >> departuresFromFirst[i];
        }
        
        cin >> M2;
        vector<int> departuresFromLast(M2);
        for (int i = 0; i < M2; i++) {
            cin >> departuresFromLast[i];
        }
        
        bool foundSolution = false;
        int minWaitingTime = INT_MAX;
        
        for (int i = 0; i < M1; i++) {
            for (int j = 0; j < M2; j++) {
                int currentTime = departuresFromFirst[i];
                int totalWaitingTime = 0;
                for (int k = 0; k < N-1; k++) {
                    totalWaitingTime += max(0, (currentTime + travelTimes[k]) - departuresFromFirst[i]);
                    currentTime += travelTimes[k];
                }
                totalWaitingTime += max(0, T - currentTime);
                
                if (currentTime <= T) {
                    minWaitingTime = min(minWaitingTime, totalWaitingTime);
                    foundSolution = true;
                }
            }
        }
        
        if (foundSolution) {
            cout << "Case Number " << caseNumber << ": " << minWaitingTime << endl;
        } else {
            cout << "Case Number " << caseNumber << ": impossible" << endl;
        }
        
        caseNumber++;
    }
    
    return 0;
}