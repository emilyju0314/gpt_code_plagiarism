#include <iostream>
#include <cmath>
using namespace std;

bool isSquare(int n) {
    int root = sqrt(n);
    return root * root == n;
}

int main() {
    int T;
    cin >> T;

    while (T--) {
        int N;
        cin >> N;

        if (N == 1) {
            cout << -1 << endl;
            continue;
        }

        int ballsPlaced = 0;
        for (int i = 1; i <= N * (N - 1) / 2; i++) {
            if (!isSquare(i)) {
                ballsPlaced++;
            }
        }

        cout << ballsPlaced << endl;
    }

    return 0;
}