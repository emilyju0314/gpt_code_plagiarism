#include <iostream>
#include <unordered_map>
#include <sstream>

int main() {
    std::unordered_map<int, int> frequency;
    std::string input;
    
    std::getline(std::cin, input);
    std::istringstream iss(input);
    
    int num;
    while (iss >> num) {
        frequency[num]++;
    }
    
    for (auto const& pair : frequency) {
        std::cout << pair.first << " " << pair.second << std::endl;
    }
    
    return 0;
}