#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Statement {
    string type;
    char variable;
    int constant;
};

struct Program {
    vector<Statement> statements;
    int current_statement;
    int program_id;
};

int main() {
    int num_cases;
    cin >> num_cases;

    for (int case_num = 1; case_num <= num_cases; case_num++) {
        int num_programs;
        int unit_execution_times[5];
        int time_quantum;
        cin >> num_programs >> unit_execution_times[0] >> unit_execution_times[1] >> unit_execution_times[2] >> unit_execution_times[3] >> unit_execution_times[4] >> time_quantum;

        queue<Program> ready_queue;
        queue<Program> blocked_queue;
        vector<int> variables(26, 0);

        for (int i = 1; i <= num_programs; i++) {
            Program new_program;
            new_program.program_id = i;
            string line;
            while (getline(cin, line)) {
                if (line == "end") {
                    break;
                }

                Statement new_statement;
                if (line.find("print") != string::npos) {
                    new_statement.type = "print";
                    new_statement.variable = line[line.find("print") + 6];
                } else if (line.find("lock") != string::npos) {
                    new_statement.type = "lock";
                } else if (line.find("unlock") != string::npos) {
                    new_statement.type = "unlock";
                } else {
                    new_statement.type = "assignment";
                    new_statement.variable = line[0];
                    new_statement.constant = stoi(line.substr(line.find("=") + 2));
                }

                new_program.statements.push_back(new_statement);
            }

            ready_queue.push(new_program);
        }

        while (!ready_queue.empty()) {
            Program current_program = ready_queue.front();
            ready_queue.pop();

            while (current_program.current_statement < current_program.statements.size()) {
                Statement current_statement = current_program.statements[current_program.current_statement];

                if (current_statement.type == "print") {
                    cout << current_program.program_id << ": " << variables[current_statement.variable - 'a'] << endl;
                } else if (current_statement.type == "assignment") {
                    variables[current_statement.variable - 'a'] = current_statement.constant;
                } else if (current_statement.type == "lock") {
                    if (blocked_queue.empty()) {
                        // Nothing in blocked queue, continue
                    } else {
                        ready_queue.push(current_program);
                        break;
                    }
                } else if (current_statement.type == "unlock") {
                    if (!blocked_queue.empty()) {
                        Program unblocked_program = blocked_queue.front();
                        blocked_queue.pop();
                        ready_queue.push(unblocked_program);
                    }
                }

                current_program.current_statement++;

                // Check time quantum
                if ((current_program.current_statement + 1) % time_quantum == 0) {
                    ready_queue.push(current_program);
                    break;
                }
            }
        }

        if (case_num < num_cases) {
            cout << endl;
        }
    }

    return 0;
}