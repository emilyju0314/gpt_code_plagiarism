#include <iostream>
#include <string>
#include <unordered_map>

using namespace std;

unordered_map<string, char> keyToChar;

void initializeKeyToChar(string header) {
    int keyLength = 1;
    int headerIndex = 0;

    for (int i = 0; i < header.length(); i++) {
        string key = bitset<8>(headerIndex).to_string().substr(8 - keyLength);

        keyToChar[key] = header[i];

        headerIndex++;
        if (headerIndex == pow(2, keyLength)) {
            keyLength++;
        }
    }
}

void decodeMessage(string message) {
    string segment = "";
    int i = 0;

    while (i < message.length()) {
        string segmentLength = message.substr(i, 3);
        int keyLength = stoi(segmentLength, nullptr, 2);
        i += 3;

        if (keyLength == 0) {
            break;
        }

        while (true) {
            string key = message.substr(i, keyLength);
            i += keyLength;

            if (key == string(keyLength, '1')) {
                break;
            }

            cout << keyToChar[key];
        }
    }
    cout << endl;
}

int main() {
    string header, message;

    while (getline(cin, header)) {
        initializeKeyToChar(header);
        getline(cin, message);

        decodeMessage(message);
    }

    return 0;
}