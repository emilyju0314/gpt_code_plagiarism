#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 0; t < T; t++) {
        int N;
        cin >> N;

        vector<int> durations(N);
        for (int i = 0; i < N; i++) {
            cin >> durations[i];
        }

        int totalMileCost = 0;
        int totalJuiceCost = 0;

        for (int i = 0; i < N; i++) {
            totalMileCost += (durations[i] / 30) * 10;
            if (durations[i] % 30 != 0) {
                totalMileCost += 10;
            }

            totalJuiceCost += (durations[i] / 60) * 15;
            if (durations[i] % 60 != 0) {
                totalJuiceCost += 15;
            }
        }

        cout << "Case " << t+1 << ": ";
        if (totalMileCost < totalJuiceCost) {
            cout << "Mile " << totalMileCost << endl;
        } else if (totalJuiceCost < totalMileCost) {
            cout << "Juice " << totalJuiceCost << endl;
        } else {
            cout << "Mile Juice " << totalMileCost << endl;
        }
    }

    return 0;
}