#include<iostream>
#include<bitset>

int main() {
    unsigned int num1, num2;
    
    while(std::cin >> num1 >> num2) {
        unsigned int sum = num1 ^ num2;
        unsigned int carry = (num1 & num2) << 1;

        while (carry != 0) {
            unsigned int temp = sum;
            sum = sum ^ carry;
            carry = (temp & carry) << 1;
        }
        
        std::bitset<32> result(sum);
        std::cout << result.to_ulong() << std::endl;
    }
    
    return 0;
}