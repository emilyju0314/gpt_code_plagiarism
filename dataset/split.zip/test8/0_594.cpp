#include <iostream>
#include <bitset>

int main() {
    int input;

    while (std::cin >> input) {
        // Convert input integer to opposite-endian machine representation
        int oppositeEndian = 0;
        for (int i = 0; i < 4; i++) {
            oppositeEndian <<= 8;
            oppositeEndian |= (input & 0xFF);
            input >>= 8;
        }

        // Print the input integer and its opposite-endian representation
        std::cout << input << " converts to " << oppositeEndian << std::endl;
    }

    return 0;
}