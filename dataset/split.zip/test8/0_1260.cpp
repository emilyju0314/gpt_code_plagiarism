#include <iostream>
#include <vector>

int main() {
    int T;
    std::cin >> T;

    for(int t = 0; t < T; t++) {
        int n;
        std::cin >> n;

        std::vector<int> dailySales(n);
        for(int i = 0; i < n; i++) {
            std::cin >> dailySales[i];
        }

        int sum = 0;
        for(int i = 1; i < n; i++) {
            int count = 0;
            for(int j = 0; j < i; j++) {
                if(dailySales[j] <= dailySales[i]) {
                    count++;
                }
            }
            sum += count;
        }

        std::cout << sum << std::endl;
    }

    return 0;
}