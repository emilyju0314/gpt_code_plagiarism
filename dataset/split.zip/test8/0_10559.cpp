#include <iostream>
#include <vector>
#include <algorithm>

int getHighestScore(int n, std::vector<int>& colors) {
    int score = 0;
    
    for(int i = 0; i < n; i++) {
        int left = i - 1, right = i + 1;
        int numSame = 1;
        
        while(left >= 0 && colors[left] == colors[i]) {
            numSame++;
            left--;
        }
        
        while(right < n && colors[right] == colors[i]) {
            numSame++;
            right++;
        }
        
        score = std::max(score, numSame * numSame);
    }
    
    return score;
}

int main() {
    int t;
    std::cin >> t;
    
    for(int i = 1; i <= t; i++) {
        int n;
        std::cin >> n;
        
        std::vector<int> colors(n);
        for(int j = 0; j < n; j++) {
            std::cin >> colors[j];
        }
        
        int highestScore = getHighestScore(n, colors);
        
        std::cout << "Case " << i << ": " << highestScore << std::endl;
    }
    
    return 0;
}