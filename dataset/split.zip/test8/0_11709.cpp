#include <iostream>
#include <vector>
#include <map>
#include <set>

using namespace std;

int findGroup(map<string, set<string>>& trustMap, string person, set<string>& visited) {
    visited.insert(person);
    int groupSize = 1;
    for (auto it = trustMap[person].begin(); it != trustMap[person].end(); ++it) {
        if (visited.find(*it) == visited.end()) {
            groupSize += findGroup(trustMap, *it, visited);
        }
    }
    return groupSize;
}

int main() {
    int P, T;
    while (cin >> P >> T && P != 0 && T != 0) {
        map<string, set<string>> trustMap;
        for (int i = 0; i < P; i++) {
            string person;
            cin >> person;
            trustMap[person] = set<string>();
        }

        for (int i = 0; i < T; i++) {
            string person1, person2;
            cin >> person1 >> person2;
            trustMap[person1].insert(person2);
        }

        int minGroups = 0;
        set<string> visited;
        for (auto it = trustMap.begin(); it != trustMap.end(); ++it) {
            if (visited.find(it->first) == visited.end()) {
                minGroups++;
                findGroup(trustMap, it->first, visited);
            }
        }

        cout << minGroups << endl;
    }
    return 0;
}