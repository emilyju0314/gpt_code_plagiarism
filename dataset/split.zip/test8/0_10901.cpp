#include <iostream>
#include <queue>

using namespace std;

int main() {
    int c;
    cin >> c;

    for (int testcase = 0; testcase < c; ++testcase) {
        int n, t, m;
        cin >> n >> t >> m;

        queue<pair<int, string>> leftBank, rightBank;
        for (int i = 0; i < m; ++i) {
            int arrivalTime;
            string bank;
            cin >> arrivalTime >> bank;
            if (bank == "left") {
                leftBank.push(make_pair(arrivalTime, bank));
            } else {
                rightBank.push(make_pair(arrivalTime, bank));
            }
        }

        int currentTime = 0;
        bool onLeftBank = true;

        while (!leftBank.empty() || !rightBank.empty()) {
            int loadedCars = 0;
            int nextArrivalTime = INT_MAX;
            if (onLeftBank) {
                while (!leftBank.empty() && leftBank.front().first <= currentTime && loadedCars < n) {
                    cout << currentTime + t << endl;
                    leftBank.pop();
                    loadedCars++;
                }
                if (loadedCars > 0 || (!leftBank.empty() && leftBank.front().first <= currentTime)) {
                    currentTime += t;
                    onLeftBank = false;
                } else {
                    nextArrivalTime = leftBank.empty() ? INT_MAX : leftBank.front().first;
                }
            } else {
                while (!rightBank.empty() && rightBank.front().first <= currentTime && loadedCars < n) {
                    cout << currentTime + t << endl;
                    rightBank.pop();
                    loadedCars++;
                }
                if (loadedCars > 0 || (!rightBank.empty() && rightBank.front().first <= currentTime)) {
                    currentTime += t;
                    onLeftBank = true;
                } else {
                    nextArrivalTime = rightBank.empty() ? INT_MAX : rightBank.front().first;
                }
            }
            currentTime = max(currentTime, nextArrivalTime);
        }

        if (testcase < c-1) {
            cout << endl;
        }
    }

    return 0;
}