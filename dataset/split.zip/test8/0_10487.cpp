#include <iostream>
#include <vector>
#include <cmath>

int main() {
    int caseNumber = 1;
    while (true) {
        int n;
        std::cin >> n;
        if (n == 0) {
            break;
        }
        
        std::vector<int> nums(n);
        for (int i = 0; i < n; i++) {
            std::cin >> nums[i];
        }
        
        int m;
        std::cin >> m;
        std::cout << "Case " << caseNumber << ":\n";
        
        for (int i = 0; i < m; i++) {
            int query;
            std::cin >> query;
            int closestSum = nums[0] + nums[1];
            int closestDiff = std::abs(query - closestSum);
            
            for (int j = 0; j < n; j++) {
                for (int k = j + 1; k < n; k++) {
                    int currentSum = nums[j] + nums[k];
                    int currentDiff = std::abs(query - currentSum);
                    if (currentDiff < closestDiff) {
                        closestDiff = currentDiff;
                        closestSum = currentSum;
                    }
                }
            }
            
            std::cout << "Closest sum to " << query << " is " << closestSum << ".\n";
        }
        
        caseNumber++;
    }
    
    return 0;
}