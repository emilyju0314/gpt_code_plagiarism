#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

int main() {
    while (!cin.eof()) {
        int numPeople;
        cin >> numPeople;
        if (cin.eof()) break;

        vector<string> names(numPeople);
        unordered_map<string, int> netWorth;

        for (int i = 0; i < numPeople; i++) {
            cin >> names[i];
            netWorth[names[i]] = 0;
        }

        for (int i = 0; i < numPeople; i++) {
            string giverName;
            int money, numRecipients;
            cin >> giverName >> money >> numRecipients;

            if (numRecipients != 0) {
                int giftAmount = money / numRecipients;
                netWorth[giverName] -= giftAmount * numRecipients;

                for (int j = 0; j < numRecipients; j++) {
                    string recipientName;
                    cin >> recipientName;
                    netWorth[recipientName] += giftAmount;
                }
            }
        }

        for (auto name : names) {
            cout << name << " " << netWorth[name] << endl;
        }

        cout << endl;
    }

    return 0;
}