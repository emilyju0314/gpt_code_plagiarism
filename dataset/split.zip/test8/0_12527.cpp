#include <iostream>
#include <string>
using namespace std;

bool hasRepeatedDigits(int num) {
    string s = to_string(num);
    for (int i = 0; i < s.length(); i++) {
        for (int j = i + 1; j < s.length(); j++) {
            if (s[i] == s[j]) {
                return true;
            }
        }
    }
    return false;
}

int countNonRepeatedDigits(int N, int M) {
    int count = 0;
    for (int i = N; i <= M; i++) {
        if (!hasRepeatedDigits(i)) {
            count++;
        }
    }
    return count;
}

int main() {
    int N, M;
    while (cin >> N >> M) {
        cout << countNonRepeatedDigits(N, M) << endl;
    }
    return 0;
}