#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int numCases;
    cin >> numCases;

    for (int c = 0; c < numCases; c++) {
        int altitudes;
        vector<int> targets;

        while (cin >> altitudes) {
            targets.push_back(altitudes);
        }

        int n = targets.size();
        vector<int> dp(n, 1);

        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (targets[i] > targets[j] && dp[i] < dp[j] + 1) {
                    dp[i] = dp[j] + 1;
                }
            }
        }

        int maxHits = *max_element(dp.begin(), dp.end());

        cout << "Max hits: " << maxHits << endl;

        for (int i = n - 1; i >= 0; i--) {
            if (dp[i] == maxHits) {
                cout << targets[i] << endl;
                maxHits--;
            }
        }

        if (c != numCases - 1) {
            cout << endl;
        }
    }

    return 0;
}