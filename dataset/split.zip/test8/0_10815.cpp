#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <algorithm>

int main() {
    std::set<std::string> words;
    std::string line;

    // Read input until EOF
    while (std::getline(std::cin, line)) {
        std::transform(line.begin(), line.end(), line.begin(), ::tolower);
        std::istringstream iss(line);
        std::string word;
        while (iss >> word) {
            std::string cleaned_word;
            for (char c : word) {
                if (isalpha(c)) {
                    cleaned_word += c;
                }
            }
            if (!cleaned_word.empty()) {
                words.insert(cleaned_word);
            }
        }
    }

    // Print the sorted distinct words
    for (const std::string& word : words) {
        std::cout << word << std::endl;
    }

    return 0;
}