#include <iostream>
#include <vector>

struct ACM {
    int x, y, type;
};

int main() {
    int N;
    
    while (true) {
        std::cin >> N;
        if (N == 0) {
            break;
        }
        
        std::vector<ACM> particles(N);
        for (int i = 0; i < N; i++) {
            std::cin >> particles[i].x >> particles[i].y >> particles[i].type;
        }
        
        int maxDissolvedParticles = 0;
        for (int i = 0; i < N; i++) {
            int hydrophilicParticles = 0;
            int hydrophobicParticles = 0;
            
            for (int j = 0; j < N; j++) {
                if ((particles[i].type == 0 && particles[j].type == 0) ||
                    (particles[i].type == 1 && particles[j].type == 1)) {
                    continue;
                }
                
                int dy = particles[j].y - particles[i].y;
                int dx = particles[j].x - particles[i].x;
                
                if (dx * particles[i].y - dy * particles[i].x < 0) {
                    hydrophilicParticles += particles[j].type == 0;
                    hydrophobicParticles += particles[j].type == 1;
                }
            }
            
            maxDissolvedParticles = std::max(maxDissolvedParticles, std::max(hydrophilicParticles, hydrophobicParticles));
        }
        
        std::cout << maxDissolvedParticles << std::endl;
    }
    
    return 0;
}