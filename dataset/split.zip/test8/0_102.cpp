#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int bin1_brown, bin1_green, bin1_clear;
    int bin2_brown, bin2_green, bin2_clear;
    int bin3_brown, bin3_green, bin3_clear;

    while(std::cin >> bin1_brown >> bin1_green >> bin1_clear
                    >> bin2_brown >> bin2_green >> bin2_clear
                    >> bin3_brown >> bin3_green >> bin3_clear) {
        
        std::vector<std::pair<std::string, int>> moves;
        
        // Calculate total number of movements for each possible bin color configuration
        moves.push_back(std::make_pair("BCG", bin2_brown + bin3_brown + bin1_clear + bin3_clear + bin1_green + bin2_green));
        moves.push_back(std::make_pair("BGC", bin2_brown + bin3_brown + bin1_green + bin3_green + bin1_clear + bin2_clear));
        moves.push_back(std::make_pair("CBG", bin2_clear + bin3_clear + bin1_brown + bin3_brown + bin1_green + bin2_green));
        moves.push_back(std::make_pair("CGB", bin2_clear + bin3_clear + bin1_green + bin3_green + bin1_brown + bin2_brown));
        moves.push_back(std::make_pair("GBC", bin2_green + bin3_green + bin1_brown + bin3_brown + bin1_clear + bin2_clear));
        moves.push_back(std::make_pair("GCB", bin2_green + bin3_green + bin1_clear + bin3_clear + bin1_brown + bin2_brown));

        // Find the configuration with the minimum number of movements
        auto min_moves = std::min_element(moves.begin(), moves.end(), [](const std::pair<std::string, int>& p1, const std::pair<std::string, int>& p2) {
            return p1.second < p2.second;
        });

        // Output the minimum movements and the corresponding configuration
        std::cout << min_moves->first << " " << min_moves->second << std::endl;
    }
    
    return 0;
}