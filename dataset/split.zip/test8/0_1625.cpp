#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int T;
    std::cin >> T;

    while (T--) {
        std::string lane1, lane2;
        std::cin >> lane1 >> lane2;

        std::vector<int> count1(26, 0);
        std::vector<int> count2(26, 0);

        for (char c : lane1) {
            count1[c - 'A']++;
        }

        for (char c : lane2) {
            count2[c - 'A']++;
        }

        int sum = 0;

        for (int i = 0; i < 26; i++) {
            sum += std::abs(count1[i] - count2[i]);
        }

        std::cout << sum << std::endl;
    }

    return 0;
}