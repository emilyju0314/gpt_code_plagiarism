#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

struct Hole {
    char character;
    int size;

    bool operator<(const Hole& h) const {
        if (size == h.size) {
            return character < h.character;
        }
        return size > h.size;
    }
};

int main() {
    int problemNum = 1;
    int x, y;
    while (true) {
        cin >> x >> y;
        if (x == 0 && y == 0) {
            break;
        }

        vector<string> map(y);
        for (int i = 0; i < y; i++) {
            cin >> map[i];
        }

        map<char, int> holeSizes;
        for (int i = 0; i < y; i++) {
            for (int j = 0; j < x; j++) {
                if (map[i][j] != '.') {
                    holeSizes[map[i][j]]++;
                }
            }
        }

        vector<Hole> sortedHoles;
        for (auto it = holeSizes.begin(); it != holeSizes.end(); it++) {
            sortedHoles.push_back({it->first, it->second});
        }

        sort(sortedHoles.begin(), sortedHoles.end());

        cout << "Problem " << problemNum << ":" << endl;
        for (int i = 0; i < sortedHoles.size(); i++) {
            cout << sortedHoles[i].character << " " << sortedHoles[i].size << endl;
        }

        problemNum++;
    }

    return 0;
}