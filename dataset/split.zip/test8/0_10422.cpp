#include <iostream>
#include <vector>
#include <queue>
#include <unordered_set>
#include <tuple>

using namespace std;

int dx[] = {-2, -1, 1, 2, 2, 1, -1, -2};
int dy[] = {1, 2, 2, 1, -1, -2, -2, -1};

bool isValid(int x, int y) {
    return (x >= 0 && x < 5 && y >= 0 && y < 5);
}

int bfs(vector<vector<int>>& board) {
    unordered_set<vector<vector<int>>> visited;
    queue<tuple<int, vector<vector<int>, int>>> q;
    
    q.push({0, board});
    visited.insert(board);
    
    while (!q.empty()) {
        auto [moves, curr_board] = q.front();
        q.pop();
        
        if (curr_board == vector<vector<int>>(5, vector<int>(5, -1))) {
            return moves;
        }
        
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (curr_board[i][j] != -1) {
                    for (int k = 0; k < 8; k++) {
                        int new_x = i + dx[k];
                        int new_y = j + dy[k];
                        if (isValid(new_x, new_y) && curr_board[new_x][new_y] == -1) {
                            vector<vector<int>> next_board = curr_board;
                            next_board[new_x][new_y] = next_board[i][j];
                            next_board[i][j] = -1;
                            if (visited.find(next_board) == visited.end()) {
                                q.push({moves + 1, next_board});
                                visited.insert(next_board);
                            }
                        }
                    }
                }
            }
        }
    }
    
    return -1;
}

int main() {
    int N;
    cin >> N;
    
    for (int i = 0; i < N; i++) {
        vector<vector<int>> board(5, vector<int>(5));
        
        for (int j = 0; j < 5; j++) {
            string row;
            cin >> row;
            for (int k = 0; k < 5; k++) {
                if (row[k] == '0') {
                    board[j][k] = 0;
                } else if (row[k] == '1') {
                    board[j][k] = 1;
                } else {
                    board[j][k] = -1;
                }
            }
        }
        
        int result = bfs(board);
        
        if (result == -1) {
            cout << "Unsolvable in less than 11 move(s)." << endl;
        } else {
            cout << "Solvable in " << result << " move(s)." << endl;
        }
    }
    
    return 0;
}