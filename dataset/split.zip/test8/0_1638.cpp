#include <iostream>
#include <vector>
using namespace std;

// Function to calculate the number of arrangements
long long calculateArrangements(int n, int l, int r) {
    vector<vector<long long>> dp(n + 1, vector<long long>(n + 1, 0));
    dp[0][0] = 1;
    
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= i; j++) {
            dp[i][j] = dp[i-1][j-1] + dp[i-1][j]*(i-1);
        }
    }
    
    return dp[n][l] * dp[n][r];
}

int main() {
    int T;
    cin >> T;
    
    while (T--) {
        int n, l, r;
        cin >> n >> l >> r;
        
        long long result = calculateArrangements(n, l, r);
        cout << result << endl;
    }
    
    return 0;
}