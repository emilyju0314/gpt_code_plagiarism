#include <iostream>
#include <vector>
#include <algorithm>

void generateMutations(std::string dna, int k, std::vector<std::string>& mutations, int pos, std::string current) {
    if (pos == dna.length()) {
        if (k == 0) {
            mutations.push_back(current);
        }
        return;
    }

    generateMutations(dna, k, mutations, pos + 1, current + dna[pos]);

    if (k > 0) {
        for (char c : {'A', 'C', 'G', 'T'}) {
            if (c != dna[pos]) {
                generateMutations(dna, k - 1, mutations, pos + 1, current + c);
            }
        }
    }
}

int main() {
    int t;
    std::cin >> t;

    for (int i = 0; i < t; i++) {
        int n, k;
        std::cin >> n >> k;

        std::string dna;
        std::cin >> dna;

        std::vector<std::string> mutations;
        generateMutations(dna, k, mutations, 0, "");

        std::sort(mutations.begin(), mutations.end());

        std::cout << mutations.size() << std::endl;
        for (const std::string& mutated_dna : mutations) {
            std::cout << mutated_dna << std::endl;
        }
    }

    return 0;
}