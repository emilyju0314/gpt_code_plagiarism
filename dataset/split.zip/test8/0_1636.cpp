#include <iostream>
#include <string>

using namespace std;

int main() {
    string pattern;
    
    while (cin >> pattern) {
        int n = pattern.size();
        int emptyChambers = 0;
        
        for (int i = 0; i < n; i++) {
            if (pattern[i] == '0') {
                emptyChambers++;
            }
        }
        
        if (pattern[0] == '0') {
            cout << "ROTATE" << endl;
        } else if (emptyChambers < n) {
            cout << "EQUAL" << endl;
        } else {
            cout << "SHOOT" << endl;
        }
    }
    
    return 0;
}