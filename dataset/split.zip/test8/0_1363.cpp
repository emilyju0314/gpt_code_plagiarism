#include <iostream>
using namespace std;

int calculateSum(int n, int k) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += (k % i);
    }
    return sum;
}

int main() {
    int n, k;
    while (cin >> n >> k) {
        cout << calculateSum(n, k) << endl;
    }
    return 0;
}