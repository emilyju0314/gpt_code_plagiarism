#include <iostream>
#include <vector>

using namespace std;

bool isSafe(vector<pair<pair<int, int>, pair<int, int>>> &rooks, int x, int y) {
    for (int i = 0; i < rooks.size(); i++) {
        if (rooks[i].first.first == x || rooks[i].first.second == y) {
            return false;
        }
    }
    return true;
}

bool placeRooks(vector<pair<pair<int, int>, pair<int, int>>> &rooks, int n) {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (isSafe(rooks, i, j)) {
                rooks.push_back({{i, j}, {i, j}});
                if (rooks.size() == n) {
                    return true;
                }
            }
        }
    }
    return false;
}

int main() {
    int n;
    cin >> n;
    
    while (n != 0) {
        vector<pair<pair<int, int>, pair<int, int>>> rooks;
        
        for (int i = 0; i < n; i++) {
            int x1, y1, x2, y2;
            cin >> x1 >> y1 >> x2 >> y2;
            rooks.push_back({{x1, y1}, {x2, y2}});
        }
        
        if (!placeRooks(rooks, n)) {
            cout << "IMPOSSIBLE" << endl;
        } else {
            for (int i = 0; i < n; i++) {
                cout << rooks[i].first.first << " " << rooks[i].first.second << endl;
            }
        }
        
        cin >> n;
    }
    
    return 0;
}