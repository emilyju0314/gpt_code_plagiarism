#include <iostream>
#include <vector>

using namespace std;

int countStars(vector<string>& sky, int rows, int cols) {
    int stars = 0;
    
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (sky[i][j] == '*') {
                if ((i == 0 || sky[i-1][j] == '.') &&
                    (i == rows-1 || sky[i+1][j] == '.') &&
                    (j == 0 || sky[i][j-1] == '.') &&
                    (j == cols-1 || sky[i][j+1] == '.') &&
                    (i == 0 || j == 0 || sky[i-1][j-1] == '.') &&
                    (i == 0 || j == cols-1 || sky[i-1][j+1] == '.') &&
                    (i == rows-1 || j == 0 || sky[i+1][j-1] == '.') &&
                    (i == rows-1 || j == cols-1 || sky[i+1][j+1] == '.')
                    ) {
                    stars++;
                }
            }
        }
    }

    return stars;
}

int main() {
    int rows, cols;
    
    while (true) {
        cin >> rows >> cols;
        
        if (rows == 0 && cols == 0) {
            break;
        }
        
        vector<string> sky(rows);
        for (int i = 0; i < rows; i++) {
            cin >> sky[i];
        }
        
        int numStars = countStars(sky, rows, cols);
        cout << numStars << endl;
    }

    return 0;
}