#include <iostream>
#include <vector>

using namespace std;

int main() {
    cout << "PERFECTION OUTPUT" << endl;
    
    vector<int> numbers;
    int num;
    
    while (cin >> num && num != 0) {
        numbers.push_back(num);
    }
    
    for (int i = 0; i < numbers.size(); i++) {
        int sum = 0;
        
        for (int j = 1; j <= numbers[i]/2; j++) {
            if (numbers[i] % j == 0) {
                sum += j;
            }
        }
        
        if (sum == numbers[i]) {
            cout << right << setw(5) << numbers[i] << " PERFECT" << endl;
        } else if (sum < numbers[i]) {
            cout << right << setw(5) << numbers[i] << " DEFICIENT" << endl;
        } else {
            cout << right << setw(5) << numbers[i] << " ABUNDANT" << endl;
        }
    }
    
    cout << "END OF OUTPUT" << endl;
    
    return 0;
}