#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

int main() {
    int m;
    cin >> m;

    for (int i = 0; i < m; i++) {
        int n, k;
        cin >> n >> k;
        
        vector<vector<int>> graph(n);
        for (int j = 0; j < k; j++) {
            int n1, n2;
            cin >> n1 >> n2;
            graph[n1-1].push_back(n2-1);
            graph[n2-1].push_back(n1-1);
        }

        unordered_set<int> blackNodes;
        for (int j = 0; j < n; j++) {
            bool canBeBlack = true;
            for (int node : graph[j]) {
                if (blackNodes.count(node) > 0) {
                    canBeBlack = false;
                    break;
                }
            }
            if (canBeBlack) {
                blackNodes.insert(j);
            }
        }

        cout << blackNodes.size() << endl;
        for (int node : blackNodes) {
            cout << node+1 << " ";
        }
        cout << endl;
    }

    return 0;
}