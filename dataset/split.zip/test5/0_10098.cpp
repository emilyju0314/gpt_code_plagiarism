#include <iostream>
#include <string>
#include <algorithm>

void generatePermutations(std::string str, std::string output, int n)
{
    if (output.length() == n)
    {
        std::cout << output << std::endl;
        return;
    }

    for (int i = 0; i < str.length(); i++)
    {
        std::string newStr = str;
        std::string newOutput = output + str[i];
        newStr.erase(i, 1);

        generatePermutations(newStr, newOutput, n);
    }
}

int main()
{
    int n;
    std::cin >> n;

    for (int i = 0; i < n; i++)
    {
        std::string input;
        std::cin >> input;
        std::sort(input.begin(), input.end());
        generatePermutations(input, "", input.length());
        std::cout << std::endl;
    }

    return 0;
}