#include <iostream>
#include <vector>
#include <cmath>

struct Location {
    int street;
    int avenue;
};

int main() {
    int T;
    std::cin >> T;

    for (int t = 0; t < T; t++) {
        int S, A, F;
        std::cin >> S >> A >> F;

        std::vector<Location> friends(F);
        int totalStreet = 0, totalAvenue = 0;

        for (int i = 0; i < F; i++) {
            std::cin >> friends[i].street >> friends[i].avenue;
            totalStreet += friends[i].street;
            totalAvenue += friends[i].avenue;
        }

        int bestStreet = round(totalStreet / double(F));
        int bestAvenue = round(totalAvenue / double(F));

        std::cout << "(Street: " << bestStreet << ", Avenue: " << bestAvenue << ")\n";
    }

    return 0;
}