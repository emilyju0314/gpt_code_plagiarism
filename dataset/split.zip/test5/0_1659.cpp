#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

struct Point {
    int x, y;
    vector<int> connectedPoints;
};

double calculateScore(vector<Point>& points, int n, int x, int y) {
    double length = 0.0;
    int colors = 0;
    
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < points[i].connectedPoints.size(); j++) {
            length += sqrt(pow(points[i].x - points[points[i].connectedPoints[j]].x, 2) + pow(points[i].y - points[points[i].connectedPoints[j]].y, 2));
        }
    }
    
    for(int i = 0; i < n; i++) {
        colors += points[i].connectedPoints.size();
    }
    
    return (length * x) - (colors * y);
}

int main() {
    int caseNum = 1;
    
    while(true) {
        int n, x, y;
        cin >> n;
        
        if(n == 0) {
            break;
        }
        
        cin >> x >> y;
        
        vector<Point> points(n);
        
        for(int i = 0; i < n; i++) {
            cin >> points[i].x >> points[i].y;
            int connectedPoint;
            cin >> connectedPoint;
            
            while(connectedPoint != 0) {
                points[i].connectedPoints.push_back(connectedPoint - 1);
                cin >> connectedPoint;
            }
        }
        
        double score = calculateScore(points, n, x, y);
        
        cout << "Case " << caseNum << ": " << fixed << setprecision(2) << score << endl;
        caseNum++;
    }
    
    return 0;
}