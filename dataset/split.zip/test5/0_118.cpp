#include <iostream>
#include <vector>
#include <string>

class Robot {
public:
    int x, y; // current position
    char orientation; // current orientation (N, S, E, W)

    Robot(int x, int y, char orientation) : x(x), y(y), orientation(orientation) {}

    void turnLeft() {
        switch(orientation) {
            case 'N': orientation = 'W'; break;
            case 'S': orientation = 'E'; break;
            case 'E': orientation = 'N'; break;
            case 'W': orientation = 'S'; break;
        }
    }

    void turnRight() {
        switch(orientation) {
            case 'N': orientation = 'E'; break;
            case 'S': orientation = 'W'; break;
            case 'E': orientation = 'S'; break;
            case 'W': orientation = 'N'; break;
        }
    }

    void moveForward(int maxX, int maxY, std::vector<std::vector<bool>>& scents) {
        int newX = x, newY = y;

        switch(orientation) {
            case 'N': newY++; break;
            case 'S': newY--; break;
            case 'E': newX++; break;
            case 'W': newX--; break;
        }

        if(newX < 0 || newY < 0 || newX > maxX || newY > maxY) {
            if(!scents[x][y]) {
                // robot falls off the edge and leaves a scent
                scents[x][y] = true;
                std::cout << x << " " << y << " " << orientation << " LOST" << std::endl;
            } else {
                // ignore command if there's a scent
                return;
            }
        } else {
            x = newX;
            y = newY;
        }
    }
};

int main() {
    int maxX, maxY;
    std::cin >> maxX >> maxY;

    std::vector<std::vector<bool>> scents(maxX+1, std::vector<bool>(maxY+1, false));

    while(true) {
        int x, y;
        char orientation;
        std::string instructions;

        if(!(std::cin >> x >> y >> orientation >> instructions)) {
            break; // end of input
        }

        Robot robot(x, y, orientation);

        for(char instruction : instructions) {
            switch(instruction) {
                case 'L': robot.turnLeft(); break;
                case 'R': robot.turnRight(); break;
                case 'F': robot.moveForward(maxX, maxY, scents); break;
            }
        }

        std::cout << robot.x << " " << robot.y << " " << robot.orientation << std::endl;
    }

    return 0;
}