#include <iostream>
using namespace std;

int main() {
    int n; // Number of test cases
    cin >> n;

    for (int i = 0; i < n; i++) {
        int f; // Number of farmers
        cin >> f;

        int sum = 0;
        for (int j = 0; j < f; j++) {
            int size, animals, environment;
            cin >> size >> animals >> environment;

            double space_per_animal = (double)size / animals;
            int premium_per_animal = space_per_animal * environment;
            int farmer_premium = premium_per_animal * animals;

            sum += farmer_premium;
        }

        cout << sum << endl;
    }

    return 0;
}