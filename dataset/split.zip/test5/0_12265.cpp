#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

int main() {
    int T;
    cin >> T;

    for(int t = 0; t < T; t++) {
        int n, m;
        cin >> n >> m;

        vector<vector<char>> grid(n, vector<char>(m));

        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                cin >> grid[i][j];
            }
        }

        map<int, int> perimeter_cnt;

        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                if(grid[i][j] == '.') {
                    int right = 1, down = 1;

                    while(j + right < m && grid[i][j + right] == '.') {
                        right++;
                    }

                    while(i + down < n) {
                        int k;
                        for(k = j; k < j + right; k++) {
                            if(grid[i + down][k] == '#') {
                                break;
                            }
                        }

                        if(k != j + right) {
                            break;
                        }

                        down++;
                    }

                    int perimeter = 2 * (right + down - 2);
                    perimeter_cnt[perimeter]++;
                }
            }
        }

        cout << "Case #" << t + 1 << ":" << endl;
        for(auto it = perimeter_cnt.begin(); it != perimeter_cnt.end(); it++) {
            cout << it->first << " x " << it->second << endl;
        }
    }

    return 0;
}