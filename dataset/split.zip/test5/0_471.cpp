#include <iostream>
#include <string>
#include <algorithm>

bool hasRepeatedDigits(int num) {
    std::string numStr = std::to_string(num);
    std::sort(numStr.begin(), numStr.end());
    for (int i = 0; i < numStr.length() - 1; i++) {
        if (numStr[i] == numStr[i + 1]) {
            return true;
        }
    }
    return false;
}

int main() {
    int numTestCases;
    std::cin >> numTestCases;

    for (int i = 0; i < numTestCases; i++) {
        int N;
        std::cin >> N;

        for (int s1 = 1234; s1 < 10000; s1++) {
            for (int s2 = 5678; s2 < 10000; s2++) {
                if (!hasRepeatedDigits(s1) && !hasRepeatedDigits(s2) && s1 % s2 == 0 && s1 / s2 == N) {
                    std::cout << s1 << " / " << s2 << " = " << N << std::endl;
                }
            }
        }
        std::cout << std::endl;
    }

    return 0;
}