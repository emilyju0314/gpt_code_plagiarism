#include <iostream>

using namespace std;

bool isBalanced(int Wl, int Dl, int Wr, int Dr) {
    if (Wl == 0 && Wr == 0) {
        return isBalanced(Dl, Dr);
    } else if (Wl == 0) {
        return Dl * Wl == Dr * Wr;
    } else if (Wr == 0) {
        return Dl * Wl == Dr * Wr;
    } else {
        return Dl * Wl == Dr * Wr;
    }
}

int main() {
    int t;
    cin >> t;
    
    while (t--) {
        int Wl, Dl, Wr, Dr;
        cin >> Wl >> Dl >> Wr >> Dr;
        
        if (isBalanced(Wl, Dl, Wr, Dr)) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
    
    return 0;
}