#include <iostream>
#include <vector>

using namespace std;

int n, m;
vector<vector<int>> constraints;
int count = 0;

bool isValid(vector<int>& arrangement) {
    for (int i = 0; i < m; i++) {
        int a = constraints[i][0];
        int b = constraints[i][1];
        int c = constraints[i][2];

        if (c > 0 && abs(arrangement[a] - arrangement[b]) > c) {
            return false;
        }

        if (c < 0 && abs(arrangement[a] - arrangement[b]) < -c) {
            return false;
        }
    }

    return true;
}

void generateSeatingArrangements(vector<int>& arrangement, vector<bool>& used) {
    if (arrangement.size() == n) {
        if (isValid(arrangement)) {
            count++;
        }
        return;
    }

    for (int i = 0; i < n; i++) {
        if (!used[i]) {
            arrangement.push_back(i);
            used[i] = true;
            generateSeatingArrangements(arrangement, used);
            arrangement.pop_back();
            used[i] = false;
        }
    }
}

int main() {
    while (true) {
        cin >> n >> m;
        if (n == 0 && m == 0) {
            break;
        }

        constraints.resize(m, vector<int>(3));
        for (int i = 0; i < m; i++) {
            cin >> constraints[i][0] >> constraints[i][1] >> constraints[i][2];
        }

        vector<int> arrangement;
        vector<bool> used(n, false);
        count = 0;

        generateSeatingArrangements(arrangement, used);

        cout << count << endl;
    }

    return 0;
}