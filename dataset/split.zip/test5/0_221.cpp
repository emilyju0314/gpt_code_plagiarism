#include <iostream>
#include <vector>
#include <algorithm>

struct Building {
    int id;
    int x;
    int y;
    int width;
    int depth;
    int height;
};

bool compareBuildings(Building b1, Building b2) {
    if (b1.x == b2.x) {
        return b1.y < b2.y;
    }
    return b1.x < b2.x;
}

int main() {
    int map = 1;
    int numBuildings;
    
    while (std::cin >> numBuildings && numBuildings != 0) {
        std::vector<Building> buildings(numBuildings);
        
        for (int i = 0; i < numBuildings; i++) {
            Building b;
            std::cin >> b.x >> b.y >> b.width >> b.depth >> b.height;
            b.id = i + 1;
            buildings[i] = b;
        }

        std::sort(buildings.begin(), buildings.end(), compareBuildings);

        int maxHeight = 0;
        std::vector<int> visibleBuildings;
        
        for (const Building& b : buildings) {
            if (b.height > maxHeight) {
                visibleBuildings.push_back(b.id);
                maxHeight = b.height;
            }
        }

        std::cout << "For map #" << map << ", the visible buildings are numbered as follows:" << std::endl;
        
        for (int i = 0; i < visibleBuildings.size(); i++) {
            std::cout << visibleBuildings[i];
            if (i != visibleBuildings.size() - 1) {
                std::cout << " ";
            }
        }
        
        std::cout << std::endl << std::endl;
        
        map++;
    }

    return 0;
}