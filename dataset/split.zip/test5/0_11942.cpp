#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    int N;
    cin >> N;
    
    cout << "Lumberjacks:" << endl;
    
    for (int i = 0; i < N; i++) {
        int beards[10];
        bool ordered = true;
        bool unordered = true;
        
        for (int j = 0; j < 10; j++) {
            cin >> beards[j];
        }
        
        int sorted_beards[10];
        copy(beards, beards + 10, sorted_beards);
        sort(sorted_beards, sorted_beards + 10);
        
        for (int j = 0; j < 10; j++) {
            if (beards[j] != sorted_beards[j]) {
                ordered = false;
            }
            
            if (beards[j] != sorted_beards[9 - j]) {
                unordered = false;
            }
        }
        
        if (ordered) {
            cout << "Ordered" << endl;
        } else if (unordered) {
            cout << "Unordered" << endl;
        } else {
            cout << "Unordered" << endl;
        }
    }
    
    return 0;
}