#include <iostream>
#include <string>
#include <algorithm>

std::string get_lexicographically_smallest_sequence(const std::string& circular_sequence) {
    std::string smallest_sequence = circular_sequence;
    int n = circular_sequence.length();

    for (int i = 0; i < n; i++) {
        std::string current_sequence = circular_sequence.substr(i) + circular_sequence.substr(0, i);
        if (current_sequence < smallest_sequence) {
            smallest_sequence = current_sequence;
        }
    }

    return smallest_sequence;
}

int main() {
    int T;
    std::cin >> T;

    for (int i = 0; i < T; i++) {
        std::string circular_sequence;
        std::cin >> circular_sequence;

        std::string smallest_sequence = get_lexicographically_smallest_sequence(circular_sequence);
        std::cout << smallest_sequence << std::endl;
    }

    return 0;
}