#include <iostream>
using namespace std;

int main() {
    int C;
    cin >> C;

    for (int i = 0; i < C; i++) {
        int N;
        cin >> N;

        int length = 1, width = 1, height = 1;
        for (int j = 1; j*j*j <= N; j++) {
            if (N % j == 0) {
                length = j;
                width = N / j;
                height = N / (j * j);
            }
        }

        int surfaceArea = 2 * (length * width + width * height + height * length);
        cout << surfaceArea << endl;
    }

    return 0;
}