#include<iostream>
#include<cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    
    for(int i=0; i<T; i++) {
        int a, b, c, d;
        cin >> a >> b >> c >> d;
        
        if(d <= c && (d % __gcd(a,b) == 0 || d % __gcd(a,c) == 0 || d % __gcd(b,c) == 0))
            cout << "0 " << d << endl;
        else {
            int x = abs(d - c);
            int gcd = __gcd(a,b);
            int minWater = min(gcd * (d/gcd), min(abs(d - a), abs(d - b)) + abs(c - x));
            
            cout << x << " " << minWater << endl;
        }
    }
    
    return 0;
}