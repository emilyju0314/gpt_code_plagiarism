#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int findCriticalPlaces(int N, vector<vector<int>>& adjList) {
    int criticalPlaces = 0;
    
    for(int i = 1; i <= N; i++) {
        vector<bool> visited(N+1, false);
        visited[i] = true;
        
        queue<int> q;
        q.push(i);
        
        while(!q.empty()) {
            int cur = q.front();
            q.pop();
            
            for(int neighbor : adjList[cur]) {
                if(!visited[neighbor]) {
                    visited[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }
        
        bool isCritical = false;
        for(int j = 1; j <= N; j++) {
            if(!visited[j]) {
                isCritical = true;
                break;
            }
        }
        
        if(isCritical) {
            criticalPlaces++;
        }
    }
    
    return criticalPlaces;
}

int main() {
    int N;
    
    while(cin >> N && N != 0) {
        vector<vector<int>> adjList(N+1);
        
        for(int i = 1; i <= N; i++) {
            int place, neighbor;
            cin >> place;
            while(cin >> neighbor && neighbor != 0) {
                adjList[place].push_back(neighbor);
            }
        }
        
        int result = findCriticalPlaces(N, adjList);
        cout << result << endl;
    }
    
    return 0;
}