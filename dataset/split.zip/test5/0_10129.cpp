#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>

bool isPossible(std::vector<std::string> words) {
    std::unordered_map<char, int> firstLetterCount, lastLetterCount;
    
    for (const std::string& word : words) {
        char firstLetter = word[0];
        char lastLetter = word[word.size() - 1];
        
        firstLetterCount[firstLetter]++;
        lastLetterCount[lastLetter]++;
    }
    
    for (const auto& pair : firstLetterCount) {
        char letter = pair.first;
        if (firstLetterCount[letter] != lastLetterCount[letter]) {
            return false;
        }
    }
    
    return true;
}

int main() {
    int T;
    std::cin >> T;

    for (int i = 0; i < T; i++) {
        int N;
        std::cin >> N;
        
        std::vector<std::string> words(N);
        for (int j = 0; j < N; j++) {
            std::cin >> words[j];
        }
        
        if (isPossible(words)) {
            std::cout << "Ordering is possible." << std::endl;
        } else {
            std::cout << "The door cannot be opened." << std::endl;
        }
    }

    return 0;
}