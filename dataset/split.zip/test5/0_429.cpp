#include <iostream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <string>

using namespace std;

int getMinTransformationSteps(string start, string end, vector<string> words) {
    queue<pair<string, int>> q;
    unordered_map<string, bool> visited;
    
    for(string word : words) {
        visited[word] = false;
    }
    
    q.push({start, 0});
    visited[start] = true;
    
    while(!q.empty()) {
        string current = q.front().first;
        int steps = q.front().second;
        q.pop();
        
        if(current == end) {
            return steps;
        }
        
        for(int i = 0; i < current.length(); i++) {
            for(char c = 'a'; c <= 'z'; c++) {
                string next = current;
                next[i] = c;
                if(visited.find(next) != visited.end() && !visited[next]) {
                    q.push({next, steps + 1});
                    visited[next] = true;
                }
            }
        }
    }
    
    return -1; // If transformation is not possible
}

int main() {
    int N;
    cin >> N;

    for(int t = 0; t < N; t++) {
        vector<string> words;
        
        string word;
        cin >> word;
        
        while(word != "*") {
            words.push_back(word);
            cin >> word;
        }
        
        string start, end;
        cin >> start >> end;
        
        int steps = getMinTransformationSteps(start, end, words);
        
        cout << start << " " << end << " " << steps << endl;
        
        if(t != N - 1) {
            cout << endl; // Separate output sets by a blank line
        }
    }

    return 0;
}