#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int t;
    std::cin >> t;

    for (int i = 0; i < t; i++) {
        int n;
        std::cin >> n;

        std::vector<int> stores(n);
        for (int j = 0; j < n; j++) {
            std::cin >> stores[j];
        }

        std::sort(stores.begin(), stores.end());

        int min_distance = INT_MAX;
        for (int j = stores[0]; j <= stores[n-1]; j++) {
            int distance = 0;
            for (int k = 0; k < n; k++) {
                distance += abs(stores[k] - j);
            }
            min_distance = std::min(min_distance, distance);
        }

        std::cout << min_distance << std::endl;
    }

    return 0;
}