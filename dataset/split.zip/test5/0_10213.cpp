#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int S;
    cin >> S;
    
    for(int i = 0; i < S; i++) {
        long long N;
        cin >> N;
        
        long long result = pow(2, N);
        cout << result << endl;
    }
    
    return 0;
}