#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int num_cases;
    std::cin >> num_cases;

    for(int i = 0; i < num_cases; i++) {
        int num_relatives;
        std::cin >> num_relatives;

        std::vector<int> street_numbers(num_relatives);
        for(int j = 0; j < num_relatives; j++) {
            std::cin >> street_numbers[j];
        }

        std::sort(street_numbers.begin(), street_numbers.end());

        int optimal_house = street_numbers[num_relatives/2];
        int total_distance = 0;
        for(int j = 0; j < num_relatives; j++) {
            total_distance += abs(optimal_house - street_numbers[j]);
        }

        std::cout << total_distance << std::endl;
    }

    return 0;
}