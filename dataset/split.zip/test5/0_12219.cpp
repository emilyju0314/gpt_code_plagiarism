#include <iostream>
#include <map>
#include <vector>
#include <string>

using namespace std;

map<string, int> subexpression_to_node_;
vector<string> nodes_;

string convertToGraph(string expression) {
    // Base case: expression is a single lowercase letter
    if(expression.length() <= 1) {
        return expression;
    }

    // Check if the subexpression already exists in map
    if(subexpression_to_node_.find(expression) != subexpression_to_node_.end()) {
        return to_string(subexpression_to_node_[expression]);
    }

    // Split the expression based on the first opening parenthesis
    size_t pos = expression.find("(");
    string node = expression.substr(0, pos);
    string remaining = expression.substr(pos+1, expression.length()-pos-2);

    // Recursively convert the subexpressions to graph representation
    string new_expression = node + "(";
    size_t start_pos = 0;
    size_t comma_pos = remaining.find(",");
    while(comma_pos != string::npos) {
        string subexpression = remaining.substr(start_pos, comma_pos - start_pos);
        new_expression += convertToGraph(subexpression) + ",";
        start_pos = comma_pos + 1;
        comma_pos = remaining.find(",", start_pos);
    }
    string last_subexpression = remaining.substr(start_pos);
    new_expression += convertToGraph(last_subexpression) + ")";

    // Add the new node to the nodes vector
    int new_node = nodes_.size() + 1;
    nodes_.push_back(new_expression);

    // Update the map with the new node
    subexpression_to_node_[expression] = new_node;

    return to_string(new_node);
}

int main() {
    int c;
    cin >> c;
    cin.ignore();

    for(int i = 0; i < c; i++) {
        string expression;
        getline(cin, expression);

        subexpression_to_node_.clear();
        nodes_.clear();

        // Convert the expression to graph representation
        string graph_expression = convertToGraph(expression);

        // Print the graph representation
        cout << graph_expression << endl;
    }

    return 0;
}