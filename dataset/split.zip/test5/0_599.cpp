#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
#include <string>

using namespace std;

bool isAcorn(unordered_map<char, vector<char>>& graph, char node) {
    return graph[node].size() == 0;
}

void dfs(unordered_map<char, vector<char>>& graph, char node, set<char>& visited) {
    visited.insert(node);
    for (char neighbor : graph[node]) {
        if (visited.find(neighbor) == visited.end()) {
            dfs(graph, neighbor, visited);
        }
    }
}

int countTreesAndAcorns(unordered_map<char, vector<char>>& graph) {
    int trees = 0, acorns = 0;
    set<char> visited;
    
    for (auto& pair : graph) {
        char node = pair.first;
        if (visited.find(node) == visited.end()) {
            if (isAcorn(graph, node)) {
                acorns++;
            } else {
                trees++;
                dfs(graph, node, visited);
            }
        }
    }
    return trees;
}

int main() {
    int numTestCases;
    cin >> numTestCases;
    
    for (int i = 0; i < numTestCases; i++) {
        unordered_map<char, vector<char>> graph;
        string edge;
        getline(cin, edge); // Consume newline
        while (getline(cin, edge) && edge != "**") {
            char u = edge[1], v = edge[3];
            graph[u].push_back(v);
            graph[v].push_back(u);
        }
        
        string nodes;
        getline(cin, nodes);
        
        for (char c : nodes) {
            graph[c] = vector<char>();
        }
        
        int trees = countTreesAndAcorns(graph);
        int acorns = nodes.size() - graph.size();
        
        cout << "There are " << trees << " tree(s) and " << acorns << " acorn(s)." << endl;
    }
    
    return 0;
}