#include <iostream>
#include <vector>
#include <unordered_set>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        vector<unordered_set<int>> problems(3);
        vector<int> uniqueSolvedProblems(3);

        for (int j = 0; j < 3; j++) {
            int S;
            cin >> S;
            for (int k = 0; k < S; k++) {
                int problem;
                cin >> problem;
                problems[j].insert(problem);
            }
        }
        
        for (int j = 0; j < 3; j++) {
            for (int k = 0; k < 3; k++) {
                if (j != k) {
                    for (int problem : problems[j]) {
                        if (problems[k].find(problem) == problems[k].end()) {
                            uniqueSolvedProblems[j] += 1;
                        }
                    }
                }
            }
        }

        int maxUniqueSolvedProblems = *max_element(uniqueSolvedProblems.begin(), uniqueSolvedProblems.end());
        
        cout << "Case #" << i << ":" << endl;
        for (int j = 0; j < 3; j++) {
            if (uniqueSolvedProblems[j] == maxUniqueSolvedProblems) {
                cout << j + 1 << " " << uniqueSolvedProblems[j] << " ";
                for (int problem : problems[j]) {
                    bool unique = true;
                    for (int k = 0; k < 3; k++) {
                        if (j != k && problems[k].find(problem) != problems[k].end()) {
                            unique = false;
                            break;
                        }
                    }
                    if (unique) {
                        cout << problem << " ";
                    }
                }
                cout << endl;
            }
        }
    }

    return 0;
}