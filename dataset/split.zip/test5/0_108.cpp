#include <iostream>
using namespace std;

int main() {
    int N;
    cin >> N;
    
    int arr[N][N];
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < N; j++) {
            cin >> arr[i][j];
        }
    }
    
    int maxSum = arr[0][0];
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < N; j++) {
            for(int k = i; k < N; k++) {
                for(int l = j; l < N; l++) {
                    int sum = 0;
                    for(int m = i; m <= k; m++) {
                        for(int n = j; n <= l; n++) {
                            sum += arr[m][n];
                        }
                    }
                    maxSum = max(maxSum, sum);
                }
            }
        }
    }
    
    cout << maxSum << endl;
    
    return 0;
}