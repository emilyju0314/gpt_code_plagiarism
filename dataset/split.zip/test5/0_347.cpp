#include <iostream>
#include <string>
#include <vector>

bool isRunaroundNumber(const std::string& number) {
    std::vector<bool> visited(number.size(), false);
    int index = 0;
    for (int i = 0; i < number.size(); ++i) {
        index = (index + (number[index] - '0')) % number.size();
        if (visited[index]) {
            return false;
        }
        visited[index] = true;
    }
    return index == 0;
}

std::string findNextRunaroundNumber(std::string R) {
    while (true) {
        if (isRunaroundNumber(R)) {
            return R;
        }
        int num = std::stoi(R) + 1;
        R = std::to_string(num);
    }
}

int main() {
    std::string R;
    int caseNum = 1;
    
    while (true) {
        std::cin >> R;
        if (R == "0") {
            break;
        }
        
        std::cout << "Case " << caseNum << ": " << findNextRunaroundNumber(R) << std::endl;
        
        caseNum++;
    }
    
    return 0;
}