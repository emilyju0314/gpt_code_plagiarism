#include <iostream>
#include <vector>
#include <algorithm>

bool isPrime(int num) {
    if (num < 2) return false;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) return false;
    }
    return true;
}

void findRing(int n, std::vector<int>& ring, std::vector<bool>& used, std::vector<std::vector<int>>& result) {
    if (ring.size() == n) {
        if (isPrime(ring[0] + ring[n - 1])) {
            result.push_back(ring);
        }
        return;
    }
    for (int i = 2; i <= n; i++) {
        if (!used[i]) {
            if (isPrime(ring.back() + i)) {
                ring.push_back(i);
                used[i] = true;
                findRing(n, ring, used, result);
                ring.pop_back();
                used[i] = false;
            }
        }
    }
}

int main() {
    int n;
    std::cin >> n;

    std::vector<std::vector<int>> results;
    for (int i = 2; i <= n; i += 2) {
        std::vector<int> ring = {1, i};
        std::vector<bool> used(n + 1, false);
        used[1] = true;
        used[i] = true;
        findRing(n, ring, used, results);
    }

    std::cout << "Case 1:\n";
    for (int i = 0; i < results[0].size(); i++) {
        std::cout << results[0][i] << " ";
    }
    std::cout << std::endl;

    std::cout << "Case 2:\n";
    for (int i = 0; i < results[1].size(); i++) {
        std::cout << results[1][i] << " ";
    }
    std::cout << std::endl;

    return 0;
}