#include <iostream>
#include <vector>

using namespace std;

vector<unsigned long long> fib;

unsigned long long fibonacci(unsigned long long n) {
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return fibonacci(n-1) + fibonacci(n-2);
    }
}

int main() {
    int t;
    cin >> t;

    fib.push_back(0);
    fib.push_back(1);

    for (int i = 2; i < 1000; i++) {
        fib.push_back(fib[i-1] + fib[i-2]);
    }

    while (t--) {
        unsigned long long a, b, n;
        cin >> a >> b >> n;

        unsigned long long x = a * b % (unsigned long long)fib.size();

        cout << fib[x] % n << endl;
    }

    return 0;
}