#include <iostream>
#include <string>
#include <algorithm>

bool isPalindrome(int num) {
    std::string original = std::to_string(num);
    std::string reverse = original;
    std::reverse(reverse.begin(), reverse.end());
    return original == reverse;
}

int reverseAndAdd(int num) {
    int iterations = 0;
    while (!isPalindrome(num)) {
        std::string str = std::to_string(num);
        std::reverse(str.begin(), str.end());
        int reverseNum = std::stoi(str);
        num += reverseNum;
        iterations++;
    }
    return num;
}

int main() {
    int N;
    std::cin >> N;

    for (int i = 0; i < N; i++) {
        int P;
        std::cin >> P;

        int palindrome = reverseAndAdd(P);
        std::cout << reverseAndAdd(P) << " " << palindrome << std::endl;
    }

    return 0;
}