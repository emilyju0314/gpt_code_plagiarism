#include <iostream>
#include <vector>

void flip(std::vector<int>& pancakes, int i) {
    // Reverse the sub-stack up to position i
    std::reverse(pancakes.begin(), pancakes.begin() + i);
    std::cout << i << " ";
}

void sortPancakes(std::vector<int>& pancakes) {
    for (int i = pancakes.size(); i > 1; --i) {
        // Find the position of the largest pancake
        auto it = std::max_element(pancakes.begin(), pancakes.begin() + i);
        int index = std::distance(pancakes.begin(), it) + 1;
        
        // Flip the pancakes to move the largest pancake to the top
        if (index != i) {
            flip(pancakes, index);
            flip(pancakes, i);
        }
    }
    std::cout << "0" << std::endl;
}

int main() {
    std::vector<int> pancakes;
    int pancake;
    
    while (std::cin >> pancake) {
        pancakes.push_back(pancake);
        
        if (std::cin.get() == '\n') {
            for (int i : pancakes) {
                std::cout << i << " ";
            }
            sortPancakes(pancakes);
            pancakes.clear();
        }
    }
    
    return 0;
}