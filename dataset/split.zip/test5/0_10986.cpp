#include <iostream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

const int INF = numeric_limits<int>::max();

struct Edge {
    int to;
    int weight;
};

int shortestPath(int n, int m, int S, int T, vector<vector<Edge>>& graph) {
    vector<int> dist(n, INF);
    dist[S] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, S});

    while (!pq.empty()) {
        int u = pq.top().second;
        int d = pq.top().first;
        pq.pop();
        
        if (u == T) {
            return d;
        }

        for (const Edge& edge : graph[u]) {
            if (d + edge.weight < dist[edge.to]) {
                dist[edge.to] = d + edge.weight;
                pq.push({dist[edge.to], edge.to});
            }
        }
    }

    return INF;
}

int main() {
    int N;
    cin >> N;

    for (int i = 1; i <= N; i++) {
        int n, m, S, T;
        cin >> n >> m >> S >> T;

        vector<vector<Edge>> graph(n);
        for (int j = 0; j < m; j++) {
            int u, v, w;
            cin >> u >> v >> w;
            graph[u].push_back({v, w});
            graph[v].push_back({u, w});
        }

        int shortestTime = shortestPath(n, m, S, T, graph);

        if (shortestTime == INF) {
            cout << "Case #" << i << ": unreachable" << endl;
        } else {
            cout << "Case #" << i << ": " << shortestTime << endl;
        }
    }

    return 0;
}