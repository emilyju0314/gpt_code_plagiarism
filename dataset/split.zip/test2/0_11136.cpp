#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;
    while (std::cin >> n && n != 0) {
        int total_paid = 0;
        for (int i = 0; i < n; i++) {
            int k;
            std::cin >> k;
            std::vector<int> bills(k);
            for (int j = 0; j < k; j++) {
                std::cin >> bills[j];
            }
            std::sort(bills.begin(), bills.end());

            int highest_bill = bills[k-1];
            int lowest_bill = bills[0];

            total_paid += highest_bill - lowest_bill;
        }
        std::cout << total_paid << std::endl;
    }

    return 0;
}