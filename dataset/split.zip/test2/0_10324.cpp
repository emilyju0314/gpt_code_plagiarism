#include <iostream>
#include <string>
#include <algorithm>

int main() {
    std::string input;
    int caseNum = 1;

    while (true) {
        std::getline(std::cin, input);

        if (input == "") break; // Check for end of input

        std::string s;
        std::getline(std::cin, s);
        int queries = std::stoi(s);

        std::cout << "Case " << caseNum << ":" << std::endl;
        caseNum++;

        int start, end;
        for (int q = 0; q < queries; q++) {
            std::cin >> start >> end;
            std::cin.ignore();

            int minIndex = std::min(start, end);
            int maxIndex = std::max(start, end);

            char target = input[minIndex];
            bool allSame = true;

            for (int i = minIndex; i <= maxIndex; i++) {
                if (input[i] != target) {
                    allSame = false;
                    break;
                }
            }

            if (allSame)
                std::cout << "Yes" << std::endl;
            else
                std::cout << "No" << std::endl;
        }
    }

    return 0;
}