#include <iostream>
#include <vector>
#include <algorithm>

void generateOrderings(std::vector<char>& variables, std::vector<std::pair<char, char>>& constraints, std::string currentOrdering, std::vector<std::string>& orderings) {
    if (currentOrdering.length() == variables.size()) {
        orderings.push_back(currentOrdering);
        return;
    }

    for (char c : variables) {
        if (currentOrdering.find(c) == std::string::npos) {
            bool isValid = true;
            for (auto constraint : constraints) {
                if (constraint.second == c && currentOrdering.find(constraint.first) == std::string::npos) {
                    isValid = false;
                    break;
                }
            }
            if (isValid) {
                generateOrderings(variables, constraints, currentOrdering + c, orderings);
            }
        }
    }
}

int main() {
    std::vector<char> variables;
    std::vector<std::pair<char, char>> constraints;

    while (!std::cin.eof()) {
        std::string variablesInput, constraintsInput;
        std::getline(std::cin, variablesInput);
        std::getline(std::cin, constraintsInput);

        if (variablesInput.empty() || constraintsInput.empty()) {
            break;
        }

        for (char c : variablesInput) {
            if (isalpha(c)) {
                variables.push_back(c);
            }
        }

        for (int i = 0; i < constraintsInput.size(); i += 4) {
            constraints.push_back(std::make_pair(constraintsInput[i], constraintsInput[i + 2]));
        }

        std::vector<std::string> orderings;
        generateOrderings(variables, constraints, "", orderings);

        std::sort(orderings.begin(), orderings.end());

        for (const std::string& ordering : orderings) {
            std::cout << ordering << std::endl;
        }
        std::cout << std::endl;

        variables.clear();
        constraints.clear();
    }

    return 0;
}