#include <iostream>
#include <vector>
#include <algorithm>

struct track {
    int duration;
    int index;
};

bool compareTracks(track t1, track t2) {
    return t1.duration < t2.duration;
}

int main() {
    int N, numTracks;
    while (std::cin >> N >> numTracks) {
        std::vector<track> tracks(numTracks);
        for (int i = 0; i < numTracks; i++) {
            std::cin >> tracks[i].duration;
            tracks[i].index = i + 1;
        }
        
        std::sort(tracks.begin(), tracks.end(), compareTracks);
        
        int totalDuration = 0;
        for (int i = 0; i < numTracks; i++) {
            if (totalDuration + tracks[i].duration <= N) {
                totalDuration += tracks[i].duration;
                std::cout << tracks[i].index << " " << tracks[i].duration << " ";
            }
        }
        std::cout << "sum:" << totalDuration << std::endl;
    }
    
    return 0;
}