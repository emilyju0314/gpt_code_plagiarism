#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

bool isValidMove(vector<int>& board, int row, int col) {
    for (int i = 0; i < col; i++) {
        if (board[i] == row || abs(board[i] - row) == abs(i - col)) {
            return false;
        }
    }
    return true;
}

void solveNQueens(vector<vector<int>>& solutions, vector<int>& board, int col, int n) {
    if (col == n) {
        solutions.push_back(board);
        return;
    }
    for (int i = 0; i < n; i++) {
        if (isValidMove(board, i, col)) {
            board[col] = i;
            solveNQueens(solutions, board, col + 1, n);
        }
    }
}

int main() {
    int datasets;
    cin >> datasets;

    while(datasets--) {
        int row, col;
        cin >> row >> col;

        vector<vector<int>> solutions;
        vector<int> board(8);

        board[col-1] = row-1;

        solveNQueens(solutions, board, 0, 8);

        cout << "SOLN COLUMN\n# 1 2 3 4 5 6 7 8\n";
        for (int i = 0; i < solutions.size(); i++) {
            cout << i + 1;
            for (int j = 0; j < 8; j++) {
                cout << " " << solutions[i][j] + 1;
            }
            cout << endl;
        }

        if (datasets > 0) {
            cout << endl;
        }
    }

    return 0;
}