#include <iostream>
using namespace std;

int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

int main() {
    int T;
    cin >> T;
    
    for (int i = 1; i <= T; i++) {
        int N;
        cin >> N;
        
        int count = 0;
        for (int A = 1; A <= N; A++) {
            for (int B = A; B <= N; B++) {
                if (gcd(A, B) == (A ^ B)) {
                    count++;
                }
            }
        }
        
        cout << "Case " << i << ": " << count << endl;
    }
    
    return 0;
}