#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main() {
    string input;
    int caseNumber = 1;
    
    while (cin >> input && input != "end") {
        vector<vector<char>> stacks;
        vector<char> order;
        
        for (char c : input) {
            if (order.empty() || c != order.back()) {
                stacks.push_back({c});
                order.push_back(c);
            } else {
                for (int i = 0; i < stacks.size(); i++) {
                    if (stacks[i].back() == c) {
                        stacks[i].push_back(c);
                        break;
                    }
                }
            }
        }
        
        cout << "Case " << caseNumber << ": " << stacks.size() << endl;
        caseNumber++;
    }
    
    return 0;
}