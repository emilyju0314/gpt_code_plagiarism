#include <iostream>
#include <vector>
#include <map>
#include <set>

using namespace std;

void dfs(map<string, vector<string>>& graph, string start, set<string>& visited, set<string>& circle) {
    visited.insert(start);
    circle.insert(start);

    for (string neighbor : graph[start]) {
        if (visited.find(neighbor) == visited.end()) {
            dfs(graph, neighbor, visited, circle);
        }
    }
}

int main() {
    int dataset = 1;
    int n, m;
    
    while (cin >> n >> m && n != 0 && m != 0) {
        map<string, vector<string>> graph;
        map<string, set<string>> circles;
        
        for (int i = 0; i < m; i++) {
            string caller, callee;
            cin >> caller >> callee;
            graph[caller].push_back(callee);
        }
        
        set<string> visited;
        
        for (auto& pair : graph) {
            string person = pair.first;
            if (visited.find(person) == visited.end()) {
                set<string> circle;
                dfs(graph, person, visited, circle);
                
                for (string member : circle) {
                    circles[person].insert(member);
                }
            }
        }
        
        cout << "Calling circles for data set " << dataset << ":\n";
        for (auto& pair : circles) {
            cout << pair.first;
            for (string member : pair.second) {
                cout << ", " << member;
            }
            cout << endl;
        }
        
        cout << endl;
        dataset++;
    }
    
    return 0;
}