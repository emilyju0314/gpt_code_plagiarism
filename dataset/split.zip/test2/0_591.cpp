#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int set = 1;
    int n;
    
    while (true) {
        std::cin >> n;
        
        if (n == 0) {
            break;
        }
        
        std::vector<int> heights(n);
        int totalBricks = 0;
        
        for (int i = 0; i < n; i++) {
            std::cin >> heights[i];
            totalBricks += heights[i];
        }
        
        int targetHeight = totalBricks / n;
        
        int moves = 0;
        for (int i = 0; i < n; i++) {
            if (heights[i] > targetHeight) {
                moves += heights[i] - targetHeight;
            }
        }
        
        std::cout << "Set #" << set << std::endl;
        std::cout << "The minimum number of moves is " << moves << "." << std::endl << std::endl;
        
        set++;
    }
    
    return 0;
}