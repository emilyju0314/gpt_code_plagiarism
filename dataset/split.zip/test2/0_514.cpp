#include <iostream>
#include <vector>

bool isPossibleOrder(std::vector<int>& order) {
    std::vector<int> station;
    int currentCoach = 1;
    
    for(int i = 0; i < order.size(); i++) {
        if(currentCoach == order[i]) {
            currentCoach++;
        } else {
            if(station.empty() || station.back() != order[i]) {
                station.push_back(order[i]);
            } else {
                station.pop_back();
            }
        }
        
        while(!station.empty() && station.back() == currentCoach) {
            station.pop_back();
            currentCoach++;
        }
    }
    
    return currentCoach == order.size() + 1;
}

int main() {
    int N;
    
    while(std::cin >> N && N > 0) {
        std::vector<int> order(N);
        for(int i = 0; i < N; i++) {
            std::cin >> order[i];
        }
        
        if(isPossibleOrder(order)) {
            std::cout << "Yes" << std::endl;
        } else {
            std::cout << "No" << std::endl;
        }
        std::cout << std::endl;
    }
    
    return 0;
}