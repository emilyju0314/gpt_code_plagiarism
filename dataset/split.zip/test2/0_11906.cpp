#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

int dx[] = {-1, -1, 1, 1, -2, -2, 2, 2};
int dy[] = {-2, 2, -2, 2, -1, 1, -1, 1};

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int R, C, M, N;
        cin >> R >> C >> M >> N;

        int W;
        cin >> W;

        vector<vector<int>> grid(R, vector<int>(C, 0));
        for (int i = 0; i < W; i++) {
            int x, y;
            cin >> x >> y;
            grid[x][y] = -1;
        }

        int evenCount = 0;
        int oddCount = 0;

        queue<pair<int, int>> q;
        q.push({0, 0});

        grid[0][0] = 1;

        while (!q.empty()) {
            int x = q.front().first;
            int y = q.front().second;
            q.pop();

            int jumpCount = 0;
            for (int i = 0; i < 8; i++) {
                int nx = x + dx[i] * M;
                int ny = y + dy[i] * N;

                if (nx >= 0 && ny >= 0 && nx < R && ny < C && grid[nx][ny] != -1) {
                    jumpCount++;
                    if (grid[nx][ny] == 0) {
                        grid[nx][ny] = 1;
                        q.push({nx, ny});
                    }
                }

                if (M != N) {
                    nx = x + dx[i] * N;
                    ny = y + dy[i] * M;

                    if (nx >= 0 && ny >= 0 && nx < R && ny < C && grid[nx][ny] != -1) {
                        jumpCount++;
                        if (grid[nx][ny] == 0) {
                            grid[nx][ny] = 1;
                            q.push({nx, ny});
                        }
                    }
                }
            }

            if (jumpCount % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
        }

        cout << "Case " << t << ": " << evenCount << " " << oddCount << endl;
    }

    return 0;
}