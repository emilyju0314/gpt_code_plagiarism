#include <iostream>
#include <vector>
#include <string>

using namespace std;

bool isUnbounded(vector<string> molecules) {
    // Implement the logic to check if the set of molecule types can generate a structure of unbounded size
    // You can use graph traversal algorithms like Depth First Search (DFS) or Breadth First Search (BFS) to check for unbounded structures
    return true;
}

int main() {
    int t;
    cin >> t;
    
    for (int i = 0; i < t; i++) {
        int n;
        cin >> n;
        
        vector<string> molecules(n);
        for (int j = 0; j < n; j++) {
            cin >> molecules[j];
        }
        
        if (isUnbounded(molecules)) {
            cout << "unbounded" << endl;
        } else {
            cout << "bounded" << endl;
        }
    }
    
    return 0;
}