#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    vector<int> ugly_numbers(1, 1);
    int p2 = 0, p3 = 0, p5 = 0;
    
    while (ugly_numbers.size() < 1500) {
        int next = min({ugly_numbers[p2] * 2, ugly_numbers[p3] * 3, ugly_numbers[p5] * 5});
        if (next == ugly_numbers[p2] * 2) p2++;
        if (next == ugly_numbers[p3] * 3) p3++;
        if (next == ugly_numbers[p5] * 5) p5++;
        
        if (next != ugly_numbers.back()) {
            ugly_numbers.push_back(next);
        }
    }
    
    cout << "The 1500'th ugly number is " << ugly_numbers.back() << "." << endl;
    
    return 0;
}