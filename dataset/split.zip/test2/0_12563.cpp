#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        int n, t;
        cin >> n >> t;

        vector<int> songs(n);
        for (int j = 0; j < n; j++) {
            cin >> songs[j];
        }

        sort(songs.begin(), songs.end());

        int maxSongs = 0;
        int totalTime = 0;

        for (int j = 0; j < n; j++) {
            if (totalTime + songs[j] <= t) {
                totalTime += songs[j];
                maxSongs++;
            } else {
                break;
            }
        }

        totalTime += 663; // Jin Ge Jin Qu

        cout << "Case " << i << ": " << maxSongs + 1 << " " << totalTime << endl;
    }

    return 0;
}