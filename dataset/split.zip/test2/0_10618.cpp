#include <iostream>
#include <vector>
#include <string>

int main() {
    std::string sequence;
    std::vector<std::string> sequences;

    while (true) {
        std::getline(std::cin, sequence);
        if (sequence == "#") {
            break;
        }
        sequences.push_back(sequence);
    }

    for (const auto& seq : sequences) {
        std::string footGuide;
        char leftFoot = 'L', rightFoot = 'R';
        int leftEnergy = 1, rightEnergy = 1;

        for (char arrow : seq) {
            if (arrow == 'U' || arrow == 'D') {
                if (leftFoot == 'L' || leftFoot == 'R') {
                    footGuide += 'L';
                    leftFoot = 'U';
                    rightEnergy = 3;
                } else if (leftFoot == 'U' && rightFoot != 'L') {
                    footGuide += 'L';
                    leftFoot = 'D';
                    rightEnergy = 7;
                } else {
                    footGuide += 'R';
                    rightFoot = 'U';
                    leftEnergy = 3;
                }
            } else if (arrow == 'L' || arrow == 'R') {
                if (rightFoot == 'R' || rightFoot == 'L') {
                    footGuide += 'R';
                    rightFoot = 'L';
                    leftEnergy = 3;
                } else if (rightFoot == 'L' && leftFoot != 'R') {
                    footGuide += 'R';
                    rightFoot = 'U';
                    leftEnergy = 7;
                } else {
                    footGuide += 'L';
                    leftFoot = 'R';
                    rightEnergy = 5;
                }
            } else {
                footGuide += '.';
            }
        }

        std::cout << footGuide << std::endl;
    }

    return 0;
}