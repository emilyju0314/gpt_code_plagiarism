#include <iostream>
#include <vector>
#include <stack>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<stack<int>> blocks(n); // initialize a vector of stacks for the blocks

    for (int i = 0; i < n; i++) {
        blocks[i].push(i); // each block starts in its own stack
    }

    string command;
    while (command != "quit") {
        int a, b;
        string action;
        cin >> action;

        if (action == "move") {
            cin >> a >> action >> b;

            stack<int> tmp; // temporary stack to hold blocks above block a

            while (blocks[a].top() != a) {
                tmp.push(blocks[a].top());
                blocks[a].pop();
            }

            if (action == "onto") {
                while (blocks[b].top() != b) {
                    blocks[blocks[b].top()].push(blocks[b].top());
                    blocks[b].pop();
                }
            }

            blocks[b].push(a); // move block a onto block b

            while (!tmp.empty()) {
                blocks[b].push(tmp.top());
                tmp.pop();
            }
        } else if (action == "pile") {
            cin >> a >> action >> b;

            stack<int> tmp; // temporary stack to hold blocks above block a

            while (blocks[a].top() != a) {
                tmp.push(blocks[a].top());
                blocks[a].pop();
            }

            if (action == "onto") {
                while (blocks[b].top() != b) {
                    blocks[blocks[b].top()].push(blocks[b].top());
                    blocks[b].pop();
                }
            }

            while (!tmp.empty()) {
                blocks[b].push(tmp.top());
                tmp.pop();
            }
        }

        cin >> command;
    }

    for (int i = 0; i < n; i++) {
        cout << i << ":";
        while (!blocks[i].empty()) {
            cout << " " << blocks[i].top();
            blocks[i].pop();
        }
        cout << endl;
    }

    return 0;
}