#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

void dfs(vector<vector<int>>& graph, vector<bool>& visited, int start) {
    visited[start] = true;
    for (int neighbor : graph[start]) {
        if (!visited[neighbor]) {
            dfs(graph, visited, neighbor);
        }
    }
}

void findInaccessibleVertices(vector<vector<int>>& graph, int start) {
    vector<bool> visited(graph.size() + 1, false);
    dfs(graph, visited, start);
    
    unordered_set<int> accessibleVertices;
    for (int i = 1; i < visited.size(); i++) {
        if (visited[i]) {
            accessibleVertices.insert(i);
        }
    }
    
    cout << graph.size() - accessibleVertices.size() << " ";
    for (int i = 1; i <= graph.size(); i++) {
        if (accessibleVertices.find(i) == accessibleVertices.end()) {
            cout << i << " ";
        }
    }
    cout << endl;
}

int main() {
    int n;
    while (cin >> n && n != 0) {
        vector<vector<int>> graph(n + 1);
        int start, end;
        while (cin >> start && start != 0) {
            while (cin >> end && end != 0) {
                graph[start].push_back(end);
            }
        }
        
        int m;
        cin >> m;
        for (int i = 0; i < m; i++) {
            int startVertex;
            cin >> startVertex;
            findInaccessibleVertices(graph, startVertex);
        }
    }
    
    return 0;
}