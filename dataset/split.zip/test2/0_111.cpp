#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    
    while(t--) {
        int n;
        cin >> n;
        vector<int> correctOrder(n);
        vector<int> tempOrder(n);
        
        for(int i = 0; i < n; i++) {
            cin >> correctOrder[i];
        }
        
        while(cin >> tempOrder[0]) {
            for(int i = 1; i < n; i++) {
                cin >> tempOrder[i];
            }
            
            int longestSequence = 0;
            for(int i = 0; i < n; i++) {
                int seqLength = 1;
                for(int j = i+1; j < n; j++) {
                    if(find(correctOrder.begin(), correctOrder.end(), tempOrder[j-1]) < find(correctOrder.begin(), correctOrder.end(), tempOrder[j])) {
                        seqLength++;
                    } else {
                        break;
                    }
                }
                longestSequence = max(longestSequence, seqLength);
            }
            
            cout << longestSequence << endl;
        }
    }
    
    return 0;
}