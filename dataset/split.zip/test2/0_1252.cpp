#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

int m, n;
vector<string> objects;
int dp[1<<11][1<<7];

int count_bits(int x) {
    return x == 0 ? 0 : (x & 1) + count_bits(x >> 1);
}

bool has_duplicate(int i, int j) {
    for (int k = 0; k < n; ++k) {
        if (objects[i][k] == objects[j][k]) {
            return false;
        }
    }
    return true;
}

int solve(int mask, int subset) {
    if (mask == (1 << m) - 1) {
        return 0;
    }
    if (dp[mask][subset] != -1) {
        return dp[mask][subset];
    }

    int res = m;
    for (int i = 0; i < m; i++) {
        if ((mask & (1 << i)) == 0) {
            int new_mask = mask | (1 << i);
            int new_subset = 0;
            for (int j = 0; j < m; j++) {
                if ((mask & (1 << j)) != 0 && ((subset & (1 << j)) == 0) && has_duplicate(i, j)) {
                    new_subset |= 1 << j;
                }
            }
            res = min(res, 1 + solve(new_mask, new_subset));
        }
    }

    return dp[mask][subset] = res;
}

int main() {
    while (true) {
        cin >> m >> n;
        
        if (m == 0 && n == 0) {
            break;
        }

        objects.clear();
        objects.resize(n);

        for (int i = 0; i < n; ++i) {
            cin >> objects[i];
        }

        memset(dp, -1, sizeof(dp));
        int result = solve(0, 0);
        cout << result << endl;
    }

    return 0;
}