#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

struct DominoRow {
    int a, b, l;
};

int main() {
    int caseNum = 1;
    
    while (true) {
        int n, m;
        cin >> n >> m;
        
        if (n == 0 && m == 0) {
            break;
        }
        
        vector<DominoRow> rows(m);
        for (int i = 0; i < m; i++) {
            cin >> rows[i].a >> rows[i].b >> rows[i].l;
        }
        
        cout << "System #" << caseNum << endl;
        
        double lastFallTime = 0.0;
        int lastFallLocation = 1;
        
        for (int i = 0; i < m; i++) {
            if (lastFallLocation == rows[i].a) {
                lastFallTime += rows[i].l;
                lastFallLocation = rows[i].b;
            } else if (lastFallLocation == rows[i].b) {
                lastFallTime += rows[i].l;
                lastFallLocation = rows[i].a;
            } else {
                double dist1 = abs(lastFallLocation - rows[i].a);
                double dist2 = abs(lastFallLocation - rows[i].b);
                double time1 = dist1 / (dist1 + dist2) * rows[i].l;
                lastFallTime += time1;
                lastFallLocation = (dist1 < dist2) ? rows[i].a : rows[i].b;
            }
        }
        
        cout << fixed << setprecision(1);
        cout << "The last domino falls after " << lastFallTime << " seconds, ";
        if (lastFallLocation == n) {
            cout << "at key domino " << n << "." << endl;
        } else {
            cout << "between key dominoes " << min(lastFallLocation, n) << " and " << max(lastFallLocation, n) << "." << endl;
        }
        
        cout << endl;
        
        caseNum++;
    }
    
    return 0;
}