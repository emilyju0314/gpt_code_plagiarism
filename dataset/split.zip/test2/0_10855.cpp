#include <iostream>
#include <vector>
#include <string>

using namespace std;

bool checkRotation(vector<string>& bigSquare, vector<string>& smallSquare, int startRow, int startCol) {
    int n = smallSquare.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (bigSquare[startRow + i][startCol + j] != smallSquare[i][j]) {
                return false;
            }
        }
    }
    return true;
}

int main() {
    int N, n;
    while (true) {
        cin >> N >> n;
        if (N == 0 && n == 0) {
            break;
        }

        vector<string> bigSquare(N);
        vector<string> smallSquare(n);
        for (int i = 0; i < N; i++) {
            cin >> bigSquare[i];
        }
        for (int i = 0; i < n; i++) {
            cin >> smallSquare[i];
        }

        int countNoRotation = 0;
        int count90 = 0, count180 = 0, count270 = 0;
        for (int i = 0; i <= N - n; i++) {
            for (int j = 0; j <= N - n; j++) {
                if (checkRotation(bigSquare, smallSquare, i, j)) {
                    countNoRotation++;
                }

                // Check rotated forms
                vector<string> rotatedSmall(n, string(n, ' '));
                for (int k = 0; k < n; k++) {
                    for (int l = 0; l < n; l++) {
                        rotatedSmall[k][l] = smallSquare[n - 1 - l][k];
                    }
                }

                if (checkRotation(bigSquare, rotatedSmall, i, j)) {
                    count90++;
                }

                if (checkRotation(bigSquare, rotatedSmall, i, j)) {
                    count180++;
                }

                if (checkRotation(bigSquare, rotatedSmall, i, j)) {
                    count270++;
                }
            }
        }

        cout << countNoRotation << " " << count90 << " " << count180 << " " << count270 << endl;
    }

    return 0;
}