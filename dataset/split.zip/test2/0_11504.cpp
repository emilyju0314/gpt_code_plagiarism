#include <iostream>
#include <unordered_set>
#include <vector>

int minDominosToKnockDown(int n, std::vector<std::pair<int, int>>& dominos) {
    std::unordered_set<int> knockedDown;
    for (int i = dominos.size() - 1; i >= 0; i--) {
        if (knockedDown.count(dominos[i].second) == 0) {
            knockedDown.insert(dominos[i].first);
        }
    }
    return n - knockedDown.size();
}

int main() {
    int testCases;
    std::cin >> testCases;

    for (int t = 0; t < testCases; t++) {
        int n, m;
        std::cin >> n >> m;

        std::vector<std::pair<int, int>> dominos;

        for (int i = 0; i < m; i++) {
            int x, y;
            std::cin >> x >> y;
            dominos.push_back(std::make_pair(x, y));
        }

        int result = minDominosToKnockDown(n, dominos);

        std::cout << result << std::endl;
    }

    return 0;
}