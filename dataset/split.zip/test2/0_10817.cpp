#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int S, M, N;
    
    while (true) {
        cin >> S >> M >> N;
        
        if (S == 0) {
            break;
        }
        
        vector<pair<int, vector<int>>> teachers(M);
        vector<pair<int, vector<int>>> applicants(N);
        
        for (int i = 0; i < M; i++) {
            cin >> teachers[i].first;
            int numSubjects;
            cin >> numSubjects;
            for (int j = 0; j < numSubjects; j++) {
                int subject;
                cin >> subject;
                teachers[i].second.push_back(subject);
            }
        }
        
        for (int i = 0; i < N; i++) {
            cin >> applicants[i].first;
            int numSubjects;
            cin >> numSubjects;
            for (int j = 0; j < numSubjects; j++) {
                int subject;
                cin >> subject;
                applicants[i].second.push_back(subject);
            }
        }
        
        vector<int> subjectCount(S+1, 0);
        for (int i = 0; i < M; i++) {
            for (int subject : teachers[i].second) {
                subjectCount[subject]++;
            }
        }
        
        int totalCost = 0;
        for (int subject = 1; subject <= S; subject++) {
            int numTeachers = subjectCount[subject];
            if (numTeachers == 1) {
                int minCost = INT_MAX;
                for (int i = 0; i < N; i++) {
                    if (find(applicants[i].second.begin(), applicants[i].second.end(), subject) != applicants[i].second.end()) {
                        minCost = min(minCost, applicants[i].first);
                    }
                }
                totalCost += minCost;
            } else if (numTeachers == 0) {
                cout << "No solution" << endl;
                break;
            }
        }
        
        if (totalCost > 0) {
            cout << totalCost << endl;
        }
    }
    
    return 0;
}