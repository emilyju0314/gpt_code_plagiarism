#include <iostream>
#include <vector>
#include <queue>
#include <tuple>

using namespace std;

int bfs(vector<vector<char>>& floor, vector<pair<int, int>>& start_positions, vector<pair<int, int>>& end_positions) {
    vector<vector<bool>> visited(floor.size(), vector<bool>(floor[0].size(), false));
    queue<tuple<int, int, int>> q; // row, column, steps
    for(int i = 0; i < start_positions.size(); i++) {
        q.push(make_tuple(start_positions[i].first, start_positions[i].second, 0));
        visited[start_positions[i].first][start_positions[i].second] = true;
    }
    while(!q.empty()) {
        int row = get<0>(q.front());
        int col = get<1>(q.front());
        int steps = get<2>(q.front());
        q.pop();
        if(floor[row][col] != '.' && floor[row][col] != ' ') { // Ghost end position check
            if(floor[row][col] != tolower(floor[row][col])) { // Check if the ghost is in correct position
                continue;
            }
        }
        for(int i = -1; i <= 1; i++) {
            for(int j = -1; j <= 1; j++) {
                if(abs(i) + abs(j) == 1) {
                    int new_row = row + i;
                    int new_col = col + j;
                    if(new_row >= 0 && new_row < floor.size() && new_col >= 0 && new_col < floor[0].size() && !visited[new_row][new_col] && floor[new_row][new_col] != '#') {
                        q.push(make_tuple(new_row, new_col, steps + 1));
                        visited[new_row][new_col] = true;
                    }
                }
            }
        }
    }
    return -1; // Ghosts couldn't be restored
}

int main() {
    int w, h, n;
    while(cin >> w >> h >> n) {
        if(w == 0 && h == 0 && n == 0) {
            break;
        }
        vector<vector<char>> floor(h, vector<char>(w));
        vector<pair<int, int>> start_positions;
        vector<pair<int, int>> end_positions;
        for(int i = 0; i < h; i++) {
            for(int j = 0; j < w; j++) {
                cin >> floor[i][j];
                if(islower(floor[i][j])) {
                    start_positions.push_back(make_pair(i, j));
                } else if(isupper(floor[i][j])) {
                    end_positions.push_back(make_pair(i, j));
                }
            }
        }
        int steps = bfs(floor, start_positions, end_positions);
        cout << steps << endl;
    }
    return 0;
}