#include <iostream>
#include <vector>
#include <iomanip>

int main() {
    int C;
    std::cin >> C;

    for (int i = 0; i < C; i++) {
        int N;
        std::cin >> N;
        
        std::vector<int> grades(N);
        double total = 0;
        for (int j = 0; j < N; j++) {
            std::cin >> grades[j];
            total += grades[j];
        }
        
        double average = total / N;
        int above_avg_count = 0;
        for (int j = 0; j < N; j++) {
            if (grades[j] > average) {
                above_avg_count++;
            }
        }
        
        double percentage = (static_cast<double>(above_avg_count) / N) * 100;
        std::cout << std::fixed << std::setprecision(3) << percentage << "%" << std::endl;
    }

    return 0;
}