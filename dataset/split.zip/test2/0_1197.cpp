#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

int main() {
    int n, m;
    while (cin >> n >> m) {
        if (n == 0 && m == 0) {
            break;
        }
        
        vector<unordered_set<int>> groups(m);
        vector<bool> suspect(n, false);
        
        suspect[0] = true; // Student 0 is initially a suspect
        
        for (int i = 0; i < m; i++) {
            int k;
            cin >> k;
            for (int j = 0; j < k; j++) {
                int student;
                cin >> student;
                groups[i].insert(student);
            }
        }
        
        for (int i = 0; i < m; i++) {
            for (int student : groups[i]) {
                if (suspect[student]) {
                    for (int s : groups[i]) {
                        suspect[s] = true;
                    }
                    break;
                }
            }
        }
        
        int totalSuspects = 0;
        for (bool isSuspect : suspect) {
            if (isSuspect) {
                totalSuspects++;
            }
        }
        
        cout << totalSuspects << endl;
    }
    
    return 0;
}