#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;
        
        vector<int> startGrid(n);
        vector<int> finishGrid(n);

        for (int i = 0; i < n; i++) {
            cin >> startGrid[i];
        }

        for (int i = 0; i < n; i++) {
            cin >> finishGrid[i];
        }

        int overtakes = 0;
        for (int i = 0; i < n; i++) {
            for (int j = i+1; j < n; j++) {
                if (startGrid[i] == finishGrid[j]) {
                    overtakes += j - i;
                    startGrid.erase(startGrid.begin() + j);
                    startGrid.insert(startGrid.begin() + i, finishGrid[j]);
                    break;
                }
            }
        }

        cout << overtakes << endl;
    }

    return 0;
}