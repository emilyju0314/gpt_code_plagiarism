#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

bool isAnagram(string s1, string s2) {
    sort(s1.begin(), s1.end());
    sort(s2.begin(), s2.end());
    return s1 == s2;
}

int main() {
    vector<string> dictionary;
    string word;
    
    // Input dictionary
    while (cin >> word) {
        if (word == "XXXXXX") {
            break;
        }
        dictionary.push_back(word);
    }
    
    // Read scrambled words and unscramble
    while (cin >> word) {
        if (word == "XXXXXX") {
            break;
        }
        
        vector<string> validWords; // Store valid dictionary words for each scrambled word
        
        for (int i = 0; i < dictionary.size(); i++) {
            if (isAnagram(word, dictionary[i])) {
                validWords.push_back(dictionary[i]);
            }
        }
        
        // Output valid words or "NOT A VALID WORD"
        if (validWords.empty()) {
            cout << "NOT A VALID WORD" << endl;
        } else {
            sort(validWords.begin(), validWords.end());
            for (string validWord : validWords) {
                cout << validWord << endl;
            }
        }
        
        cout << "******" << endl;
    }
    
    return 0;
}