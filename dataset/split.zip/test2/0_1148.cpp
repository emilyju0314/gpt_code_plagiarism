#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int findMinIntermediateCamarades(int c1, int c2, vector<vector<int>>& adjList) {
    vector<int> visited(adjList.size(), false);
    vector<int> distance(adjList.size(), 0);
    
    queue<int> q;
    q.push(c1);
    visited[c1] = true;
    
    while (!q.empty()) {
        int curCamarade = q.front();
        q.pop();
        
        if (curCamarade == c2) {
            return distance[curCamarade]; // return the distance to reach c2
        }
        
        for (int neighbor : adjList[curCamarade]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                distance[neighbor] = distance[curCamarade] + 1;
                q.push(neighbor);
            }
        }
    }
    
    return -1; // c2 not found
}

int main() {
    int T;
    cin >> T;
    
    for (int t = 0; t < T; t++) {
        int N;
        cin >> N;
        
        vector<vector<int>> adjList(N);
        
        for (int i = 0; i < N; i++) {
            int c, nc;
            cin >> c >> nc;
            
            for (int j = 0; j < nc; j++) {
                int neighbor;
                cin >> neighbor;
                adjList[c].push_back(neighbor);
            }
        }
        
        int c1, c2;
        cin >> c1 >> c2;
        
        int minIntermediateCamarades = findMinIntermediateCamarades(c1, c2, adjList);
        
        cout << c1 << " " << c2 << " " << minIntermediateCamarades << endl;
        if (t < T-1) {
            cout << endl; // Output separator between test cases
        }
    }
    
    return 0;
}