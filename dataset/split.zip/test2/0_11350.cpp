#include <iostream>
#include <string>

using namespace std;

pair<int, int> findFraction(string path) {
    int num = 1, den = 1;
    
    for(char c : path) {
        if (c == 'L') {
            num = num + den;
        } else {
            den = num + den;
        }
    }
    
    return make_pair(num, den);
}

int main() {
    int N;
    cin >> N;
    
    for (int i = 0; i < N; i++) {
        string path;
        cin >> path;
        
        pair<int, int> result = findFraction(path);
        cout << result.first << "/" << result.second << endl;
    }
    
    return 0;
}