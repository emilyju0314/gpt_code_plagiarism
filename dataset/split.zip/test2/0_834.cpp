#include <iostream>
#include <vector>

using namespace std;

vector<int> compute_continued_fraction(int numerator, int denominator) {
    vector<int> continued_fraction;
    
    while (denominator != 0) {
        int quotient = numerator / denominator;
        continued_fraction.push_back(quotient);
        
        int temp = numerator;
        numerator = denominator;
        denominator = temp % denominator;
    }
    
    return continued_fraction;
}

int main() {
    int numerator, denominator;
    
    while (cin >> numerator >> denominator) {
        vector<int> continued_fraction = compute_continued_fraction(numerator, denominator);
        
        cout << "[";
        for (int i = 0; i < continued_fraction.size(); i++) {
            if (i == 0) {
                cout << continued_fraction[i];
            } else {
                cout << "," << continued_fraction[i];
            }
        }
        cout << "]" << endl;
    }
    
    return 0;
}