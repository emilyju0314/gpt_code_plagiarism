#include <iostream>
#include <vector>

using namespace std;

int countAliveShips(vector<vector<char>> &grid, int n) {
    int aliveShips = 0;
    
    vector<vector<bool>> visited(n, vector<bool>(n, false));
    
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(grid[i][j] == 'x' && !visited[i][j]) {
                bool shipSunk = true;
                int startRow = i;
                int startCol = j;
                
                // check if ship is horizontal
                while(j < n && grid[i][j] == 'x') {
                    if(visited[i][j]) {
                        shipSunk = false;
                        break;
                    }
                    visited[i][j] = true;
                    j++;
                }
                
                // check if ship is vertical
                if(shipSunk) {
                    j = startCol;
                    while(i < n && grid[i][j] == 'x') {
                        if(visited[i][j]) {
                            shipSunk = false;
                            break;
                        }
                        visited[i][j] = true;
                        i++;
                    }
                }
                
                if(shipSunk) {
                    aliveShips++;
                }
            }
        }
    }
    
    return aliveShips;
}

int main() {
    int T;
    cin >> T;
    
    for(int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        
        vector<vector<char>> grid(n, vector<char>(n));
        
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                cin >> grid[i][j];
            }
        }
        
        int aliveShips = countAliveShips(grid, n);
        
        cout << "Case " << t << ": " << aliveShips << endl;
    }
    
    return 0;
}