#include <iostream>
#include <string>
#include <vector>

using namespace std;

void sendEmail(string sender, string receiver, string MTA) {
    cout << "Connection between " << sender << " and " << MTA << "\n";
    cout << "HELO " << sender << "\n";
    cout << "250\n";
    cout << "MAIL FROM:<" << sender << "@" << MTA << ">\n";
    cout << "250\n";
    cout << "RCPT TO:<" << receiver << "@" << MTA << ">\n";
    if (receiver == "Lisa") {
        cout << "550\n";
        cout << "QUIT\n";
        cout << "221\n";
    } else {
        cout << "250\n";
        cout << "DATA\n";
        cout << "354\n";
        cout << "Congratulations on your efforts !!\n";
        cout << "--" << sender << "\n";
        cout << ".\n";
        cout << "250\n";
        cout << "QUIT\n";
        cout << "221\n";
    }
}

int main() {
    vector<string> MTAs = {"London", "SanFrancisco", "Paris", "HongKong", "MexicoCity", "Cairo"};
    vector<vector<string>> users = {
        {"Fiona", "Paul", "Heather", "Nevil"},
        {"Mario", "Luigi", "Shariff"},
        {"Jacque", "Suzanne", "Maurice"},
        {"Chen", "Jeng", "Hee"},
        {"Conrado", "Estella", "Eva", "Raul"},
        {"Hamdy", "Tarik", "Misa"}
    };

    string sender, receiver, MTA;

    while (true) {
        cin >> sender;
        if (sender == "*") {
            break;
        }
        cin >> receiver >> MTA;

        sendEmail(sender, receiver, MTA);
    }

    return 0;
}