#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<double> spanishProb = {12.53, 1.42, 4.68, 5.86, 13.68, 0.69, 1.01, 0.70, 6.25, 0.44, 0.00, 4.97, 3.15, 
                               6.71, 8.68, 2.51, 0.88, 6.87, 7.98, 4.63, 3.93, 0.90, 0.02, 0.22, 0.90, 0.52};

double calculateSBC(string word) {
    double sbc = 0.0;
    for(char c : word) {
        int index = (int) c - 97;
        sbc += spanishProb[index];
    }
    return sbc;
}

int main() {
    int N;
    cin >> N;
    
    for(int i = 0; i < N; i++) {
        string word;
        cin >> word;
        
        double wordSBC = calculateSBC(word);
        
        int size = word.size();
        double avgSBC = 0.0;
        
        for(int j = 0; j < 26; j++) {
            string temp = string(1, (char) (j + 97)) + string(size - 1, 'a');
            avgSBC += calculateSBC(temp);
        }
        avgSBC /= 26.0;
        
        if(wordSBC >= avgSBC) {
            cout << "above or equal" << endl;
        } else {
            cout << "below" << endl;
        }
    }
    
    return 0;
}