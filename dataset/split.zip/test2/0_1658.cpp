#include <iostream>
#include <vector>
#include <climits>

using namespace std;

int main() {
    int v, e;
    cin >> v >> e;

    vector<vector<pair<int, int>>> adj(v + 1);

    for (int i = 0; i < e; ++i) {
        int a, b, c;
        cin >> a >> b >> c;
        adj[a].push_back({b, c});
    }

    vector<vector<int>> dp(v + 1, vector<int>(101, INT_MAX));
    dp[1][0] = 0;

    for (int i = 1; i <= v; ++i) {
        for (int j = 0; j <= 100; ++j) {
            if (dp[i][j] != INT_MAX) {
                for (auto edge : adj[i]) {
                    int next = edge.first;
                    int cannonballs = edge.second;
                    dp[next][j + cannonballs] = min(dp[next][j + cannonballs], dp[i][j] + cannonballs);
                }
            }
        }
    }

    int ans = INT_MAX;
    for (int i = 0; i <= 100; ++i) {
        ans = min(ans, max(i, dp[v][i]));
    }

    cout << ans << endl;

    return 0;
}