#include <iostream>
#include <string>
#include <map>

using namespace std;

int main() {
    int m, n;
    cin >> m >> n;
    
    map<string, int> hayPoints;
    
    for (int i = 0; i < m; i++) {
        string word;
        int value;
        cin >> word >> value;
        hayPoints[word] = value;
    }
    
    cin.ignore();
    
    for (int i = 0; i < n; i++) {
        string line;
        int salary = 0;
        
        while (getline(cin, line) && line != ".") {
            string word = "";
            for (char c : line) {
                if (isalpha(c)) {
                    word += tolower(c);
                } else if (!word.empty()) {
                    salary += hayPoints[word];
                    word = "";
                }
            }
            if (!word.empty()) {
                salary += hayPoints[word];
            }
        }
        
        cout << salary << endl;
    }
    
    return 0;
}