#include<iostream>
#include<unordered_map>
#include<vector>

using namespace std;

int findFallingDominos(int n, vector<pair<int, int>>& edges, vector<int>& knockedByHand) {
    unordered_map<int, bool> visited;
    unordered_map<int, vector<int>> graph;

    for(auto& edge : edges) {
        graph[edge.first].push_back(edge.second);
    }

    for(int domino : knockedByHand) {
        visited[domino] = true;
    }

    int count = 0;

    for(int domino : knockedByHand) {
        count++;
        for(int adjacent : graph[domino]) {
            if(!visited[adjacent]) {
                visited[adjacent] = true;
                count++;
            }
        }
    }

    return count;
}

int main() {
    int t;
    cin >> t;

    while(t--) {
        int n, m, l;
        cin >> n >> m >> l;

        vector<pair<int, int>> edges;
        vector<int> knockedByHand;

        for(int i = 0; i < m; i++) {
            int x, y;
            cin >> x >> y;
            edges.push_back({x, y});
        }

        for(int i = 0; i < l; i++) {
            int z;
            cin >> z;
            knockedByHand.push_back(z);
        }

        cout << findFallingDominos(n, edges, knockedByHand) << endl;
    }

    return 0;
}