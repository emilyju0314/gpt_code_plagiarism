#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

int main() {
    int N;
    cin >> N;

    for (int i = 1; i <= N; i++) {
        int H, W;
        cin >> H >> W;

        vector<vector<char>> map(H, vector<char>(W));
        for (int j = 0; j < H; j++) {
            for (int k = 0; k < W; k++) {
                cin >> map[j][k];
            }
        }

        map<char, int> states;
        for (int j = 0; j < H; j++) {
            for (int k = 0; k < W; k++) {
                char language = map[j][k];
                if (states.find(language) == states.end()) {
                    states[language] = 1;
                } else {
                    states[language]++;
                }
            }
        }

        // Sort languages based on number of states (descending) and alphabetically
        vector<pair<char, int>> sorted_states(states.begin(), states.end());
        sort(sorted_states.begin(), sorted_states.end(), [](const pair<char, int> &a, const pair<char, int> &b) {
            if (a.second == b.second) {
                return a.first < b.first;
            }
            return a.second > b.second;
        });

        // Print output
        cout << "World #" << i << endl;
        for (auto p : sorted_states) {
            cout << p.first << ": " << p.second << endl;
        }
    }

    return 0;
}