#include <iostream>

int main() {
    int T;
    std::cin >> T;

    for (int i = 1; i <= T; i++) {
        int salaries[3];
        std::cin >> salaries[0] >> salaries[1] >> salaries[2];
        
        int maxSalary = std::max(salaries[0], std::max(salaries[1], salaries[2]));
        int minSalary = std::min(salaries[0], std::min(salaries[1], salaries[2]));

        int survivedSalary = salaries[0] + salaries[1] + salaries[2] - maxSalary - minSalary;
        
        std::cout << "Case " << i << ": " << survivedSalary << std::endl;
    }

    return 0;
}