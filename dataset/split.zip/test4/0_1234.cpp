#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Road {
    int start;
    int end;
    int cost;
};

bool compare(Road r1, Road r2) {
    return r1.cost < r2.cost;
}

int main() {
    int datasets;
    cin >> datasets;

    while(datasets--) {
        int n, m;
        cin >> n >> m;

        vector<Road> roads;
        for(int i = 0; i < m; i++) {
            Road road;
            cin >> road.start >> road.end >> road.cost;
            roads.push_back(road);
        }

        sort(roads.begin(), roads.end(), compare);

        // Kruskal's algorithm to find Minimum Spanning Tree
        int totalCost = 0;
        int count = 0;
        vector<int> parent(n+1);
        for(int i = 1; i <= n; i++) {
            parent[i] = i;
        }

        for(int i = 0; i < m; i++) {
            int start = roads[i].start;
            int end = roads[i].end;
            int cost = roads[i].cost;

            while(parent[start] != start) {
                start = parent[start];
            }
            while(parent[end] != end) {
                end = parent[end];
            }

            if(start != end) {
                totalCost += cost;
                count++;
                parent[start] = end;
            }

            if(count == n-1) {
                break;
            }
        }

        cout << totalCost << endl;
    }

    return 0;
}