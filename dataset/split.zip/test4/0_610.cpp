#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

int main() {
    int caseNumber = 1;
    while (true) {
        int n, m;
        cin >> n >> m;

        if (n == 0 && m == 0) {
            break;
        }

        unordered_map<int, vector<int>> streets;
        for (int i = 0; i < m; i++) {
            int start, end;
            cin >> start >> end;
            streets[start].push_back(end);
        }

        cout << caseNumber << endl;
        for (const auto& street : streets) {
            for (const auto& end : street.second) {
                cout << street.first << " " << end << endl;
                if (streets.find(end) == streets.end() || streets[end].empty() || streets[end][0] != street.first) {
                    cout << end << " " << street.first << endl;
                }
            }
        }

        cout << "#" << endl;
        caseNumber++;
    }

    return 0;
}