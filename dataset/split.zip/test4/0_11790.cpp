#include <iostream>
#include <vector>

using namespace std;

int longestIncreasingSubsequence(vector<int>& heights, vector<int>& widths) {
    int n = heights.size();
    vector<int> dp(n, 0);

    for (int i = 0; i < n; i++) {
        dp[i] = widths[i];
        for (int j = 0; j < i; j++) {
            if (heights[j] < heights[i]) {
                dp[i] = max(dp[i], dp[j] + widths[i]);
            }
        }
    }

    int maxLength = 0;
    for (int i = 0; i < n; i++) {
        maxLength = max(maxLength, dp[i]);
    }

    return maxLength;
}

int longestDecreasingSubsequence(vector<int>& heights, vector<int>& widths) {
    int n = heights.size();
    vector<int> dp(n, 0);

    for (int i = 0; i < n; i++) {
        dp[i] = widths[i];
        for (int j = 0; j < i; j++) {
            if (heights[j] > heights[i]) {
                dp[i] = max(dp[i], dp[j] + widths[i]);
            }
        }
    }

    int maxLength = 0;
    for (int i = 0; i < n; i++) {
        maxLength = max(maxLength, dp[i]);
    }

    return maxLength;
}

int main() {
    int t;
    cin >> t;

    for (int k = 1; k <= t; k++) {
        int n;
        cin >> n;

        vector<int> heights(n);
        vector<int> widths(n);

        for (int i = 0; i < n; i++) {
            cin >> heights[i];
        }

        for (int i = 0; i < n; i++) {
            cin >> widths[i];
        }

        int increasingLength = longestIncreasingSubsequence(heights, widths);
        int decreasingLength = longestDecreasingSubsequence(heights, widths);

        if (increasingLength >= decreasingLength) {
            cout << "Case " << k << ". Increasing (" << increasingLength << "). Decreasing (" << decreasingLength << ")." << endl;
        } else {
            cout << "Case " << k << ". Decreasing (" << decreasingLength << "). Increasing (" << increasingLength << ")." << endl;
        }
    }

    return 0;
}