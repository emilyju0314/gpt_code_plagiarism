#include <iostream>
#include <vector>
#include <cmath>

struct Point {
    double x;
    double y;
};

double calculateDistance(Point p1, Point p2) {
    return sqrt(pow(p2.x - p1.x, 2) + pow(p2.y - p1.y, 2));
}

int main() {
    int numPoints;
    while (std::cin >> numPoints) {
        std::vector<Point> points(numPoints);
        for (int i = 0; i < numPoints; i++) {
            std::cin >> points[i].x >> points[i].y;
        }

        double tourLength = 0.0;
        for (int i = 0; i < numPoints - 1; i++) {
            tourLength += calculateDistance(points[i], points[i + 1]);
        }
        tourLength += calculateDistance(points[numPoints - 1], points[0]);

        std::cout << std::fixed;
        std::cout << std::setprecision(2);
        std::cout << tourLength << std::endl;
    }

    return 0;
}