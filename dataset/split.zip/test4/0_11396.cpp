#include <iostream>
#include <vector>
#include <set>

using namespace std;

bool isClaw(vector<pair<int, int>>& edges) {
    if (edges.size() != 3) {
        return false;
    }

    set<int> vertices;
    for (auto edge : edges) {
        vertices.insert(edge.first);
        vertices.insert(edge.second);
    }

    if (vertices.size() != 4) {
        return false;
    }

    int count = 0;
    for (auto v : vertices) {
        int degree = 0;
        for (auto edge : edges) {
            if (edge.first == v || edge.second == v) {
                degree++;
            }
        }
        if (degree == 3) {
            count++;
        } else if (degree != 1) {
            return false;
        }
    }

    return count == 3;
}

int main() {
    int V;
    while (cin >> V && V != 0) {
        vector<pair<int, int>> edges;
        int a, b;
        while (cin >> a >> b && !(a == 0 && b == 0)) {
            edges.push_back({a, b});
        }

        if (edges.size() % 3 != 0) {
            cout << "NO" << endl;
            continue;
        }

        bool canDecompose = true;
        for (int i = 0; i < edges.size(); i += 3) {
            vector<pair<int, int>> subgraph(edges.begin() + i, edges.begin() + i + 3);
            if (!isClaw(subgraph)) {
                canDecompose = false;
                break;
            }
        }

        if (canDecompose) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }

    return 0;
}