#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

bool is_valid_move(int i, int j, int N) {
    return i >= 0 && i < N && j >= 0 && j < N;
}

bool has_won(vector<string>& board, char color, int N, int i, int j) {
    if (color == 'b' && i == 0) {
        return true;
    } 
    if (color == 'w' && j == 0) {
        return true;
    }

    vector<vector<bool>> visited(N, vector<bool>(N, false));
    vector<pair<int, int>> queue;
    queue.push_back({i, j});

    while (!queue.empty()) {
        pair<int, int> current = queue.back();
        queue.pop_back();
        int x = current.first;
        int y = current.second;

        if (color == 'b' && x == N - 1) {
            return true;
        }
        if (color == 'w' && y == N - 1) {
            return true;
        }

        visited[x][y] = true;

        vector<pair<int, int>> neighbors = {{x-1, y-1}, {x-1, y}, {x, y-1}, {x, y+1}, {x+1, y}, {x+1, y+1}};
        for (auto neighbor : neighbors) {
            int new_x = neighbor.first;
            int new_y = neighbor.second;
            if (is_valid_move(new_x, new_y, N) && !visited[new_x][new_y] && board[new_x][new_y] == color) {
                queue.push_back({new_x, new_y});
            }
        }
    }

    return false;
}

int main() {
    ifstream input_file("input.txt");
    ofstream output_file("output.txt");

    int game_num = 0;
    while (true) {
        int N;
        input_file >> N;
        if (N == 0) {
            break;
        }

        game_num++;
        vector<string> board(N);
        for (int i = 0; i < N; i++) {
            input_file >> board[i];
        }

        char winner = 'N';
        if (has_won(board, 'b', N, 0, 0)) {
            winner = 'B';
        } else if (has_won(board, 'w', N, 0, 0)) {
            winner = 'W';
        }

        output_file << game_num << " " << winner << endl;
    }

    input_file.close();
    output_file.close();

    return 0;
}