#include <iostream>
#include <string>
#include <cctype>

bool isPalindrome(std::string str) {
    std::string cleanStr = "";
    for (char c : str) {
        if (isalpha(c)) {
            cleanStr += tolower(c);
        }
    }
    
    int i = 0, j = cleanStr.length() - 1;
    while(i < j) {
        if (cleanStr[i] != cleanStr[j]) {
            return false;
        }
        i++;
        j--;
    }
    return true;
}

int main() {
    std::string input;
    while (std::getline(std::cin, input)) {
        if (input == "DONE") {
            break;
        }
        if (isPalindrome(input)) {
            std::cout << "You won't be eaten!" << std::endl;
        } else {
            std::cout << "Uh oh.." << std::endl;
        }
    }
    
    return 0;
}