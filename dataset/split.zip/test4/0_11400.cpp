#include <iostream>
#include <vector>
#include <climits>
using namespace std;

int main() {
    int n;
    while (cin >> n && n != 0) {
        vector<vector<int>> categories(n, vector<int>(4));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 4; j++) {
                cin >> categories[i][j];
            }
        }
        
        vector<vector<int>> dp(n+1, vector<int>(n+1, INT_MAX));
        dp[0][0] = 0;

        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= i; j++) {
                for (int k = 0; k <= j; k++) {
                    int prevCost = dp[i-1][j-k];
                    if (prevCost != INT_MAX) {
                        dp[i][j] = min(dp[i][j], prevCost + categories[i-1][1] + categories[i-1][2]*max(0, categories[i-1][4] - j + k));
                    }
                }
            }
        }
        
        int minCost = INT_MAX;
        for (int j = 0; j <= n; j++) {
            minCost = min(minCost, dp[n][j]);
        }
        
        cout << minCost << endl;
    }
    
    return 0;
}