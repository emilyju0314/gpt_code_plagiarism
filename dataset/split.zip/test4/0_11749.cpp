#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstring>

using namespace std;

const int INF = 1e9;
const int MAXN = 505;
const int MAXM = 1005;

int n, m;
vector<pair<int, int>> adj[MAXN];
int cap[MAXN][MAXN];
int flow[MAXN][MAXN];

int maxFlow(int source, int sink) {
    int totalFlow = 0;
    memset(flow, 0, sizeof(flow));

    while (true) {
        vector<int> parent(n + 1, -1);
        queue<int> q;
        parent[source] = source;
        q.push(source);

        while (!q.empty() && parent[sink] == -1) {
            int u = q.front();
            q.pop();

            for (auto &e : adj[u]) {
                int v = e.first;
                if (parent[v] == -1 && cap[u][v] - flow[u][v] > 0) {
                    parent[v] = u;
                    q.push(v);
                }
            }
        }

        if (parent[sink] == -1) break;

        int minCapacity = INF;
        for (int v = sink; v != source; v = parent[v]) {
            int u = parent[v];
            minCapacity = min(minCapacity, cap[u][v] - flow[u][v]);
        }

        for (int v = sink; v != source; v = parent[v]) {
            int u = parent[v];
            flow[u][v] += minCapacity;
            flow[v][u] -= minCapacity;
        }

        totalFlow += minCapacity;
    }

    return totalFlow;
}

int main() {
    while (true) {
        cin >> n >> m;
        if (n == 0 && m == 0) break;

        for (int i = 1; i <= n; i++) {
            adj[i].clear();
        }
        memset(cap, 0, sizeof(cap));

        for (int i = 0; i < m; i++) {
            int u, v, ppa;
            cin >> u >> v >> ppa;
            adj[u].push_back({v, ppa});
            adj[v].push_back({u, ppa});
            cap[u][v] = ppa;
            cap[v][u] = ppa;
        }

        int maxCities = 0;
        for (int i = 1; i <= n; i++) {
            for (auto &e : adj[i]) {
                int j = e.first;
                int ppa = e.second;

                cap[i][j] = INF;
                cap[j][i] = -ppa;

                maxCities = max(maxCities, maxFlow(i, j));
                
                cap[i][j] = ppa;
                cap[j][i] = ppa;
            }
        }

        cout << maxCities << endl;
    }

    return 0;
}