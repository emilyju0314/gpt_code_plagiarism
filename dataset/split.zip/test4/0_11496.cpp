#include <iostream>

int main() {
    int N;
    while (true) {
        std::cin >> N;
        if (N == 0) {
            break;
        }
        
        int peaks = 0;
        int prev, current, next;
        std::cin >> prev;
        std::cin >> current;
        for (int i = 2; i < N; i++) {
            std::cin >> next;
            if ((current > prev && current > next) || (current < prev && current < next)) {
                peaks++;
            }
            prev = current;
            current = next;
        }
        
        // check the first and last elements
        if ((current > prev && current > next) || (current < prev && current < next)) {
            peaks++;
        }
        
        std::cout << peaks << std::endl;
    }
    
    return 0;
}