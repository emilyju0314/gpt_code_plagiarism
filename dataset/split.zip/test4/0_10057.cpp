#include <iostream>
#include <vector>
#include <cmath>
#include <unordered_set>

int main() {
    int n;
    while (std::cin >> n) {
        if (n == 0) {
            break;
        }
        
        std::vector<int> numbers(n);
        for (int i = 0; i < n; ++i) {
            std::cin >> numbers[i];
        }
        
        int minA = 0;
        int minSum = INT_MAX;
        for (int A = 0; A <= 65535; ++A) {
            int sum = 0;
            for (int i = 0; i < n; ++i) {
                sum += std::abs(numbers[i] - A);
            }
            if (sum < minSum) {
                minSum = sum;
                minA = A;
            }
        }
        
        std::unordered_set<int> uniqueA;
        for (int i = 0; i < n; ++i) {
            uniqueA.insert(minA + numbers[i]);
            uniqueA.insert(minA - numbers[i]);
        }
        
        std::cout << minA << " " << n << " " << uniqueA.size() << std::endl;
    }
    
    return 0;
}