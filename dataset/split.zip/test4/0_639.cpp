#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n;
    while (cin >> n) {
        if (n == 0) {
            break;
        }

        vector<string> board(n);
        for (int i = 0; i < n; i++) {
            cin >> board[i];
        }

        int maxRooks = 0;
        for (int i = 0; i < (1 << n); i++) {
            int rooks = 0;
            for (int j = 0; j < n; j++) {
                int count = 0;
                for (int k = 0; k < n; k++) {
                    if ((i & (1 << k)) != 0 && board[j][k] == '.') {
                        count++;
                    }
                }
                if (count == 1) {
                    rooks++;
                }
            }
            maxRooks = max(maxRooks, rooks);
        }

        cout << maxRooks << endl;
    }

    return 0;
}