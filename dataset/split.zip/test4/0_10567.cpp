#include <iostream>
#include <string>

using namespace std;

int main() {
    string S;
    int Q;
    
    // Input the string S and the number of queries Q
    cin >> S;
    cin >> Q;
    
    // Process each query
    for (int i = 0; i < Q; i++) {
        string query;
        cin >> query;
        
        int start = -1, end = -1;
        
        // Find the subsequence in S that matches the query
        int j = 0;
        for (int k = 0; k < S.size() && j < query.size(); k++) {
            if (S[k] == query[j]) {
                if (start == -1) {
                    start = k;
                }
                end = k;
                j++;
            }
        }
        
        // Check if the query was matched
        if (j == query.size()) {
            cout << "Matched " << start << " " << end << endl;
        } else {
            cout << "Not matched" << endl;
        }
    }
    
    return 0;
}