#include <iostream>
#include <cmath>

bool isPrime(int n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    
    if (n % 2 == 0 || n % 3 == 0) return false;
    
    for (int i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) {
            return false;
        }
    }
    
    return true;
}

int main() {
    int T;
    std::cin >> T;
    
    for (int i = 1; i <= T; i++) {
        int K;
        std::cin >> K;
        
        int A = 2;
        int B = K / A;
        
        while (!isPrime(A) || !isPrime(B) || A == B) {
            A++;
            B = K / A;
        }
        
        int C = 2;
        int D = K / C;
        
        while (!isPrime(C) || !isPrime(D) || C == D || C == A || C == B || D == A || D == B) {
            C++;
            D = K / C;
        }
        
        std::cout << "Case #" << i << ": " << K << " = " << A << " * " << B << " = " << C << " * " << D << "\n";
    }
    
    return 0;
}