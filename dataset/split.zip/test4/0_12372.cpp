#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T; // number of test cases
    for(int i = 1; i <= T; i++) {
        int L, W, H;
        cin >> L >> W >> H; // length, width, height of the box
        
        if((L <= 20 && W <= 20 && H <= 20) || (L <= 20 && W <= 20 && H <= 20) || (L <= 20 && W <= 20 && H <= 20)) {
            cout << "Case " << i << ": good" << endl;
        } else {
            cout << "Case " << i << ": bad" << endl;
        }
    }

    return 0;
}