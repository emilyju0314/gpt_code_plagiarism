#include <iostream>
#include <vector>

int n, w, h;

int main() {
    while (std::cin >> n >> w >> h) {
        if (n == 0 && w == 0 && h == 0) break;

        // Implement your logic to find the number of distinct free n-polyominoes that fit into rectangle w*h
        
        std::cout << result << std::endl; // Output the result
    }

    return 0;
}