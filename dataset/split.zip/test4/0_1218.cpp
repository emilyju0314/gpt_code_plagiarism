#include <iostream>
#include <vector>
#include <set>

using namespace std;

int main() {
    int N;
    while (true) {
        cin >> N;
        if (N == -1) {
            break;
        }
        
        vector<set<int>> adj(N + 1);
        vector<bool> isServer(N + 1, false);

        for (int i = 0; i < N - 1; i++) {
            int u, v;
            cin >> u >> v;
            adj[u].insert(v);
            adj[v].insert(u);
        }

        for (int i = 1; i <= N; i++) {
            bool isClient = true;
            for (int j : adj[i]) {
                if (isServer[j]) {
                    isClient = false;
                    break;
                }
            }
            if (isClient) {
                isServer[i] = true;
            }
        }

        int perfectServiceNumber = 0;
        for (int i = 1; i <= N; i++) {
            if (isServer[i]) {
                perfectServiceNumber++;
            }
        }

        cout << perfectServiceNumber << endl;
    }

    return 0;
}