#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main() {
    int n;
    
    while (cin >> n) {
        vector<int> sequence(n);
        vector<bool> diffExists(n, false);
        
        for (int i = 0; i < n; i++) {
            cin >> sequence[i];
        }
        
        for (int i = 1; i < n; i++) {
            int diff = abs(sequence[i] - sequence[i-1]);
            if (diff >= 1 && diff <= n-1) {
                diffExists[diff] = true;
            }
        }
        
        bool jolly = true;
        for (int i = 1; i < n; i++) {
            if (!diffExists[i]) {
                jolly = false;
                break;
            }
        }
        
        if (jolly) {
            cout << "Jolly" << endl;
        } else {
            cout << "Not jolly" << endl;
        }
    }
    
    return 0;
}