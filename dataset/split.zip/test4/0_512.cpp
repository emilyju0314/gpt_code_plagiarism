#include <iostream>
#include <vector>
#include <sstream>
#include <string>

void deleteRows(std::vector<std::vector<int>>& spreadsheet, int row) {
    spreadsheet.erase(spreadsheet.begin() + row - 1);
}

void deleteColumns(std::vector<std::vector<int>>& spreadsheet, std::vector<int> columns) {
    for (int i = columns.size() - 1; i >= 0; i--) {
        int col = columns[i];
        for (int j = 0; j < spreadsheet.size(); j++) {
            spreadsheet[j].erase(spreadsheet[j].begin() + col - 1);
        }
    }
}

void insertRows(std::vector<std::vector<int>>& spreadsheet, std::vector<int> rows) {
    for (int i = rows.size() - 1; i >= 0; i--) {
        int row = rows[i];
        spreadsheet.insert(spreadsheet.begin() + row - 1, std::vector<int>(spreadsheet[0].size(), 0));
    }
}

void insertColumns(std::vector<std::vector<int>>& spreadsheet, std::vector<int> columns) {
    for (int i = columns.size() - 1; i >= 0; i--) {
        int col = columns[i];
        for (int j = 0; j < spreadsheet.size(); j++) {
            spreadsheet[j].insert(spreadsheet[j].begin() + col - 1, 0);
        }
    }
}

void exchangeCells(std::vector<std::vector<int>>& spreadsheet, int r1, int c1, int r2, int c2) {
    std::swap(spreadsheet[r1 - 1][c1 - 1], spreadsheet[r2 - 1][c2 - 1]);
}

int main() {
    int spreadsheetNum = 1;

    int rows, cols;
    while (std::cin >> rows >> cols && rows != 0 && cols != 0) {
        std::vector<std::vector<int>> spreadsheet(rows, std::vector<int>(cols, 0));

        int operations;
        std::cin >> operations;
        for (int i = 0; i < operations; i++) {
            std::string operation;
            std::cin >> operation;

            if (operation == "DR") {
                int row;
                std::vector<int> rowsToDelete;
                while (std::cin >> row && row != 0) {
                    rowsToDelete.push_back(row);
                }
                deleteRows(spreadsheet, rowsToDelete[0]);
            } else if (operation == "DC") {
                int col;
                std::vector<int> colsToDelete;
                while (std::cin >> col && col != 0) {
                    colsToDelete.push_back(col);
                }
                deleteColumns(spreadsheet, colsToDelete);
            } else if (operation == "IR") {
                int row;
                std::vector<int> rowsToInsert;
                while (std::cin >> row && row != 0) {
                    rowsToInsert.push_back(row);
                }
                insertRows(spreadsheet, rowsToInsert);
            } else if (operation == "IC") {
                int col;
                std::vector<int> colsToInsert;
                while (std::cin >> col && col != 0) {
                    colsToInsert.push_back(col);
                }
                insertColumns(spreadsheet, colsToInsert);
            } else if (operation == "EX") {
                int r1, c1, r2, c2;
                std::cin >> r1 >> c1 >> r2 >> c2;
                exchangeCells(spreadsheet, r1, c1, r2, c2);
            }
        }

        std::cout << "Spreadsheet #" << spreadsheetNum << std::endl;
        
        int queryRow, queryCol;
        while (std::cin >> queryRow >> queryCol && queryRow != 0 && queryCol != 0) {
            if (queryRow <= spreadsheet.size() && queryCol <= spreadsheet[0].size()) {
                std::cout << "Cell data in (" << queryRow << "," << queryCol << ") moved to (" 
                          << (rows - spreadsheet.size() + queryRow) << "," 
                          << (cols - spreadsheet[0].size() + queryCol) << ")" << std::endl;
            } else {
                std::cout << "Cell data in (" << queryRow << "," << queryCol << ") GONE" << std::endl;
            }
        }

        spreadsheetNum++;
        std::cout << std::endl; // Separate output for different spreadsheets
    }

    return 0;
}