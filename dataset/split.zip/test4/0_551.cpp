#include <iostream>
#include <stack>
#include <string>

bool isProperlyNested(std::string expression) {
    std::stack<char> brackets;
    for (int i = 0; i < expression.length(); i++) {
        if (expression[i] == '(' || expression[i] == '[' || expression[i] == '{' || expression[i] == '<' || (expression[i] == '*' && expression[i+1] == '(')) {
            brackets.push(expression[i]);
        } else if (expression[i] == ')' || expression[i] == ']' || expression[i] == '}' || expression[i] == '>') {
            if (brackets.empty()) {
                return false;
            }
            char opening = brackets.top();
            if ((opening == '(' && expression[i] != ')') || (opening == '[' && expression[i] != ']') || (opening == '{' && expression[i] != '}') || (opening == '<' && expression[i] != '>') || (opening == '*' && expression[i] != '*' && expression[i+1] != ')')) {
                return false;
            }
            brackets.pop();
        }
    }
    return brackets.empty();
}

int main() {
    std::string line;
    int position = 1;
    while (std::getline(std::cin, line)) {
        if (isProperlyNested(line)) {
            std::cout << "YES" << std::endl;
        } else {
            int errorPos = position;
            std::cout << "NO " << errorPos << std::endl;
        }
        position++;
    }
    return 0;
}