#include <iostream>
#include <algorithm>
#include <vector>
#include <numeric>

using namespace std;

long long gcd(long long a, long long b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

long long magicalGCD(vector<long long>& sequence) {
    int n = sequence.size();
    long long max_gcd = 0;
    for (int i = 0; i < n; i++) {
        long long temp_gcd = sequence[i];
        for (int j = i; j < n; j++) {
            temp_gcd = gcd(temp_gcd, sequence[j]);
            long long current_gcd = temp_gcd * (j - i + 1);
            max_gcd = max(max_gcd, current_gcd);
        }
    }
    return max_gcd;
}

int main() {
    int T;
    cin >> T;
    while (T--) {
        int n;
        cin >> n;
        vector<long long> sequence(n);
        for (int i = 0; i < n; i++) {
            cin >> sequence[i];
        }
        long long result = magicalGCD(sequence);
        cout << result << endl;
    }
    return 0;
}