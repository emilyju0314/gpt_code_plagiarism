#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>

int main() {
    std::unordered_map<char, int> order;
    std::vector<std::string> inputStrings;

    // Input
    std::string input;
    while (std::getline(std::cin, input) && input != "#") {
        inputStrings.push_back(input);
        for (char ch : input) {
            if (order.find(ch) == order.end()) {
                order[ch] = 0;
            }
        }
    }

    // Determine the ordering
    for (int i = 1; i < inputStrings.size(); i++) {
        std::string prev = inputStrings[i - 1];
        std::string curr = inputStrings[i];
        int length = std::min(prev.length(), curr.length());

        for (int j = 0; j < length; j++) {
            if (prev[j] != curr[j]) {
                order[prev[j]]++;
                order[curr[j]]--;
                break;
            }
        }
    }

    // Output
    std::sort(inputStrings.begin(), inputStrings.end(), [&order](const std::string &s1, const std::string &s2) {
        int length = std::min(s1.length(), s2.length());
        for (int i = 0; i < length; i++) {
            if (order[s1[i]] < order[s2[i]]) {
                return true;
            } else if (order[s1[i]] > order[s2[i]]) {
                return false;
            }
        }
        return s1.length() < s2.length();
    });

    for (const auto &it : order) {
        std::cout << it.first;
    }
    std::cout << std::endl;

    return 0;
}