#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int v, e;
        cin >> v >> e;

        vector<vector<int>> graph(v);

        for (int i = 0; i < e; i++) {
            int f, t;
            cin >> f >> t;
            graph[f].push_back(t);
            graph[t].push_back(f);
        }

        unordered_set<int> guards;
        bool impossible = false;

        for (int i = 0; i < v; i++) {
            if (guards.find(i) != guards.end()) {
                continue;
            }

            int guard = i;
            for (int j : graph[i]) {
                if (guards.find(j) != guards.end()) {
                    impossible = true;
                    break;
                }
                guards.insert(j);
            }

            if (impossible) {
                break;
            }
            guards.insert(guard);
        }

        if (impossible) {
            cout << "-1\n";
        } else {
            cout << guards.size() << endl;
        }
    }

    return 0;
}