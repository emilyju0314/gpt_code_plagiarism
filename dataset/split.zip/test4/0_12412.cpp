#include <iostream>
#include <map>
#include <vector>
#include <iomanip>

struct Student {
    int CID;
    std::string name;
    int Chinese;
    int Mathematics;
    int English;
    int Programming;
};

std::map<long long, Student> studentDatabase;
std::vector<long long> studentOrder;

void addStudent() {
    // Implement the logic for adding a student
}

void removeStudent() {
    // Implement the logic for removing a student
}

void queryStudent() {
    // Implement the logic for querying a student
}

void showStatistics() {
    // Implement the logic for showing statistics
}

int main() {
    int choice = -1;
    
    while (choice != 0) {
        std::cout << "Welcome to Student Performance Management System (SPMS)." << std::endl;
        std::cout << "1 - Add" << std::endl;
        std::cout << "2 - Remove" << std::endl;
        std::cout << "3 - Query" << std::endl;
        std::cout << "4 - Show ranking" << std::endl;
        std::cout << "5 - Show Statistics" << std::endl;
        std::cout << "0 - Exit" << std::endl;
        
        std::cin >> choice;
        
        switch(choice) {
            case 1:
                addStudent();
                break;
            case 2:
                removeStudent();
                break;
            case 3:
                queryStudent();
                break;
            case 4:
                std::cout << "Showing the ranklist hurts students' self-esteem. Don't do that." << std::endl;
                break;
            case 5:
                showStatistics();
                break;
            case 0:
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
                break;
        }
    }
    
    return 0;
}