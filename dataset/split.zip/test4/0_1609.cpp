#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        vector<string> teams(n);
        for (int i = 0; i < n; i++) {
            cin >> teams[i];
        }

        vector<int> order(n);
        for (int i = 0; i < n; i++) {
            order[i] = i + 1;
        }

        while (order.size() > 1) {
            vector<int> winners;
            for (int i = 0; i < order.size(); i += 2) {
                if (teams[order[i] - 1][order[i + 1] - 1] == '1') {
                    winners.push_back(order[i]);
                } else {
                    winners.push_back(order[i + 1]);
                }
            }
            order = winners;
        }

        for (int i = 0; i < n - 1; i++) {
            cout << 1 << " " << order[0] << endl;
        }
    }

    return 0;
}