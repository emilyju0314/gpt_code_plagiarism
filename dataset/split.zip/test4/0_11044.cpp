#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t; // Number of test cases

    for (int i = 0; i < t; i++) {
        int n, m;
        cin >> n >> m; // Size of the grid

        // Calculate the minimum number of sonars needed
        int sonars = ceil((n * m) / 3.0);
        
        cout << sonars << endl;
    }

    return 0;
}