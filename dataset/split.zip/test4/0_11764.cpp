#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T; // number of test cases

    for (int i = 0; i < T; i++) {
        int N;
        cin >> N; // number of walls

        int heights[N];
        for (int j = 0; j < N; j++) {
            cin >> heights[j]; // heights of walls
        }

        int highJumps = 0, lowJumps = 0;
        for (int j = 0; j < N - 1; j++) {
            if (heights[j] < heights[j+1]) {
                highJumps++;
            } else if (heights[j] > heights[j+1]) {
                lowJumps++;
            }
        }

        cout << "Case " << i+1 << ": " << highJumps << " " << lowJumps << endl;
    }

    return 0;
}