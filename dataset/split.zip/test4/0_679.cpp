#include <iostream>
#include <vector>

int calculateStopPosition(int D, int I) {
    int node = 1;
    for (int i = 0; i < D - 1; i++) {
        if (I % 2 == 1) {
            node = node * 2;
            I = (I + 1) / 2;
        } else {
            node = node * 2 + 1;
            I = I / 2;
        }
    }
    return node;
}

int main() {
    int T;
    std::cin >> T;

    std::vector<std::pair<int, int>> testCases(T);
    for (int i = 0; i < T; i++) {
        int D, I;
        std::cin >> D >> I;
        testCases[i] = {D, I};
    }

    for (int i = 0; i < T; i++) {
        int D = testCases[i].first;
        int I = testCases[i].second;

        int stopPosition = calculateStopPosition(D, I);
        std::cout << stopPosition << std::endl;
    }

    return 0;
}