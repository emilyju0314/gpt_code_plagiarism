#include <iostream>
#include <algorithm>

void generatePermutations(std::string prefix, std::string remaining) {
    if (remaining.empty()) {
        std::cout << prefix << std::endl;
    } else {
        for (int i = 0; i < remaining.size(); i++) {
            generatePermutations(prefix + remaining[i], remaining.substr(0, i) + remaining.substr(i + 1));
        }
    }
}

int main() {
    std::string line;
    
    while (std::cin >> line) {
        std::sort(line.begin(), line.end());
        generatePermutations("", line);
        std::cout << std::endl;
    }
    
    return 0;
}