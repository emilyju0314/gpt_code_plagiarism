#include <iostream>
#include <string>

void convertTree(std::string inputTree, std::string &outputTree) {
    int level = 0;
    for (char c : inputTree) {
        if (c == '|') {
            outputTree.push_back('(');
            level++;
        } else if (c == '-') {
            outputTree.push_back(')');
            outputTree.push_back('(');
        } else if (c == '#') {
            outputTree.push_back(')');
        } else if (c != ' ') {
            if (level == 0) {
                outputTree.push_back(c);
            }
        }
    }
}

int main() {
    int T;
    std::cin >> T;
    std::cin.ignore(); // ignore newline

    for (int i = 0; i < T; i++) {
        std::string inputTree;
        std::string outputTree;

        std::getline(std::cin, inputTree);

        convertTree(inputTree, outputTree);

        std::cout << outputTree << std::endl;
    }

    return 0;
}