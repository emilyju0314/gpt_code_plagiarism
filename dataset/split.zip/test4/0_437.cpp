#include <iostream>
#include <algorithm>
#include <vector>

struct Block {
    int x, y, z;
};

int maxHeight(std::vector<Block>& blocks) {
    int n = blocks.size();
    std::vector<int> dp(n);
    int maxHeight = 0;

    std::sort(blocks.begin(), blocks.end(), [](const Block& a, const Block& b) {
        return a.x * a.y > b.x * b.y;
    });

    for (int i = 0; i < n; i++) {
        dp[i] = blocks[i].z;
        for (int j = 0; j < i; j++) {
            if (blocks[j].x > blocks[i].x && blocks[j].y > blocks[i].y) {
                dp[i] = std::max(dp[i], dp[j] + blocks[i].z);
            }
        }
        maxHeight = std::max(maxHeight, dp[i]);
    }

    return maxHeight;
}

int main() {
    int caseNum = 1;
    int n;

    while (std::cin >> n && n != 0) {
        std::vector<Block> blocks(n);
        for (int i = 0; i < n; i++) {
            std::cin >> blocks[i].x >> blocks[i].y >> blocks[i].z;
        }

        int max_height = maxHeight(blocks);
        std::cout << "Case " << caseNum++ << ": maximum height = " << max_height << std::endl;
    }

    return 0;
}