#include <iostream>
using namespace std;

int main() {
    char grid[9][9] = {
        {'R', 'A', 'K', 'I', 'B', 'U', 'L', 'A', 'S'},
        {'U', 'N', 'N', 'Y', 'I', 'O', 'A', 'H', 'N'},
        {'S', 'N', 'O', 'M', 'I', 'D', 'A', 'O', 'Y'},
        {'H', 'P', 'I', 'B', 'W', 'S', 'I', 'P', 'U'},
        {'I', 'D', 'A', 'A', 'H', 'R', 'L', 'B', 'S'},
        {'P', 'W', 'A', 'H', 'I', 'O', 'S', 'K', 'R'},
        {'B', 'Y', 'K', 'O', 'I', 'N', 'R', 'I', 'A'},
        {'I', 'U', 'W', 'W', 'L', 'B', 'A', 'S', 'O'},
        {'U', 'A', 'S', 'N', 'Y', 'A', 'M', 'I', 'S'}
    };

    // Count the occurrence of each alphabetical letter
    int charCount[26] = {0};
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            charCount[grid[i][j] - 'A']++;
        }
    }

    // Find the name hidden twice
    string name;
    for (int i = 0; i < 26; i++) {
        if (charCount[i] == 2) {
            name += (char)('A' + i);
        }
    }

    cout << name << endl;

    return 0;
}