#include <iostream>
#include <vector>
#include <unordered_map>
#include <queue>

using namespace std;

int findLargestGroupOfFriends(int N, int M, vector<pair<int, int>>& friendships) {
    unordered_map<int, vector<int>> adjList;
    
    for(auto f : friendships) {
        adjList[f.first].push_back(f.second);
        adjList[f.second].push_back(f.first);
    }
    
    vector<bool> visited(N+1, false);
    int maxGroupSize = 0;
    
    for(int i = 1; i <= N; i++) {
        if(!visited[i]) {
            int groupSize = 0;
            
            queue<int> q;
            q.push(i);
            visited[i] = true;
            
            while(!q.empty()) {
                int person = q.front();
                q.pop();
                groupSize++;
                
                for(int friend : adjList[person]) {
                    if(!visited[friend]) {
                        q.push(friend);
                        visited[friend] = true;
                    }
                }
            }
            
            maxGroupSize = max(maxGroupSize, groupSize);
        }
    }
    
    return maxGroupSize;
}

int main() {
    int T;
    cin >> T;
    
    while(T--) {
        int N, M;
        cin >> N >> M;
        
        vector<pair<int, int>> friendships;
        for(int i = 0; i < M; i++) {
            int A, B;
            cin >> A >> B;
            friendships.push_back({A, B});
        }
        
        int largestGroup = findLargestGroupOfFriends(N, M, friendships);
        cout << largestGroup << endl;
    }
    
    return 0;
}