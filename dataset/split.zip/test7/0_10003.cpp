#include <iostream>
#include <vector>

using namespace std;

int minCost(vector<int> cuts, int length) {
    int n = cuts.size();
    vector<vector<int>> dp(n + 2, vector<int>(n + 2, 0));
    
    for (int len = 2; len <= n + 1; len++) {
        for (int i = 0; i + len <= n + 1; i++) {
            int j = i + len;
            dp[i][j] = INT_MAX;
            for (int k = i + 1; k < j; k++) {
                dp[i][j] = min(dp[i][j], cuts[j] - cuts[i] + dp[i][k] + dp[k][j]);
            }
        }
    }
    
    return dp[0][n + 1];
}

int main() {
    
    int length, n;
    
    while (true) {
        cin >> length;
        
        if (length == 0) {
            break;
        }
        
        cin >> n;
        vector<int> cuts(n + 2);
        cuts[0] = 0;
        cuts[n + 1] = length;
        
        for (int i = 1; i <= n; i++) {
            cin >> cuts[i];
        }
        
        int cost = minCost(cuts, length);
        cout << "The minimum cutting is " << cost << "." << endl;
    }
    
    return 0;
}