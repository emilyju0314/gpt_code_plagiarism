#include <iostream>
#include <string>

using namespace std;

int calculateBlackPixels(string s, int &index) {
    char c = s[index++];
    if (c == 'p') {
        int sum = 0;
        for (int i = 0; i < 4; i++) {
            sum += calculateBlackPixels(s, index);
        }
        return sum;
    } else if (c == 'f') {
        return 1024;
    } else {
        return 0;
    }
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        string s1, s2;
        cin >> s1 >> s2;

        int index1 = 0, index2 = 0;
        int result = calculateBlackPixels(s1, index1) + calculateBlackPixels(s2, index2);

        cout << "There are " << result << " black pixels." << endl;
    }

    return 0;
}