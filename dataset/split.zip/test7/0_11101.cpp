#include <iostream>
#include <vector>
#include <cmath>

struct Point {
    int x;
    int y;
};

int calculateDistance(Point p1, Point p2) {
    return std::abs(p1.x - p2.x) + std::abs(p1.y - p2.y);
}

int minimumWalkingDistance(std::vector<Point>& mall1, std::vector<Point>& mall2) {
    int minDistance = INT_MAX;
    
    for (int i = 0; i < mall1.size(); i++) {
        for (int j = 0; j < mall2.size(); j++) {
            int distance = calculateDistance(mall1[i], mall2[j]);
            if (distance < minDistance) {
                minDistance = distance;
            }
        }
    }
    
    return minDistance;
}

int main() {
    int p1, p2;
    
    while (true) {
        std::cin >> p1;
        
        if (p1 == 0) {
            break;
        }
        
        std::vector<Point> mall1(p1);
        
        for (int i = 0; i < p1; i++) {
            int x, y;
            std::cin >> x >> y;
            mall1[i] = {x, y};
        }
        
        std::cin >> p2;
        
        std::vector<Point> mall2(p2);
        
        for (int i = 0; i < p2; i++) {
            int x, y;
            std::cin >> x >> y;
            mall2[i] = {x, y};
        }
        
        int minDistance = minimumWalkingDistance(mall1, mall2);
        std::cout << minDistance << std::endl;
    }
    
    return 0;
}