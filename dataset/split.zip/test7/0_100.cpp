#include <iostream>

int cycleLength(int n) {
    int length = 1;
    while (n != 1) {
        if (n % 2 == 0) {
            n = n / 2;
        } else {
            n = 3 * n + 1;
        }
        length++;
    }
    return length;
}

int maxCycleLength(int i, int j) {
    int max = 0;
    for (int n = i; n <= j; n++) {
        int length = cycleLength(n);
        if (length > max) {
            max = length;
        }
    }
    return max;
}

int main() {
    int i, j;
    while (std::cin >> i >> j) {
        int max_length = maxCycleLength(i, j);
        std::cout << i << " " << j << " " << max_length << std::endl;
    }
    return 0;
}