#include <iostream>
#include <vector>

using namespace std;

void explore(vector<vector<char>>& grid, int i, int j) {
    if (i < 0 || i >= grid.size() || j < 0 || j >= grid[0].size() || grid[i][j] != '@') {
        return;
    }

    grid[i][j] = '*'; // mark as visited

    explore(grid, i+1, j);
    explore(grid, i-1, j);
    explore(grid, i, j+1);
    explore(grid, i, j-1);
    explore(grid, i+1, j+1);
    explore(grid, i+1, j-1);
    explore(grid, i-1, j+1);
    explore(grid, i-1, j-1);
}

int countOilDeposits(vector<vector<char>>& grid) {
    int count = 0;

    for (int i = 0; i < grid.size(); i++) {
        for (int j = 0; j < grid[0].size(); j++) {
            if (grid[i][j] == '@') {
                explore(grid, i, j);
                count++;
            }
        }
    }

    return count;
}

int main() {
    int m, n;
    while (cin >> m >> n && m != 0) {
        vector<vector<char>> grid(m, vector<char>(n));
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                cin >> grid[i][j];
            }
        }

        int numDeposits = countOilDeposits(grid);
        cout << numDeposits << endl;
    }

    return 0;
}