#include <iostream>
#include <vector>

int main() {
    int n, m;
    while (std::cin >> n >> m) {
        std::vector<int> irrelevant;
        for (int i = 1; i <= n; i++) {
            if (n % 2 == 0 || i % 2 != 0) {
                irrelevant.push_back(i);
            }
        }
        std::cout << irrelevant.size() << std::endl;
        for (int i : irrelevant) {
            std::cout << i << " ";
        }
        std::cout << std::endl;
    }
    return 0;
}