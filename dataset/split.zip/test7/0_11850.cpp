#include <iostream>
#include <vector>

int main() {
    int n;
    
    while (true) {
        std::cin >> n;
        if (n == 0) {
            break;
        }
        
        std::vector<int> distances(n);
        
        for (int i = 0; i < n; i++) {
            std::cin >> distances[i];
        }
        
        bool possible = false;
        for (int i = 0; i < n; i++) {
            if (distances[i] + 200 >= 1422) {
                possible = true;
                break;
            }
        }
        
        if (possible) {
            std::cout << "POSSIBLE" << std::endl;
        } else {
            std::cout << "IMPOSSIBLE" << std::endl;
        }
    }
    
    return 0;
}