#include <iostream>
#include <vector>
#include <queue>

using namespace std;

const int MAX_V = 100;
const int MAX_E = 500;

int V, E;
vector<pair<int, char>> graph[MAX_V + 1];
vector<int> circuit;
int inDegree[MAX_V + 1];
int outDegree[MAX_V + 1];

void eulerDfs(int u) {
    while (!graph[u].empty()) {
        pair<int, char> edge = graph[u].back();
        graph[u].pop_back();
        if (edge.second == 'D') {
            eulerDfs(edge.first);
        } else {
            graph[edge.first].emplace_back(u, ' ');
            eulerDfs(edge.first);
        }
    }
    circuit.push_back(u);
}

bool isEulerCircuitPossible() {
    int start = -1, end = -1;
    for (int i = 1; i <= V; i++) {
        if (inDegree[i] != outDegree[i]) {
            if (inDegree[i] == outDegree[i] + 1) {
                if (end != -1) return false;
                end = i;
            } else if (inDegree[i] + 1 == outDegree[i]) {
                if (start != -1) return false;
                start = i;
            } else {
                return false;
            }
        }
    }
    if (start == -1) {
        for (int i = 1; i <= V; i++) {
            if (outDegree[i] > 0) {
                start = i;
                break;
            }
        }
    }
    eulerDfs(start);
    return circuit.size() == E + 1;
}

int main() {
    int T;
    cin >> T;

    for (int t = 0; t < T; t++) {
        cin >> V >> E;

        for (int i = 1; i <= V; i++) {
            graph[i].clear();
            inDegree[i] = outDegree[i] = 0;
        }
        circuit.clear();

        for (int i = 0; i < E; i++) {
            int a, b;
            char type;
            cin >> a >> b >> type;
            graph[a].emplace_back(b, type);
            if (type == 'D') {
                outDegree[a]++;
                inDegree[b]++;
            } else {
                outDegree[a]++;
                outDegree[b]++;
            }
        }

        if (isEulerCircuitPossible()) {
            for (int i = circuit.size() - 1; i >= 0; i--) {
                cout << circuit[i] << " ";
            }
            cout << endl;
        } else {
            cout << "No euler circuit exist" << endl;
        }
        cout << endl;
    }

    return 0;
}