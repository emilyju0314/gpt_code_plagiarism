#include <iostream>
#include <string>

int main() {
    int a, b;
    while (std::cin >> a >> b) {
        if (a == 0 && b == 0) {
            break;
        }
        
        int digit_count[10] = {0};
        for (int i = a; i <= b; ++i) {
            std::string num_str = std::to_string(i);
            for (char& c : num_str) {
                digit_count[c - '0']++;
            }
        }

        for (int i = 0; i < 10; ++i) {
            std::cout << digit_count[i];
            if (i < 9) {
                std::cout << " ";
            }
        }
        std::cout << std::endl;
    }

    return 0;
}