#include <iostream>
#include <string>
#include <map>

using namespace std;

int main() {
    int round = 1;
    
    while(true) {
        string solution, guesses;
        cin >> solution;
        if(solution == "-1") {
            break;
        }
        cin >> guesses;
        
        map<char, bool> solved;
        map<char, bool> wrongGuesses;
        int mistakes = 0;
        bool win = false;
        
        for(char c : solution) {
            solved[c] = false;
        }
        
        for(char c : guesses) {
            if(solved.count(c) > 0) {
                solved[c] = true;
            } else {
                if(wrongGuesses.count(c) == 0) {
                    wrongGuesses[c] = true;
                    mistakes++;
                }
            }
            
            if(mistakes >= 7) {
                break;
            }
            
            bool allSolved = true;
            for(auto it = solved.begin(); it != solved.end(); ++it) {
                if(!it->second) {
                    allSolved = false;
                    break;
                }
            }
            
            if(allSolved) {
                win = true;
                break;
            }
        }
        
        cout << "Round " << round << endl;
        if(win) {
            cout << "You win." << endl;
        } else if(mistakes >= 7) {
            cout << "You lose." << endl;
        } else {
            cout << "You chickened out." << endl;
        }
        
        round++;
    }
    
    return 0;
}