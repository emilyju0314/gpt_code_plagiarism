#include <iostream>
#include <vector>

using namespace std;

bool canLiquidateDebentures(int B, int N, vector<int>& reserves, vector<vector<int>>& debentures) {
    vector<int> balance(B+1, 0);
    
    for (int i = 0; i < N; i++) {
        int debtor = debentures[i][0];
        int creditor = debentures[i][1];
        int value = debentures[i][2];
        
        balance[debtor] -= value;
        balance[creditor] += value;
    }
    
    for (int i = 1; i <= B; i++) {
        if (balance[i] < 0 && abs(balance[i]) > reserves[i-1]) {
            return false;
        }
    }
    
    return true;
}

int main() {
    int B, N;
    
    while (true) {
        cin >> B >> N;
        
        if (B == 0 && N == 0) {
            break;
        }
        
        vector<int> reserves(B);
        for (int i = 0; i < B; i++) {
            cin >> reserves[i];
        }
        
        vector<vector<int>> debentures(N, vector<int>(3));
        for (int i = 0; i < N; i++) {
            cin >> debentures[i][0] >> debentures[i][1] >> debentures[i][2];
        }
        
        if (canLiquidateDebentures(B, N, reserves, debentures)) {
            cout << "S" << endl;
        } else {
            cout << "N" << endl;
        }
    }
    
    return 0;
}