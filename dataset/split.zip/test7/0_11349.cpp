#include <iostream>
#include <vector>

bool isSymmetric(std::vector<std::vector<int>> matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (matrix[i][j] != matrix[n - 1 - i][n - 1 - j]) {
                return false;
            }
        }
    }
    return true;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        std::cin >> n;

        std::vector<std::vector<int>> matrix(n, std::vector<int>(n));

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                std::cin >> matrix[i][j];
            }
        }

        if (isSymmetric(matrix, n)) {
            std::cout << "Test #" << t << ": Symmetric." << std::endl;
        } else {
            std::cout << "Test #" << t << ": Non-symmetric." << std::endl;
        }
    }

    return 0;
}