#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int T;
    std::cin >> T;

    for (int i = 0; i < T; i++) {
        int N, M;
        std::cin >> N >> M;

        std::vector<int> withdrawnPlayers(M);
        for (int j = 0; j < M; j++) {
            std::cin >> withdrawnPlayers[j];
        }

        std::sort(withdrawnPlayers.begin(), withdrawnPlayers.end());

        int walkoverMatches = 0;
        for (int j = 1; j <= 2*N; j+=2) {
            if (std::binary_search(withdrawnPlayers.begin(), withdrawnPlayers.end(), j) && std::binary_search(withdrawnPlayers.begin(), withdrawnPlayers.end(), j+1)) {
                walkoverMatches++;
            }
        }

        std::cout << walkoverMatches << std::endl;
    }

    return 0;
}