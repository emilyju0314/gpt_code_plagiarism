#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int main() {
    int N;
    while (std::cin >> N) {
        std::vector<std::string> filenames(N);
        int max_length = 0;

        for (int i = 0; i < N; i++) {
            std::cin >> filenames[i];
            max_length = std::max(max_length, static_cast<int>(filenames[i].length()));
        }

        std::sort(filenames.begin(), filenames.end());

        int num_columns = 60 / (max_length + 3);
        int num_rows = (N + num_columns - 1) / num_columns;

        for (int i = 0; i < num_rows; i++) {
            for (int j = 0; j < num_columns; j++) {
                int index = j * num_rows + i;
                if (index < N) {
                    std::cout << filenames[index];
                    int spaces = max_length + 3 - filenames[index].length();
                    std::cout << std::string(spaces, ' ');
                }
            }
            std::cout << std::endl;
        }

        std::cout << "------------------------------------------------------------" << std::endl;
    }

    return 0;
}