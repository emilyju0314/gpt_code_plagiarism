#include <iostream>
#include <vector>
#include <map>

using namespace std;

int main() {
    int d;
    cin >> d;

    for (int i = 0; i < d; i++) {
        int n, m;
        cin >> n >> m;

        vector<int> sources(2 * m);
        for (int j = 0; j < 2 * m; j++) {
            cin >> sources[j];
        }

        map<int, int> inputCount;
        vector<int> assignment(n);

        for (int j = 0; j < 2 * m; j++) {
            if (sources[j] < 0) {
                inputCount[-sources[j]]++;
            }
        }

        int minXIndex = -1;
        int minInputCount = n;

        for (int j = 0; j < n; j++) {
            if (inputCount.find(j + 1) == inputCount.end()) {
                assignment[j] = 1;
            } else {
                assignment[j] = 0;
                if (inputCount[j + 1] < minInputCount) {
                    minInputCount = inputCount[j + 1];
                    minXIndex = j;
                }
            }
        }

        assignment[minXIndex] = 2;

        for (int j = 0; j < n; j++) {
            if (assignment[j] == 0) {
                cout << "0";
            } else if (assignment[j] == 1) {
                cout << "1";
            } else {
                cout << "x";
            }
        }

        cout << endl;
    }

    return 0;
}