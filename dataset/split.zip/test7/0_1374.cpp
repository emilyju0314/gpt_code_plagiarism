#include <iostream>
#include <cmath>

int main() {
    int n;
    
    while(std::cin >> n && n != 0) {
        int operations = 0;
        
        while(n > 1) {
            if(n % 2 == 0) {
                n /= 2;
            } else {
                n -= 1;
            }
            operations++;
        }
        
        std::cout << operations << std::endl;
    }
    
    return 0;
}