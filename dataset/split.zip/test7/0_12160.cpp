#include <iostream>
#include <vector>

using namespace std;

int main() {
    int L, U, R, button;
    int caseNum = 1;

    while (true) {
        cin >> L >> U >> R;
        if (L == 0 && U == 0 && R == 0) {
            break;
        }

        vector<int> buttons;
        for (int i = 0; i < R; i++) {
            cin >> button;
            buttons.push_back(button);
        }

        vector<bool> visited(10000, false);
        vector<int> distance(10000, -1);
        distance[L] = 0;

        for (int i = 0; i < 10000; i++) {
            if (distance[U] != -1) {
                break;
            }

            for (int b : buttons) {
                int newLock = (i + b) % 10000;
                if (distance[newLock] == -1) {
                    distance[newLock] = distance[i] + 1;
                }
            }
        }

        if (distance[U] == -1) {
            cout << "Case " << caseNum << ": Permanently Locked" << endl;
        } else {
            cout << "Case " << caseNum << ": " << distance[U] << endl;
        }

        caseNum++;
    }

    return 0;
}