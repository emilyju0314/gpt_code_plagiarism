#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool isCyclic(vector<vector<int>>& matrix, int n, int i, int j, int k) {
    return matrix[i][j] && matrix[j][k] && matrix[k][i];
}

void findCyclicChains(vector<vector<int>>& matrix, int n) {
    vector<vector<int>> chains;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                if (isCyclic(matrix, n, i, j, k)) {
                    vector<int> chain = {i+1, j+1, k+1};
                    sort(chain.begin(), chain.end());
                    if (find(chains.begin(), chains.end(), chain) == chains.end()) {
                        chains.push_back(chain);
                    }
                }
            }
        }
    }

    sort(chains.begin(), chains.end());

    for (auto chain : chains) {
        for (int i = 0; i < 3; i++) {
            cout << chain[i] << " ";
        }
        cout << endl;
    }

    cout << "total:" << chains.size() << endl;
}

int main() {
    int n;
    while (cin >> n) {
        vector<vector<int>> matrix(n, vector<int>(n));

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> matrix[i][j];
            }
        }

        findCyclicChains(matrix, n);

        cout << endl;
    }

    return 0;
}