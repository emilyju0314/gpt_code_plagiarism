#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 0; t < T; t++) {
        int n;
        cin >> n;

        vector<int> positions(n);
        vector<int> earnings(n);
        vector<int> penalties(n);

        for (int i = 0; i < n; i++) {
            cin >> positions[i];
        }

        for (int i = 0; i < n; i++) {
            cin >> earnings[i];
        }

        penalties[0] = 0;
        for (int i = 1; i < n; i++) {
            penalties[i] = penalties[i-1] + (positions[i] - positions[i-1]) - 1;
        }

        vector<int> profit(n);
        profit[0] = earnings[0] - penalties[0];

        for (int i = 1; i < n; i++) {
            profit[i] = max(earnings[i] - penalties[i], profit[i-1]);
        }

        cout << profit[n-1] << endl;
    }

    return 0;
}