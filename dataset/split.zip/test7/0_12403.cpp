#include <iostream>
#include <string>

using namespace std;

int main() {
    int T, amount = 0;
    cin >> T;

    for (int i = 0; i < T; i++) {
        string operation;
        int value;

        cin >> operation;

        if (operation == "donate") {
            cin >> value;
            amount += value;
        } else if (operation == "report") {
            cout << amount << endl;
        }
    }

    return 0;
}