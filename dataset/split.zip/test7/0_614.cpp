#include <iostream>
#include <vector>

using namespace std;

struct Cell {
    int row;
    int col;
    int value;
    bool visited;
    bool inPath;
};

void solveMaze(vector<vector<Cell>>& maze, int currentRow, int currentCol, int sequence) {
    if (currentRow < 0 || currentRow >= maze.size() || currentCol < 0 || currentCol >= maze[0].size() || maze[currentRow][currentCol].visited || maze[currentRow][currentCol].value == 3) {
        return;
    }
    maze[currentRow][currentCol].visited = true;
    maze[currentRow][currentCol].inPath = true;
    maze[currentRow][currentCol].value = sequence;

    if (currentRow == maze.size() - 1 && currentCol == maze[0].size() - 1) {
        return;
    }

    solveMaze(maze, currentRow, currentCol - 1, sequence + 1);
    solveMaze(maze, currentRow - 1, currentCol, sequence + 1);
    solveMaze(maze, currentRow, currentCol + 1, sequence + 1);
    solveMaze(maze, currentRow + 1, currentCol, sequence + 1);

    if (currentRow == maze.size() - 1 && currentCol == maze[0].size() - 1) {
        return;
    }

    maze[currentRow][currentCol].visited = false;
    maze[currentRow][currentCol].inPath = false;
    maze[currentRow][currentCol].value = -1;
}

int main() {
    int mazeNum = 1;
    while (true) {
        int rows, cols, startRow, startCol, goalRow, goalCol;
        cin >> rows >> cols >> startRow >> startCol >> goalRow >> goalCol;
        
        if (rows == 0 && cols == 0 && startRow == 0 && startCol == 0 && goalRow == 0 && goalCol == 0) {
            break;
        }

        vector<vector<Cell>> maze(rows, vector<Cell>(cols));
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int value;
                cin >> value;
                maze[i][j] = {i, j, value, false, false};
            }
        }

        solveMaze(maze, startRow - 1, startCol - 1, 1);

        cout << "Maze " << mazeNum << endl;
        for (int i = 0; i < rows; i++) {
            cout << "+";
            for (int j = 0; j < cols; j++) {
                cout << "---+";
            }
            cout << endl;

            cout << "|";
            for (int j = 0; j < cols; j++) {
                if (maze[i][j].inPath) {
                    cout << " " << maze[i][j].value << " |";
                } else {
                    cout << "???|";
                }
            }
            cout << endl;
        }

        cout << "+";
        for (int j = 0; j < cols; j++) {
            cout << "---+";
        }
        cout << endl;
        cout << endl;

        mazeNum++;
    }

    return 0;
}