#include <iostream>
#include <string>
#include <stack>

bool evaluateWFF(std::string wff) {
    std::stack<int> stack;
    
    for(char c : wff) {
        if(c == 'p' || c == 'q' || c == 'r' || c == 's' || c == 't') {
            // Push variable value to stack
            stack.push(1);
            stack.push(0);
        } else if(c == 'N') {
            int val = stack.top();
            stack.pop();
            stack.push(!val);
        } else if(c == 'K') {
            int val2 = stack.top();
            stack.pop();
            int val1 = stack.top();
            stack.pop();
            stack.push(val1 && val2);
        } else if(c == 'A') {
            int val2 = stack.top();
            stack.pop();
            int val1 = stack.top();
            stack.pop();
            stack.push(val1 || val2);
        } else if(c == 'C') {
            int val2 = stack.top();
            stack.pop();
            int val1 = stack.top();
            stack.pop();
            stack.push(!val1 || val2);
        } else if(c == 'E') {
            int val2 = stack.top();
            stack.pop();
            int val1 = stack.top();
            stack.pop();
            stack.push(val1 == val2);
        }
    }
    
    // Check if WFF is a tautology
    return stack.top() == 1;
}

int main() {
    std::string wff;
    
    while(std::cin >> wff) {
        if(wff == "0") {
            break;
        }
        
        if(evaluateWFF(wff)) {
            std::cout << "tautology" << std::endl;
        } else {
            std::cout << "not" << std::endl;
        }
    }
    
    return 0;
}