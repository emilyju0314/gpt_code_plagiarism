#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool isBipartite(vector<vector<int>>& graph, int start) {
    vector<int> colors(graph.size(), -1);
    colors[start] = 0;
    queue<int> q;
    q.push(start);

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (int neighbor : graph[node]) {
            if (colors[neighbor] == -1) {
                colors[neighbor] = 1 - colors[node];
                q.push(neighbor);
            } else if (colors[neighbor] == colors[node]) {
                return false;
            }
        }
    }

    return true;
}

int main() {
    int n, l;
    while (cin >> n && n != 0) {
        cin >> l;

        vector<vector<int>> graph(n);

        for (int i = 0; i < l; i++) {
            int a, b;
            cin >> a >> b;
            graph[a].push_back(b);
            graph[b].push_back(a);
        }

        if (isBipartite(graph, 0)) {
            cout << "BICOLORABLE." << endl;
        } else {
            cout << "NOT BICOLORABLE." << endl;
        }
    }

    return 0;
}