#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int size;
    
    while (true) {
        cin >> size;
        
        if (size == 0) {
            break;
        }
        
        if (size == 1) {
            cout << "0" << endl;
        } else {
            cout << pow(2, size) - 2 << endl;
        }
    }
    
    return 0;
} 

//Output:
//4
//5
//0
//3
//8