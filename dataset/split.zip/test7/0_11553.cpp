#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int minimax(vector<vector<int>>& grid, int i, int j, bool isAliceTurn) {
    if (i == grid.size() || j == grid.size()) return 0;
    
    int candies = grid[i][j];
    grid[i][j] = 0;
    
    if (isAliceTurn) {
        int maxCandies = -1000;
        for (int row = 0; row < grid.size(); row++) {
            maxCandies = max(maxCandies, candies + minimax(grid, row, j, false));
        }
        grid[i][j] = candies;
        return maxCandies;
    } else {
        int minCandies = 1000;
        for (int col = 0; col < grid.size(); col++) {
            minCandies = min(minCandies, -candies + minimax(grid, i, col, true));
        }
        grid[i][j] = candies;
        return minCandies;
    }
}

int main() {
    int t;
    cin >> t;
    
    while (t--) {
        int n;
        cin >> n;
        
        vector<vector<int>> grid(n, vector<int>(n));
        
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> grid[i][j];
            }
        }
        
        int result = minimax(grid, 0, 0, true);
        cout << result << endl;
    }
    
    return 0;
}