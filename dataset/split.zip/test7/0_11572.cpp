#include <iostream>
#include <set>

using namespace std;

int main() {
    int test_cases;
    cin >> test_cases;
    
    while (test_cases--) {
        int n;
        cin >> n;
        
        set<int> unique_snowflakes;
        int max_package_size = 0;
        
        for (int i = 0; i < n; i++) {
            int snowflake_id;
            cin >> snowflake_id;
            
            if (unique_snowflakes.count(snowflake_id) == 0) {
                unique_snowflakes.insert(snowflake_id);
                max_package_size = max(max_package_size, (int)unique_snowflakes.size());
            } else {
                unique_snowflakes.clear();
                unique_snowflakes.insert(snowflake_id);
            }
        }
        
        cout << max_package_size << endl;
    }
    
    return 0;
}