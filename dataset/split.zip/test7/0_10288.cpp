#include <iostream>

int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

int main() {
    int n;

    while (std::cin >> n) {
        int lcm = 1;
        for (int i = 1; i <= n; i++) {
            lcm = (lcm * i) / gcd(lcm, i);
        }

        std::cout << lcm << " -";

        for (int i = 1; i <= n; i++) {
            std::cout << "-";
        }

        std::cout << std::endl;
    }

    return 0;
}