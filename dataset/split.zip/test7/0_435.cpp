#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 0; i < t; i++) {
        int p;
        cin >> p;
        
        vector<int> parties(p);
        int totalVotes = 0;
        
        for (int j = 0; j < p; j++) {
            cin >> parties[j];
            totalVotes += parties[j];
        }
        
        for (int j = 0; j < p; j++) {
            int coalitionVotes = 0;
            for (int k = 0; k < p; k++) {
                if (k != j) {
                    coalitionVotes += parties[k];
                }
            }
            
            int powerIndex = totalVotes - coalitionVotes;
            cout << "party " << j+1 << " has power index " << powerIndex << endl;
        }
        
        cout << endl;
    }

    return 0;
}